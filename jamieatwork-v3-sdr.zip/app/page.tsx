import Link from 'next/link'

const SDR_CAPABILITIES = [
  {
    icon: '🎯',
    title: 'Inbound Chat',
    desc: 'Engages website visitors instantly, qualifies them with your criteria, and books meetings on your calendar.',
  },
  {
    icon: '✉️',
    title: 'Outbound Email',
    desc: 'Crafts personalized outreach based on your ICP and value prop. No more generic templates.',
  },
  {
    icon: '🔍',
    title: 'Lead Qualification',
    desc: 'Asks the right questions, scores leads against your framework, and filters out bad fits automatically.',
  },
  {
    icon: '📅',
    title: 'Meeting Booking',
    desc: 'When a lead qualifies, Jamie books directly on your calendar. No back-and-forth scheduling.',
  },
  {
    icon: '🔄',
    title: 'Follow-up Sequences',
    desc: 'Prospects go quiet? Jamie follows up persistently but naturally until they respond or opt out.',
  },
  {
    icon: '📊',
    title: 'Pipeline Dashboard',
    desc: 'Track every lead, conversation, and meeting. Full visibility into your AI-powered pipeline.',
  },
]

const HOW_IT_WORKS = [
  {
    step: '01',
    title: 'Upload Your Docs',
    desc: 'Drop in your pitch deck, product one-pager, case studies — whatever you have. Jamie reads it all in seconds.',
    time: '5 min',
  },
  {
    step: '02',
    title: 'Train Jamie',
    desc: 'Jamie interviews you about your product, ICP, objections, and qualification criteria. Just talk to her like a real hire.',
    time: '15 min',
  },
  {
    step: '03',
    title: 'Review & Go Live',
    desc: 'Jamie generates your Sales Playbook. Review it, approve it, and she starts working your pipeline immediately.',
    time: '10 min',
  },
]

export default function Home() {
  return (
    <div style={{ minHeight: '100vh' }}>
      {/* Navigation */}
      <nav style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100,
        padding: '16px 0',
        background: 'rgba(10, 10, 15, 0.85)',
        backdropFilter: 'blur(20px)',
        borderBottom: '1px solid var(--border-color)',
      }}>
        <div className="container" style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
          <Link href="/" style={{
            fontFamily: 'var(--font-mono)',
            fontSize: '18px',
            fontWeight: 700,
            letterSpacing: '-0.02em',
          }}>
            <span style={{ color: 'var(--accent-primary)' }}>jamie</span>
            <span style={{ color: 'var(--text-tertiary)' }}>@</span>
            <span>work</span>
          </Link>

          <div style={{ display: 'flex', gap: '8px' }}>
            <Link href="/dashboard" className="btn btn-secondary" style={{ fontSize: '13px', padding: '8px 16px' }}>
              Dashboard
            </Link>
            <Link href="/onboarding" className="btn btn-primary" style={{ fontSize: '13px', padding: '8px 16px' }}>
              Hire Jamie →
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section style={{
        paddingTop: '160px',
        paddingBottom: '100px',
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute',
          top: '10%',
          left: '20%',
          width: '400px',
          height: '400px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(34, 211, 167, 0.08) 0%, transparent 70%)',
          filter: 'blur(60px)',
          pointerEvents: 'none',
        }} />
        <div style={{
          position: 'absolute',
          top: '30%',
          right: '10%',
          width: '300px',
          height: '300px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(99, 102, 241, 0.08) 0%, transparent 70%)',
          filter: 'blur(60px)',
          pointerEvents: 'none',
        }} />

        <div className="container" style={{ position: 'relative', textAlign: 'center' }}>
          <div className="animate-in" style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '8px',
            padding: '6px 16px',
            borderRadius: 'var(--radius-full)',
            border: '1px solid var(--border-color)',
            background: 'var(--bg-card)',
            fontSize: '13px',
            color: 'var(--text-secondary)',
            marginBottom: '32px',
          }}>
            <span style={{
              width: '6px',
              height: '6px',
              borderRadius: '50%',
              background: 'var(--accent-primary)',
              animation: 'pulse-glow 2s infinite',
            }} />
            Your AI Sales Development Rep
          </div>

          <h1 className="animate-in animate-delay-1" style={{
            fontSize: 'clamp(40px, 6vw, 72px)',
            fontWeight: 700,
            lineHeight: 1.05,
            letterSpacing: '-0.03em',
            marginBottom: '24px',
          }}>
            Your first SDR.<br />
            <span className="glow-text">Trained in 30 minutes.</span>
          </h1>

          <p className="animate-in animate-delay-2" style={{
            fontSize: '18px',
            color: 'var(--text-secondary)',
            maxWidth: '560px',
            margin: '0 auto 40px',
            lineHeight: 1.6,
          }}>
            Jamie is an AI sales agent that learns your product, your pitch, 
            and your ICP — then qualifies leads, sends outreach, and books 
            meetings on your calendar. 24/7.
          </p>

          <div className="animate-in animate-delay-3" style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
            <Link href="/onboarding" className="btn btn-primary btn-lg">
              Hire Jamie — It&apos;s Free to Start →
            </Link>
            <a href="#how-it-works" className="btn btn-secondary btn-lg">
              See How It Works
            </a>
          </div>

          {/* Social proof line */}
          <p className="animate-in animate-delay-4" style={{
            fontSize: '13px',
            color: 'var(--text-tertiary)',
            marginTop: '24px',
          }}>
            Built for startups doing $0–$1M ARR who can&apos;t afford a full-time SDR.
          </p>
        </div>
      </section>

      {/* The Problem */}
      <section style={{
        borderTop: '1px solid var(--border-color)',
        borderBottom: '1px solid var(--border-color)',
        padding: '60px 0',
        background: 'var(--bg-secondary)',
      }}>
        <div className="container" style={{ textAlign: 'center', maxWidth: '700px' }}>
          <h2 style={{
            fontSize: '24px',
            fontWeight: 700,
            letterSpacing: '-0.02em',
            marginBottom: '20px',
          }}>
            You know the problem.
          </h2>
          <p style={{
            fontSize: '16px',
            color: 'var(--text-secondary)',
            lineHeight: 1.7,
          }}>
            You&apos;re the founder, the AE, and the SDR. You know you need pipeline, 
            but you&apos;re too busy closing deals to prospect. A junior SDR costs $70K+ and 
            takes 3 months to ramp. And they&apos;ll probably leave in a year.
          </p>
          <div style={{
            display: 'flex',
            justifyContent: 'center',
            gap: '40px',
            marginTop: '32px',
          }}>
            <div>
              <div style={{
                fontSize: '28px',
                fontWeight: 700,
                fontFamily: 'var(--font-mono)',
                color: 'var(--accent-danger)',
              }}>$70K+</div>
              <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginTop: '4px' }}>Junior SDR salary</div>
            </div>
            <div>
              <div style={{
                fontSize: '28px',
                fontWeight: 700,
                fontFamily: 'var(--font-mono)',
                color: 'var(--accent-danger)',
              }}>3 mo</div>
              <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginTop: '4px' }}>Ramp time</div>
            </div>
            <div>
              <div style={{
                fontSize: '28px',
                fontWeight: 700,
                fontFamily: 'var(--font-mono)',
                color: 'var(--accent-danger)',
              }}>14 mo</div>
              <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginTop: '4px' }}>Avg tenure</div>
            </div>
            <div>
              <div style={{
                fontSize: '28px',
                fontWeight: 700,
                fontFamily: 'var(--font-mono)',
                color: 'var(--accent-primary)',
              }}>30 min</div>
              <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginTop: '4px' }}>Jamie&apos;s ramp time</div>
            </div>
          </div>
        </div>
      </section>

      {/* What Jamie Does */}
      <section style={{ padding: '80px 0' }}>
        <div className="container">
          <div style={{ marginBottom: '48px', textAlign: 'center' }}>
            <h2 style={{
              fontSize: '32px',
              fontWeight: 700,
              letterSpacing: '-0.02em',
              marginBottom: '12px',
            }}>
              What Jamie Does
            </h2>
            <p style={{ color: 'var(--text-secondary)', fontSize: '16px' }}>
              A full SDR skill set, trained on your specific product and market.
            </p>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: '20px',
          }}>
            {SDR_CAPABILITIES.map((cap, i) => (
              <div key={cap.title} className={`card animate-in animate-delay-${(i % 4) + 1}`}>
                <div style={{ fontSize: '28px', marginBottom: '12px' }}>{cap.icon}</div>
                <h3 style={{ fontSize: '16px', fontWeight: 600, marginBottom: '8px' }}>
                  {cap.title}
                </h3>
                <p style={{ fontSize: '14px', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
                  {cap.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section id="how-it-works" style={{
        padding: '80px 0',
        borderTop: '1px solid var(--border-color)',
        background: 'var(--bg-secondary)',
      }}>
        <div className="container">
          <h2 style={{
            fontSize: '32px',
            fontWeight: 700,
            letterSpacing: '-0.02em',
            marginBottom: '48px',
            textAlign: 'center',
          }}>
            Trained and ready in <span className="glow-text">30 minutes</span>
          </h2>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: '24px',
          }}>
            {HOW_IT_WORKS.map((item) => (
              <div key={item.step} className="card" style={{ textAlign: 'center', padding: '32px' }}>
                <div style={{
                  fontFamily: 'var(--font-mono)',
                  fontSize: '36px',
                  fontWeight: 700,
                  color: 'var(--accent-primary)',
                  marginBottom: '16px',
                  opacity: 0.6,
                }}>
                  {item.step}
                </div>
                <h3 style={{ fontSize: '18px', fontWeight: 600, marginBottom: '8px' }}>
                  {item.title}
                </h3>
                <p style={{ fontSize: '14px', color: 'var(--text-secondary)', lineHeight: 1.6, marginBottom: '16px' }}>
                  {item.desc}
                </p>
                <span style={{
                  fontFamily: 'var(--font-mono)',
                  fontSize: '12px',
                  color: 'var(--accent-primary)',
                  padding: '4px 10px',
                  borderRadius: 'var(--radius-full)',
                  border: '1px solid rgba(34, 211, 167, 0.2)',
                  background: 'rgba(34, 211, 167, 0.08)',
                }}>
                  ~{item.time}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section style={{
        padding: '80px 0',
        textAlign: 'center',
      }}>
        <div className="container" style={{ maxWidth: '600px' }}>
          <h2 style={{
            fontSize: '32px',
            fontWeight: 700,
            letterSpacing: '-0.02em',
            marginBottom: '16px',
          }}>
            Stop doing SDR work yourself.
          </h2>
          <p style={{
            fontSize: '16px',
            color: 'var(--text-secondary)',
            marginBottom: '32px',
            lineHeight: 1.6,
          }}>
            Hire Jamie, teach her your pitch in 30 minutes, and let her 
            fill your calendar with qualified meetings.
          </p>
          <Link href="/onboarding" className="btn btn-primary btn-lg">
            Hire SDR Jamie →
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer style={{
        padding: '40px 0',
        borderTop: '1px solid var(--border-color)',
      }}>
        <div className="container" style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}>
          <div style={{
            fontFamily: 'var(--font-mono)',
            fontSize: '14px',
            color: 'var(--text-tertiary)',
          }}>
            © 2026 jamie@work
          </div>
          <div style={{
            fontSize: '13px',
            color: 'var(--text-tertiary)',
          }}>
            AI digital employees for startups
          </div>
        </div>
      </footer>
    </div>
  )
}
