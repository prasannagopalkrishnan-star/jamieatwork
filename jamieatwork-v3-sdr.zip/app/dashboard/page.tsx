import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'

export const dynamic = 'force-dynamic'

interface Lead {
  id: string
  name: string | null
  email: string | null
  company_name: string | null
  role_title: string | null
  source: string | null
  status: string
  qualification_score: number | null
  created_at: string
}

interface DigitalEmployee {
  id: string
  name: string
  title: string
  department: string | null
  category: string | null
  status: string
  created_at: string
}

interface Ticket {
  id: string
  ticket_ref: string | null
  submitter_name: string | null
  category: string | null
  question: string
  status: string
  created_at: string
}

export default async function DashboardPage() {
  const supabase = await createClient()

  const { data: employees } = await supabase
    .from('digital_employees')
    .select('*')
    .order('created_at', { ascending: false })

  const { data: leads } = await supabase
    .from('leads')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(10)

  const { data: tickets } = await supabase
    .from('tickets')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(10)

  const activeEmployees = employees?.filter((e: DigitalEmployee) => e.status === 'active').length ?? 0
  const totalLeads = leads?.length ?? 0
  const qualifiedLeads = leads?.filter((l: Lead) => l.status === 'qualified' || l.status === 'meeting_booked').length ?? 0
  const meetingsBooked = leads?.filter((l: Lead) => l.status === 'meeting_booked').length ?? 0

  const statusColors: Record<string, string> = {
    new: 'badge-setup',
    contacted: 'badge-setup',
    qualified: 'badge-active',
    disqualified: 'badge-inactive',
    meeting_booked: 'badge-active',
    closed: 'badge-inactive',
    resolved: 'badge-active',
    open: 'badge-setup',
    escalated: 'badge-inactive',
  }

  return (
    <div style={{ minHeight: '100vh' }}>
      {/* Top Bar */}
      <nav style={{
        position: 'sticky',
        top: 0,
        zIndex: 100,
        padding: '12px 0',
        background: 'rgba(10, 10, 15, 0.9)',
        backdropFilter: 'blur(20px)',
        borderBottom: '1px solid var(--border-color)',
      }}>
        <div className="container" style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '24px' }}>
            <Link href="/" style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '16px',
              fontWeight: 700,
            }}>
              <span style={{ color: 'var(--accent-primary)' }}>jamie</span>
              <span style={{ color: 'var(--text-tertiary)' }}>@</span>
              <span>work</span>
            </Link>
            <span style={{
              fontSize: '12px',
              color: 'var(--text-tertiary)',
              fontFamily: 'var(--font-mono)',
              padding: '2px 10px',
              borderRadius: 'var(--radius-full)',
              border: '1px solid var(--border-color)',
            }}>
              DASHBOARD
            </span>
          </div>
          <div style={{ display: 'flex', gap: '8px' }}>
            <Link href="/onboarding" className="btn btn-primary" style={{ fontSize: '12px', padding: '6px 14px' }}>
              + Train Jamie
            </Link>
            <Link href="/" className="btn btn-secondary" style={{ fontSize: '12px', padding: '6px 14px' }}>
              ← Marketplace
            </Link>
          </div>
        </div>
      </nav>

      <div className="container" style={{ padding: '40px 24px' }}>
        {/* Header */}
        <div style={{ marginBottom: '36px' }}>
          <h1 style={{ fontSize: '28px', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: '8px' }}>
            SDR Command Center
          </h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: '15px' }}>
            Monitor Jamie&apos;s pipeline activity and lead engagement.
          </p>
        </div>

        {/* Stats Grid */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(4, 1fr)',
          gap: '16px',
          marginBottom: '40px',
        }}>
          {[
            { label: 'Active Agents', value: activeEmployees, color: 'var(--accent-primary)' },
            { label: 'Total Leads', value: totalLeads, color: 'var(--text-primary)' },
            { label: 'Qualified', value: qualifiedLeads, color: 'var(--accent-secondary)' },
            { label: 'Meetings Booked', value: meetingsBooked, color: 'var(--accent-primary)' },
          ].map((stat) => (
            <div key={stat.label} className="card" style={{ padding: '20px' }}>
              <div style={{
                fontSize: '32px',
                fontWeight: 700,
                fontFamily: 'var(--font-mono)',
                color: stat.color,
                marginBottom: '4px',
              }}>
                {stat.value}
              </div>
              <div style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Two Column Layout */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
          {/* Leads Panel */}
          <div>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '16px',
            }}>
              <h2 style={{ fontSize: '18px', fontWeight: 600 }}>Recent Leads</h2>
              <span style={{
                fontSize: '12px',
                color: 'var(--text-tertiary)',
                fontFamily: 'var(--font-mono)',
              }}>
                Pipeline
              </span>
            </div>

            {leads && leads.length > 0 ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {leads.map((lead: Lead) => (
                  <div key={lead.id} className="card" style={{ padding: '14px 16px' }}>
                    <div style={{
                      display: 'flex',
                      alignItems: 'flex-start',
                      justifyContent: 'space-between',
                      gap: '12px',
                    }}>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontWeight: 600, fontSize: '14px', marginBottom: '2px' }}>
                          {lead.name ?? 'Unknown'}
                        </div>
                        <div style={{
                          fontSize: '11px',
                          color: 'var(--text-tertiary)',
                          fontFamily: 'var(--font-mono)',
                        }}>
                          {lead.role_title ?? ''}{lead.company_name ? ` · ${lead.company_name}` : ''} · {lead.source ?? 'manual'} · {new Date(lead.created_at).toLocaleDateString()}
                        </div>
                      </div>
                      <span className={`badge ${statusColors[lead.status] ?? 'badge-setup'}`} style={{ flexShrink: 0 }}>
                        {lead.status.replace('_', ' ')}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="card" style={{
                padding: '40px',
                textAlign: 'center',
                color: 'var(--text-tertiary)',
              }}>
                <div style={{ fontSize: '32px', marginBottom: '12px' }}>🎯</div>
                <p style={{ fontSize: '14px', marginBottom: '16px' }}>No leads yet. Train Jamie and she&apos;ll start filling your pipeline.</p>
                <Link href="/onboarding" className="btn btn-primary" style={{ fontSize: '13px' }}>
                  Train Jamie
                </Link>
              </div>
            )}
          </div>

          {/* Activity Panel */}
          <div>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '16px',
            }}>
              <h2 style={{ fontSize: '18px', fontWeight: 600 }}>Recent Activity</h2>
              <span style={{
                fontSize: '12px',
                color: 'var(--text-tertiary)',
                fontFamily: 'var(--font-mono)',
              }}>
                Last 10
              </span>
            </div>

            {tickets && tickets.length > 0 ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {tickets.map((ticket: Ticket) => (
                  <div key={ticket.id} className="card" style={{ padding: '14px 16px' }}>
                    <div style={{
                      display: 'flex',
                      alignItems: 'flex-start',
                      justifyContent: 'space-between',
                      gap: '12px',
                    }}>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{
                          fontSize: '13px',
                          fontWeight: 500,
                          marginBottom: '4px',
                          whiteSpace: 'nowrap',
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                        }}>
                          {ticket.question}
                        </div>
                        <div style={{
                          fontSize: '11px',
                          color: 'var(--text-tertiary)',
                          fontFamily: 'var(--font-mono)',
                        }}>
                          {ticket.ticket_ref} · {ticket.submitter_name ?? 'Unknown'} · {new Date(ticket.created_at).toLocaleDateString()}
                        </div>
                      </div>
                      <span className={`badge ${statusColors[ticket.status] ?? 'badge-setup'}`} style={{ flexShrink: 0 }}>
                        {ticket.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="card" style={{
                padding: '40px',
                textAlign: 'center',
                color: 'var(--text-tertiary)',
              }}>
                <div style={{ fontSize: '32px', marginBottom: '12px' }}>📭</div>
                <p style={{ fontSize: '14px' }}>No activity yet. Conversations will appear here once Jamie starts engaging leads.</p>
              </div>
            )}
          </div>
        </div>

        {/* Active Agents */}
        <div style={{ marginTop: '40px' }}>
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '16px',
          }}>
            <h2 style={{ fontSize: '18px', fontWeight: 600 }}>Your Digital Employees</h2>
          </div>

          {employees && employees.length > 0 ? (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '12px' }}>
              {employees.map((emp: DigitalEmployee) => (
                <div key={emp.id} className="card" style={{ padding: '16px' }}>
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                  }}>
                    <div>
                      <div style={{ fontWeight: 600, fontSize: '15px', marginBottom: '2px' }}>
                        {emp.name}
                      </div>
                      <div style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
                        {emp.title}
                      </div>
                    </div>
                    <span className={`badge badge-${emp.status}`}>
                      {emp.status === 'active' ? '● Active' : emp.status === 'setup' ? '○ Setup' : '◌ Inactive'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="card" style={{
              padding: '32px',
              textAlign: 'center',
              color: 'var(--text-tertiary)',
            }}>
              <p style={{ fontSize: '14px' }}>No agents deployed yet.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
