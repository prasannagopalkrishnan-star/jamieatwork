'use client'

import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'

export default function LogoutButton() {
  const router = useRouter()

  const handleLogout = async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push('/')
  }

  return (
    <button onClick={handleLogout}
      style={{
        fontSize: '12px', padding: '7px 14px', borderRadius: '9px',
        border: '1.5px solid #E8E5DF', background: 'white', color: '#78716C',
        fontFamily: "'DM Sans', sans-serif", fontWeight: 600,
        cursor: 'pointer', transition: 'all .2s',
      }}
      onMouseEnter={e => { e.currentTarget.style.borderColor = '#DC2626'; e.currentTarget.style.color = '#DC2626' }}
      onMouseLeave={e => { e.currentTarget.style.borderColor = '#E8E5DF'; e.currentTarget.style.color = '#78716C' }}
    >
      Log out
    </button>
  )
}
