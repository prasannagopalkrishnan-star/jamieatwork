'use client'

import { useState, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [message, setMessage] = useState<string | null>(null)
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    const msg = searchParams.get('message')
    if (msg) setMessage(msg)
  }, [searchParams])

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email.trim() || !password.trim()) return
    setLoading(true)
    setError(null)

    const supabase = createClient()
    const { error: signInError } = await supabase.auth.signInWithPassword({ email, password })

    if (signInError) {
      setError(signInError.message)
      setLoading(false)
      return
    }

    router.push('/onboarding')
  }

  return (
    <>
      <style>{`
        @import url('https://api.fontshare.com/v2/css?f[]=satoshi@500,700,800,900&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        .fd{font-family:'Satoshi',-apple-system,sans-serif;}
        .fb{font-family:'DM Sans',-apple-system,sans-serif;}
        .fm{font-family:'JetBrains Mono',monospace;}
        @keyframes fadeUp{from{opacity:0;transform:translateY(14px);}to{opacity:1;transform:translateY(0);}}
        .ai{animation:fadeUp .5s cubic-bezier(.16,1,.3,1) forwards;opacity:0;}
        .d1{animation-delay:.08s;}.d2{animation-delay:.16s;}.d3{animation-delay:.24s;}
        .noise{position:relative;}
        .noise::before{content:'';position:absolute;inset:0;opacity:.02;pointer-events:none;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");}
        input:focus{border-color:#0D9488 !important;box-shadow:0 0 0 3px #F0FDFA !important;}
      `}</style>

      <div className="noise" style={{ minHeight: '100vh', background: '#FAF9F7', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px' }}>
        <div style={{ width: '100%', maxWidth: '400px' }}>
          {/* Logo */}
          <div className="ai" style={{ textAlign: 'center', marginBottom: '36px' }}>
            <Link href="/" style={{ display: 'inline-flex', alignItems: 'center', gap: '10px', textDecoration: 'none', color: '#1C1917' }}>
              <div style={{ width: '36px', height: '36px', borderRadius: '10px', background: 'linear-gradient(135deg,#0D9488,#06B6D4)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: '17px', fontWeight: 800 }}>J</div>
              <span className="fd" style={{ fontSize: '20px', fontWeight: 800, letterSpacing: '-.03em' }}>
                jamie<span style={{ color: '#A8A29E', fontWeight: 500 }}>@</span>work
              </span>
            </Link>
          </div>

          {/* Card */}
          <div className="ai d1" style={{
            padding: '32px', borderRadius: '18px', background: 'white',
            border: '1px solid #E8E5DF', boxShadow: '0 4px 24px rgba(28,25,23,.06)',
          }}>
            <h1 className="fd" style={{ fontSize: '24px', fontWeight: 800, letterSpacing: '-.03em', marginBottom: '6px', color: '#1C1917' }}>
              Welcome back
            </h1>
            <p className="fb" style={{ fontSize: '14px', color: '#78716C', marginBottom: '28px', fontWeight: 500, lineHeight: 1.5 }}>
              Log in to manage Jamie and your pipeline.
            </p>

            {message && (
              <div className="fb" style={{
                padding: '10px 14px', borderRadius: '10px', marginBottom: '20px',
                background: '#F0FDFA', border: '1px solid #99F6E4',
                fontSize: '13px', color: '#0D9488', fontWeight: 500,
              }}>
                {message}
              </div>
            )}

            {error && (
              <div className="fb" style={{
                padding: '10px 14px', borderRadius: '10px', marginBottom: '20px',
                background: '#FEF2F2', border: '1px solid #FECACA',
                fontSize: '13px', color: '#DC2626', fontWeight: 500,
              }}>
                {error}
              </div>
            )}

            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div>
                <label className="fb" style={{ fontSize: '13px', fontWeight: 600, color: '#57534E', display: 'block', marginBottom: '5px' }}>
                  Email
                </label>
                <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                  placeholder="you@company.com" autoFocus className="fb"
                  style={{
                    width: '100%', padding: '11px 14px', borderRadius: '10px',
                    border: '1.5px solid #E8E5DF', background: '#FAF9F7',
                    color: '#1C1917', fontSize: '14px', fontWeight: 500, outline: 'none',
                    transition: 'all .2s',
                  }} />
              </div>

              <div>
                <label className="fb" style={{ fontSize: '13px', fontWeight: 600, color: '#57534E', display: 'block', marginBottom: '5px' }}>
                  Password
                </label>
                <input type="password" value={password} onChange={e => setPassword(e.target.value)}
                  placeholder="Your password" className="fb"
                  onKeyDown={e => e.key === 'Enter' && handleLogin(e)}
                  style={{
                    width: '100%', padding: '11px 14px', borderRadius: '10px',
                    border: '1.5px solid #E8E5DF', background: '#FAF9F7',
                    color: '#1C1917', fontSize: '14px', fontWeight: 500, outline: 'none',
                    transition: 'all .2s',
                  }} />
              </div>

              <button onClick={handleLogin} disabled={loading || !email.trim() || !password.trim()}
                className="fb"
                style={{
                  width: '100%', padding: '13px', borderRadius: '12px', border: 'none',
                  background: loading ? '#F5F3EE' : 'linear-gradient(135deg,#0D9488,#06B6D4)',
                  color: loading ? '#78716C' : 'white',
                  fontSize: '15px', fontWeight: 700, cursor: loading ? 'default' : 'pointer',
                  boxShadow: loading ? 'none' : '0 3px 12px rgba(13,148,136,.25)',
                  transition: 'all .2s', marginTop: '4px',
                }}>
                {loading ? 'Logging in...' : 'Log In →'}
              </button>
            </div>
          </div>

          {/* Signup link */}
          <p className="ai d2 fb" style={{ textAlign: 'center', marginTop: '20px', fontSize: '13px', color: '#78716C', fontWeight: 500 }}>
            Don&apos;t have an account?{' '}
            <Link href="/signup" style={{ color: '#0D9488', fontWeight: 700, textDecoration: 'none' }}>
              Sign up free
            </Link>
          </p>

          <p className="ai d3 fb" style={{ textAlign: 'center', marginTop: '12px', fontSize: '12px' }}>
            <Link href="/" style={{ color: '#A8A29E', textDecoration: 'none', fontWeight: 500 }}>
              ← Back to home
            </Link>
          </p>
        </div>
      </div>
    </>
  )
}
