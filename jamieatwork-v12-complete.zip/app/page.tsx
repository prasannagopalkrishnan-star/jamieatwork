import Link from 'next/link'

const SDR_CAPABILITIES = [
  { icon: '🎯', title: 'Inbound Chat', desc: 'Engages visitors, qualifies them, books meetings on your calendar.' },
  { icon: '✉️', title: 'Outbound Email', desc: 'Personalized outreach based on your ICP. No generic templates.' },
  { icon: '🔍', title: 'Lead Qualification', desc: 'Scores leads against your framework, filters out bad fits.' },
  { icon: '📅', title: 'Meeting Booking', desc: 'Qualified leads get booked directly. No scheduling ping-pong.' },
  { icon: '🔄', title: 'Follow-ups', desc: 'Persistent but natural follow-up until they respond or opt out.' },
  { icon: '📊', title: 'Pipeline View', desc: 'Every lead, conversation, and meeting in one dashboard.' },
]

const HOW_IT_WORKS = [
  { step: '01', title: 'Drop your website', desc: 'Jamie reads your site and pre-fills product, ICP, and differentiators.', time: '2 min', icon: '🌐' },
  { step: '02', title: 'Pick her personality', desc: 'Choose Jamie\'s tone, your CTA, and target market. No forms, just taps.', time: '3 min', icon: '🎭' },
  { step: '03', title: 'Answer 3 questions', desc: 'Jamie asks about objections, qualification, and special context. Done.', time: '5 min', icon: '💬' },
]

export default function Home() {
  return (
    <>
      <style>{`
        @import url('https://api.fontshare.com/v2/css?f[]=satoshi@500,700,800,900&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        body{background:#FFFBF9;}
        .fd{font-family:'Satoshi',-apple-system,sans-serif;}
        .fb{font-family:'DM Sans',-apple-system,sans-serif;}
        .fm{font-family:'JetBrains Mono',monospace;}
        @keyframes fadeUp{from{opacity:0;transform:translateY(16px);}to{opacity:1;transform:translateY(0);}}
        @keyframes float{0%,100%{transform:translateY(0);}50%{transform:translateY(-8px);}}
        @keyframes pulse{0%,100%{opacity:1;}50%{opacity:.4;}}
        @keyframes slideIn{from{opacity:0;transform:translateX(20px);}to{opacity:1;transform:translateX(0);}}
        .ai{animation:fadeUp .6s cubic-bezier(.16,1,.3,1) forwards;opacity:0;}
        .d1{animation-delay:.1s;}.d2{animation-delay:.2s;}.d3{animation-delay:.3s;}.d4{animation-delay:.4s;}.d5{animation-delay:.5s;}
        .si{animation:slideIn .6s cubic-bezier(.16,1,.3,1) forwards;opacity:0;}
        .ch{transition:all .25s cubic-bezier(.16,1,.3,1);}
        .ch:hover{transform:translateY(-3px);box-shadow:0 8px 28px rgba(28,25,23,.08);}
        .noise{position:relative;}
        .noise::before{content:'';position:absolute;inset:0;opacity:.015;pointer-events:none;z-index:0;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");}
        .cta-btn{transition:all .2s;}
        .cta-btn:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(13,148,136,.3);}
        .sec-btn{transition:all .2s;}
        .sec-btn:hover{border-color:#0D9488;color:#0D9488;}
      `}</style>

      <div className="noise" style={{ minHeight: '100vh', background: '#FFFBF9', color: '#1C1917', position: 'relative', overflow: 'hidden' }}>

        {/* ── ROSE GRADIENT BLOBS ── */}
        <div style={{ position: 'fixed', top: '-10%', right: '-5%', width: '600px', height: '600px', borderRadius: '50%', background: 'radial-gradient(circle, rgba(251,113,133,.08) 0%, transparent 70%)', filter: 'blur(60px)', pointerEvents: 'none', zIndex: 0 }} />
        <div style={{ position: 'fixed', bottom: '10%', left: '-8%', width: '500px', height: '500px', borderRadius: '50%', background: 'radial-gradient(circle, rgba(244,114,182,.06) 0%, transparent 70%)', filter: 'blur(50px)', pointerEvents: 'none', zIndex: 0 }} />
        <div style={{ position: 'fixed', top: '40%', left: '30%', width: '400px', height: '400px', borderRadius: '50%', background: 'radial-gradient(circle, rgba(13,148,136,.04) 0%, transparent 70%)', filter: 'blur(50px)', pointerEvents: 'none', zIndex: 0 }} />

        {/* ── NAV ── */}
        <nav style={{
          position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100, padding: '12px 0',
          background: 'rgba(255,251,249,.88)', backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)',
          borderBottom: '1px solid rgba(232,229,223,.6)',
        }}>
          <div style={{ maxWidth: '1080px', margin: '0 auto', padding: '0 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: '8px', textDecoration: 'none', color: '#1C1917' }}>
              <div style={{ width: '28px', height: '28px', borderRadius: '8px', background: 'linear-gradient(135deg,#0D9488,#06B6D4)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: '13px', fontWeight: 800 }}>J</div>
              <span className="fd" style={{ fontSize: '16px', fontWeight: 900, letterSpacing: '-.03em' }}>jamie<span style={{ color: '#D4A0A0', fontWeight: 500 }}>@</span>work</span>
            </Link>
            <div style={{ display: 'flex', gap: '8px' }}>
              <Link href="/dashboard" className="fb sec-btn" style={{ fontSize: '13px', padding: '7px 16px', borderRadius: '9px', border: '1.5px solid #E8E5DF', background: 'white', color: '#1C1917', textDecoration: 'none', fontWeight: 700 }}>Dashboard</Link>
              <Link href="/signup" className="fb cta-btn" style={{ fontSize: '13px', padding: '7px 16px', borderRadius: '9px', background: 'linear-gradient(135deg,#0D9488,#06B6D4)', color: 'white', textDecoration: 'none', fontWeight: 700, border: 'none' }}>Hire Jamie →</Link>
            </div>
          </div>
        </nav>

        {/* ── HERO — left copy, right visual ── */}
        <section style={{ paddingTop: '110px', paddingBottom: '60px', position: 'relative', zIndex: 1 }}>
          <div style={{ maxWidth: '1080px', margin: '0 auto', padding: '0 24px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '48px', alignItems: 'center' }}>
            {/* Left — copy */}
            <div>
              <div className="ai fb" style={{
                display: 'inline-flex', alignItems: 'center', gap: '7px', padding: '5px 14px',
                borderRadius: '100px', border: '1px solid #F9D4DC', background: '#FFF5F7',
                fontSize: '12px', color: '#BE185D', marginBottom: '20px', fontWeight: 600,
              }}>
                <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#F472B6', animation: 'pulse 2s infinite' }} />
                AI Sales Development Rep
              </div>

              <h1 className="ai d1 fd" style={{ fontSize: '52px', fontWeight: 900, lineHeight: 1.02, letterSpacing: '-.05em', marginBottom: '18px' }}>
                Your first SDR.<br />
                <span style={{ background: 'linear-gradient(135deg,#0D9488,#06B6D4)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                  Trained in 10 min.
                </span>
              </h1>

              <p className="ai d2 fb" style={{ fontSize: '17px', color: '#57534E', lineHeight: 1.6, marginBottom: '28px', maxWidth: '460px', fontWeight: 500 }}>
                Jamie learns your product, pitch, and ICP — then qualifies leads, sends outreach, and books meetings on your calendar. 24/7.
              </p>

              <div className="ai d3" style={{ display: 'flex', gap: '10px', marginBottom: '18px' }}>
                <Link href="/signup" className="fb cta-btn" style={{
                  padding: '13px 30px', borderRadius: '12px',
                  background: 'linear-gradient(135deg,#0D9488,#06B6D4)', color: 'white',
                  fontSize: '15px', fontWeight: 700, textDecoration: 'none',
                  boxShadow: '0 4px 16px rgba(13,148,136,.25)',
                }}>Hire Jamie — Free to Start →</Link>
                <a href="#how-it-works" className="fb sec-btn" style={{
                  padding: '13px 24px', borderRadius: '12px',
                  background: 'white', border: '1.5px solid #E8E5DF', color: '#1C1917',
                  fontSize: '15px', fontWeight: 700, textDecoration: 'none',
                }}>How It Works</a>
              </div>

              <p className="ai d4 fb" style={{ fontSize: '12px', color: '#A8A29E', fontWeight: 600 }}>
                For startups doing $0–$1M ARR who can&apos;t afford a full-time SDR.
              </p>
            </div>

            {/* Right — animated onboarding preview */}
            <div className="si d2" style={{ position: 'relative' }}>
              <div style={{
                padding: '28px', borderRadius: '20px',
                background: 'linear-gradient(145deg, #FFF5F7, #FFF0F3, #FFEEF2)',
                border: '1px solid #F9D4DC',
                boxShadow: '0 8px 40px rgba(244,114,182,.1)',
              }}>
                {/* Mini onboarding card preview */}
                <div style={{ marginBottom: '16px' }}>
                  <div className="fm" style={{ fontSize: '9px', color: '#BE185D', letterSpacing: '.08em', fontWeight: 700, marginBottom: '10px' }}>ONBOARDING PREVIEW</div>
                  {/* URL scan bar */}
                  <div style={{ display: 'flex', gap: '6px', padding: '4px', borderRadius: '10px', background: 'white', border: '1px solid #E8E5DF', marginBottom: '12px' }}>
                    <div className="fm" style={{ padding: '8px 10px', fontSize: '11px', color: '#A8A29E' }}>https://</div>
                    <div className="fb" style={{ padding: '8px 0', fontSize: '13px', color: '#1C1917', fontWeight: 500, flex: 1 }}>yourcompany.com</div>
                    <div style={{ padding: '8px 14px', borderRadius: '8px', background: 'linear-gradient(135deg,#0D9488,#06B6D4)', color: 'white', fontSize: '11px', fontWeight: 700 }}>🔍 Scan</div>
                  </div>
                  {/* Vibe cards mini */}
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px', marginBottom: '12px' }}>
                    {[
                      { emoji: '🌊', label: 'Chill', g: 'linear-gradient(135deg,#0D9488,#06B6D4)' },
                      { emoji: '⚡', label: 'Sharp', g: 'linear-gradient(135deg,#7C3AED,#A855F7)' },
                      { emoji: '☀️', label: 'Warm', g: 'linear-gradient(135deg,#EA580C,#F97316)' },
                      { emoji: '🤓', label: 'Nerdy', g: 'linear-gradient(135deg,#2563EB,#0EA5E9)' },
                    ].map(v => (
                      <div key={v.label} style={{
                        padding: '10px 8px', borderRadius: '10px', background: v.label === 'Chill' ? v.g : 'white',
                        border: v.label === 'Chill' ? 'none' : '1px solid #E8E5DF',
                        color: v.label === 'Chill' ? 'white' : '#1C1917',
                        display: 'flex', alignItems: 'center', gap: '6px',
                      }}>
                        <span style={{ fontSize: '14px' }}>{v.emoji}</span>
                        <span className="fb" style={{ fontSize: '11px', fontWeight: 700 }}>{v.label}</span>
                      </div>
                    ))}
                  </div>
                  {/* Chat preview */}
                  <div style={{ padding: '10px 12px', borderRadius: '10px', background: 'white', border: '1px solid #E8E5DF' }}>
                    <div style={{ display: 'flex', gap: '8px', alignItems: 'flex-start', marginBottom: '8px' }}>
                      <div style={{ width: '22px', height: '22px', borderRadius: '6px', background: 'linear-gradient(135deg,#0D9488,#06B6D4)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '10px', flexShrink: 0 }}>🤖</div>
                      <div className="fb" style={{ fontSize: '11px', color: '#57534E', lineHeight: 1.4, fontWeight: 500 }}>What are the top objections you hear from prospects?</div>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                      <div style={{ padding: '6px 10px', borderRadius: '8px', background: '#0D9488', fontSize: '11px', color: 'white', fontWeight: 500 }}>&ldquo;Too expensive&rdquo; → We show ROI in...</div>
                    </div>
                  </div>
                </div>
                {/* Floating badge */}
                <div style={{
                  display: 'inline-flex', alignItems: 'center', gap: '6px',
                  padding: '6px 14px', borderRadius: '100px',
                  background: 'white', border: '1px solid #99F6E4',
                  boxShadow: '0 2px 12px rgba(13,148,136,.1)',
                  animation: 'float 3s ease-in-out infinite',
                }}>
                  <span style={{ fontSize: '12px' }}>✅</span>
                  <span className="fb" style={{ fontSize: '11px', fontWeight: 700, color: '#0D9488' }}>Ready in 10 minutes</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ── WHAT JAMIE DOES — rose tint section ── */}
        <section style={{ padding: '64px 0', background: 'linear-gradient(180deg, #FFFBF9 0%, #FFF5F7 50%, #FFFBF9 100%)', borderTop: '1px solid #F9D4DC', borderBottom: '1px solid #F9D4DC', position: 'relative', zIndex: 1 }}>
          <div style={{ maxWidth: '1080px', margin: '0 auto', padding: '0 24px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '28px' }}>
              <div>
                <h2 className="fd" style={{ fontSize: '28px', fontWeight: 900, letterSpacing: '-.04em' }}>What Jamie Does</h2>
                <p className="fb" style={{ color: '#78716C', fontSize: '14px', fontWeight: 500, marginTop: '4px' }}>Full SDR skill set, trained on your product</p>
              </div>
              <div className="fm" style={{ fontSize: '10px', color: '#F472B6', fontWeight: 700, padding: '4px 12px', borderRadius: '6px', background: '#FFF5F7', border: '1px solid #F9D4DC', letterSpacing: '.04em' }}>6 CAPABILITIES</div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px' }}>
              {SDR_CAPABILITIES.map(cap => (
                <div key={cap.title} className="ch" style={{
                  padding: '22px', borderRadius: '16px', background: 'white',
                  border: '1px solid #E8E5DF', boxShadow: '0 1px 4px rgba(28,25,23,.02)', cursor: 'default',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
                    <div style={{ width: '36px', height: '36px', borderRadius: '10px', background: '#FFF5F7', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '18px', border: '1px solid #F9D4DC' }}>{cap.icon}</div>
                    <h3 className="fd" style={{ fontSize: '15px', fontWeight: 800, letterSpacing: '-.01em' }}>{cap.title}</h3>
                  </div>
                  <p className="fb" style={{ fontSize: '13px', color: '#78716C', lineHeight: 1.55, fontWeight: 500, paddingLeft: '46px' }}>{cap.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── HOW IT WORKS ── */}
        <section id="how-it-works" style={{ padding: '64px 0', position: 'relative', zIndex: 1 }}>
          <div style={{ maxWidth: '1080px', margin: '0 auto', padding: '0 24px' }}>
            <div style={{ textAlign: 'center', marginBottom: '40px' }}>
              <h2 className="fd" style={{ fontSize: '28px', fontWeight: 900, letterSpacing: '-.04em', marginBottom: '8px' }}>
                Ready in{' '}
                <span style={{ background: 'linear-gradient(135deg,#F472B6,#FB7185)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>10 minutes</span>
              </h2>
              <p className="fb" style={{ fontSize: '14px', color: '#78716C', fontWeight: 500 }}>Three steps. No forms. No meetings. No ramp time.</p>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px' }}>
              {HOW_IT_WORKS.map((item, i) => (
                <div key={item.step} style={{
                  padding: '28px 24px', borderRadius: '18px', background: 'white',
                  border: '1px solid #E8E5DF',
                  boxShadow: '0 2px 8px rgba(28,25,23,.03)',
                  position: 'relative', overflow: 'hidden',
                }}>
                  {/* Rose accent stripe at top */}
                  <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: '3px', background: i === 0 ? 'linear-gradient(90deg,#F472B6,#FB7185)' : i === 1 ? 'linear-gradient(90deg,#0D9488,#06B6D4)' : 'linear-gradient(90deg,#7C3AED,#A855F7)' }} />
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '14px' }}>
                    <div style={{ width: '42px', height: '42px', borderRadius: '12px', background: '#FFF5F7', border: '1px solid #F9D4DC', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '20px' }}>{item.icon}</div>
                    <div>
                      <div className="fm" style={{ fontSize: '22px', fontWeight: 700, color: '#F472B6', lineHeight: 1 }}>{item.step}</div>
                    </div>
                  </div>
                  <h3 className="fd" style={{ fontSize: '18px', fontWeight: 800, marginBottom: '6px', letterSpacing: '-.02em' }}>{item.title}</h3>
                  <p className="fb" style={{ fontSize: '13px', color: '#78716C', lineHeight: 1.55, marginBottom: '14px', fontWeight: 500 }}>{item.desc}</p>
                  <span className="fm" style={{ fontSize: '11px', color: '#0D9488', padding: '4px 12px', borderRadius: '100px', border: '1px solid #99F6E4', background: '#F0FDFA', fontWeight: 600 }}>~{item.time}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── CTA — rose background ── */}
        <section style={{ padding: '60px 0', background: 'linear-gradient(180deg, #FFFBF9 0%, #FFF0F3 100%)', borderTop: '1px solid #F9D4DC', position: 'relative', zIndex: 1 }}>
          <div style={{ maxWidth: '520px', margin: '0 auto', padding: '0 24px', textAlign: 'center' }}>
            <div style={{ fontSize: '36px', marginBottom: '16px' }}>🚀</div>
            <h2 className="fd" style={{ fontSize: '30px', fontWeight: 900, letterSpacing: '-.04em', marginBottom: '12px' }}>
              Stop doing SDR work yourself.
            </h2>
            <p className="fb" style={{ fontSize: '15px', color: '#78716C', marginBottom: '28px', lineHeight: 1.6, fontWeight: 500 }}>
              Hire Jamie, teach her your pitch in 10 minutes, and let her fill your calendar with qualified meetings.
            </p>
            <Link href="/signup" className="fb cta-btn" style={{
              display: 'inline-block', padding: '14px 32px', borderRadius: '14px',
              background: 'linear-gradient(135deg,#0D9488,#06B6D4)', color: 'white',
              fontSize: '16px', fontWeight: 700, textDecoration: 'none',
              boxShadow: '0 4px 16px rgba(13,148,136,.25)',
            }}>Hire SDR Jamie — Free →</Link>
            <p className="fb" style={{ marginTop: '14px', fontSize: '12px', color: '#D4A0A0', fontWeight: 600 }}>No credit card required</p>
          </div>
        </section>

        {/* ── FOOTER ── */}
        <footer style={{ padding: '28px 0', borderTop: '1px solid rgba(232,229,223,.6)', position: 'relative', zIndex: 1 }}>
          <div style={{ maxWidth: '1080px', margin: '0 auto', padding: '0 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span className="fm" style={{ fontSize: '12px', color: '#A8A29E' }}>© 2026 jamie@work</span>
            <span className="fb" style={{ fontSize: '12px', color: '#D4A0A0', fontWeight: 500 }}>AI digital employees for startups</span>
          </div>
        </footer>
      </div>
    </>
  )
}
