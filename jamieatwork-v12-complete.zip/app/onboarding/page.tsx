'use client'

import { useState, useRef, useEffect, useCallback } from 'react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'

/* ─── PALETTE ─── */
const P = {
  bg: '#FAF9F7', bgWash: '#F5F3EE', bgCard: '#FFFFFF',
  border: '#E8E5DF', borderSubtle: '#F0EDE8', borderFocus: '#0D9488',
  text: '#1C1917', textMd: '#57534E', textSec: '#78716C', textTer: '#A8A29E',
  accent: '#0D9488', accentHover: '#0F766E', accentLight: '#F0FDFA', accentBorder: '#99F6E4',
  gradient: 'linear-gradient(135deg,#0D9488,#06B6D4)',
  gradientPurple: 'linear-gradient(135deg,#7C3AED,#A855F7)',
  gradientWarm: 'linear-gradient(135deg,#EA580C,#F97316)',
  gradientBlue: 'linear-gradient(135deg,#2563EB,#0EA5E9)',
  warning: '#EA580C', danger: '#DC2626', success: '#16A34A',
}

type Phase = 'cards' | 'chat' | 'review'
interface Msg { role: 'jamie' | 'user'; content: string }
interface Playbook {
  product_name: string; product_description: string; problem_solved: string
  key_differentiators: string; target_company_size: string; target_industries: string
  target_roles: string; icp_signals: string; qualification_questions: string[]
  disqualification_criteria: string
  objection_playbook: { objection: string; response: string }[]
  voice_style: string; call_to_action: string; calendar_link: string
}
interface Scraped {
  product_name: string; product_description: string; problem_solved: string
  key_differentiators: string; suggested_industries: string; suggested_roles: string
}

const FONTS = `
@import url('https://api.fontshare.com/v2/css?f[]=satoshi@500,700,800,900&display=swap');
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&display=swap');
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&display=swap');
`

const CSS = `
${FONTS}
*{box-sizing:border-box;margin:0;padding:0;}
body{background:${P.bg};}
.fd{font-family:'Satoshi',-apple-system,sans-serif;}
.fb{font-family:'DM Sans',-apple-system,sans-serif;}
.fm{font-family:'JetBrains Mono',monospace;}
.noise{position:relative;}
.noise::before{content:'';position:absolute;inset:0;opacity:.02;pointer-events:none;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");}
@keyframes fadeUp{from{opacity:0;transform:translateY(14px);}to{opacity:1;transform:translateY(0);}}
@keyframes spin{from{transform:rotate(0deg);}to{transform:rotate(360deg);}}
@keyframes shimmer{0%{background-position:-200% 0;}100%{background-position:200% 0;}}
@keyframes pulse{0%,100%{opacity:1;}50%{opacity:.5;}}
.ai{animation:fadeUp .5s cubic-bezier(.16,1,.3,1) forwards;opacity:0;}
.d1{animation-delay:.08s;}.d2{animation-delay:.16s;}.d3{animation-delay:.24s;}.d4{animation-delay:.32s;}
.ch{transition:all .25s cubic-bezier(.16,1,.3,1);}
.ch:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(28,25,23,.08);border-color:${P.accent};}
.vc{transition:all .3s cubic-bezier(.16,1,.3,1);}
.vc:hover{transform:translateY(-3px) scale(1.02);}
.ai-btn{transition:all .2s;cursor:pointer;}
.ai-btn:hover{background:${P.accentLight} !important;border-color:${P.accent} !important;color:${P.accent} !important;}
`

export default function OnboardingPage() {
  const [step, setStep] = useState(0)
  const [website, setWebsite] = useState('')
  const [companyName, setCompanyName] = useState('')
  const [scanning, setScanning] = useState(false)
  const [scraped, setScraped] = useState<Scraped | null>(null)
  const [editField, setEditField] = useState<string | null>(null)
  const [editValues, setEditValues] = useState<Record<string, string>>({})
  const [aiLoading, setAiLoading] = useState<string | null>(null)
  const [teamSize, setTeamSize] = useState('')
  const [industry, setIndustry] = useState('')
  const [vibe, setVibe] = useState('')
  const [cta, setCta] = useState('')
  const [calendarLink, setCalendarLink] = useState('')
  const [phase, setPhase] = useState<Phase>('cards')
  const [messages, setMessages] = useState<Msg[]>([])
  const [userInput, setUserInput] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [playbook, setPlaybook] = useState<Playbook | null>(null)
  const [saving, setSaving] = useState(false)
  const [profileId, setProfileId] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [pbEdit, setPbEdit] = useState<string | null>(null)
  const [pbEdits, setPbEdits] = useState<Record<string, string>>({})
  const chatEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])
  useEffect(() => { if (phase === 'chat' && inputRef.current) inputRef.current.focus() }, [phase, messages])

  const totalCards = 7
  const getFormData = () => ({
    product_name: editValues.product_name || scraped?.product_name || companyName,
    product_description: editValues.product_description || scraped?.product_description || '',
    problem_solved: editValues.problem_solved || scraped?.problem_solved || '',
    key_differentiators: editValues.key_differentiators || scraped?.key_differentiators || '',
    company_size: teamSize, industry, target_roles: editValues.target_roles || scraped?.suggested_roles || '',
    tone: vibe, cta_type: cta, calendar_link: calendarLink,
  })

  /* ─── AI SUGGESTION ENGINE ─── */
  const getAiSuggestion = useCallback(async (fieldKey: string, prompt: string) => {
    setAiLoading(fieldKey)
    try {
      const res = await fetch('/api/training', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'chat',
          messages: [{ role: 'user', content: prompt }],
          companyName: editValues.product_name || scraped?.product_name || companyName || 'the company',
          formData: getFormData(),
        }),
      })
      const data = await res.json()
      if (data.message) {
        // Clean up — strip markdown bold, keep it plain
        const clean = data.message.replace(/\*\*(.*?)\*\*/g, '$1').replace(/^(Here|Sure|Of course|I'd suggest|Based on)[^:]*:\s*/i, '').trim()
        setEditValues(prev => ({ ...prev, [fieldKey]: clean }))
      }
    } catch { /* silent fail */ }
    setAiLoading(null)
  }, [companyName, scraped, editValues])

  /* ─── CHAT SUGGESTIONS — matched to Jamie's 3 questions ─── */
  const generateChatSuggestions = useCallback((jamieMsg: string, questionNumber: number) => {
    const lower = jamieMsg.toLowerCase()
    const sug: string[] = []

    // Q1: Objections — Jamie asks about pushback and how to handle it
    if (lower.includes('objection') || lower.includes('pushback') || lower.includes('concern') || lower.includes('hear') || questionNumber === 1) {
      sug.push(
        '"Too expensive" → We show ROI within 30 days and offer a free trial',
        '"We already have a solution" → We integrate with existing tools and add what they\'re missing',
        '"Not the right time" → We offer a light start so they can see value before committing',
      )
    }
    // Q2: Qualification — Jamie asks how to qualify leads and deal-breakers
    else if (lower.includes('qualif') || lower.includes('deal-break') || lower.includes('worth a meeting') || lower.includes('walk away') || questionNumber === 2) {
      sug.push(
        'Good fit: Has the problem we solve, has budget, decision-maker in the loop, timeline under 3 months',
        'Walk away: No budget, under 10 employees, already locked into a 2-year contract, no urgency',
        'Key questions: What are you using today? What\'s your timeline? Who else is involved in the decision?',
      )
    }
    // Q3: Special instructions — Jamie asks for anything else to know
    else if (lower.includes('anything else') || lower.includes('special') || lower.includes('competitor') || lower.includes('avoid') || questionNumber === 3) {
      sug.push(
        'Never mention competitor X by name. Focus on our speed and support.',
        'Always ask about their current stack before pitching. Lead with the integration story.',
        'Nothing else — I think you have everything you need!',
      )
    }
    // First message from Jamie (intro/greeting)
    else if (questionNumber === 0) {
      sug.push(
        'Ready! Ask me anything about our sales process.',
        'Let\'s do it — fire away with your questions.',
      )
    }
    // Completion message
    else if (lower.includes('🎉') || lower.includes('got everything') || lower.includes('playbook')) {
      setSuggestions([])
      return
    }
    // Fallback
    else {
      sug.push(
        'Here\'s what I know so far...',
        'Let me give you the details...',
      )
    }
    setSuggestions(sug)
  }, [])

  /* ─── SCAN ─── */
  const scanWebsite = async () => {
    if (!website.trim()) return
    setScanning(true); setError(null)
    try {
      const res = await fetch('/api/training', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'scrape_website', website }) })
      const data = await res.json()
      if (data.extracted) { setScraped(data.extracted); setCompanyName(data.extracted.product_name || '') }
      setTimeout(() => setStep(1), 400)
    } catch { setTimeout(() => setStep(1), 300) }
    setScanning(false)
  }

  /* ─── CHAT ─── */
  const startChat = async () => {
    setPhase('chat'); setIsTyping(true); setError(null)
    try {
      const res = await fetch('/api/training', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'chat',
          messages: [{ role: 'user', content: `Hi Jamie, I'm the founder of ${companyName || 'my company'}. Ready for your questions.` }],
          companyName: companyName || 'the company', formData: getFormData() }) })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      setMessages([{ role: 'jamie', content: data.message }])
      generateChatSuggestions(data.message, 0)
    } catch { setError('Failed to connect.') }
    setIsTyping(false)
  }

  const handleSend = async (text?: string) => {
    const msg = text || userInput
    if (!msg.trim() || isTyping) return
    const newMsgs: Msg[] = [...messages, { role: 'user', content: msg }]
    setMessages(newMsgs); setUserInput(''); setSuggestions([]); setIsTyping(true); setError(null)
    try {
      const res = await fetch('/api/training', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'chat', messages: newMsgs, companyName, formData: getFormData() }) })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      const updated: Msg[] = [...newMsgs, { role: 'jamie', content: data.message }]
      setMessages(updated)
      // Count how many Jamie messages there are (each = a question)
      const jamieCount = updated.filter(m => m.role === 'jamie').length
      generateChatSuggestions(data.message, jamieCount)
      if (data.message.includes('🎉') || data.message.toLowerCase().includes('got everything') || data.message.toLowerCase().includes('playbook now'))
        setTimeout(() => generatePlaybook(updated), 1500)
    } catch { setError('Failed to get response.') }
    setIsTyping(false)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend() } }

  const generatePlaybook = async (msgs: Msg[]) => {
    setIsTyping(true)
    try {
      const res = await fetch('/api/training', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'generate_playbook', messages: msgs, companyName, formData: getFormData() }) })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      setPlaybook(data.playbook); setPhase('review')
    } catch { setError('Failed to generate playbook.') }
    setIsTyping(false)
  }

  const savePlaybook = async () => {
    if (!playbook) return; setSaving(true); setError(null)
    const supabase = createClient()
    const fp = { ...playbook }
    Object.entries(pbEdits).forEach(([k, v]) => { if (k in fp) (fp as Record<string, unknown>)[k] = v })
    try {
      const { data: co, error: ce } = await supabase.from('companies').insert({ name: companyName || fp.product_name, domain: website }).select().single()
      if (ce) throw ce
      const { data: pr, error: pe } = await supabase.from('onboarding_profiles').insert({
        company_id: co.id, status: 'completed', ...fp, training_transcript: messages, uploaded_docs: [],
      }).select().single()
      if (pe) throw pe
      await supabase.from('digital_employees').insert({ company_id: co.id, name: 'Jamie', title: 'SDR — Sales Development Rep', department: 'Sales', category: 'sdr', status: 'active' })
      if (pr) setProfileId(pr.id)
    } catch { setError('Failed to save.') }
    setSaving(false)
  }

  /* ─── SHARED UI ─── */
  const Dots = () => {
    const cur = phase === 'cards' ? step : phase === 'chat' ? totalCards : totalCards + 1
    return (
      <div style={{ display: 'flex', gap: '3px', alignItems: 'center' }}>
        {Array.from({ length: totalCards + 1 }).map((_, i) => (
          <div key={i} style={{
            width: i === cur ? '18px' : '5px', height: '5px', borderRadius: '3px',
            background: i < cur ? P.accent : i === cur ? P.accent : P.border,
            opacity: i < cur ? .3 : 1, transition: 'all .5s cubic-bezier(.16,1,.3,1)',
          }} />
        ))}
      </div>
    )
  }

  const Nav = () => (
    <nav style={{
      position: 'sticky', top: 0, zIndex: 100, padding: '12px 24px',
      background: 'rgba(250,249,247,.85)', backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)',
      borderBottom: `1px solid ${P.borderSubtle}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    }}>
      <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: '8px', textDecoration: 'none', color: P.text }}>
        <div style={{ width: '28px', height: '28px', borderRadius: '8px', background: P.gradient, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: '13px', fontWeight: 800 }}>J</div>
        <span className="fd" style={{ fontSize: '15px', fontWeight: 800, letterSpacing: '-.03em' }}>jamie<span style={{ color: P.textTer, fontWeight: 500 }}>@</span>work</span>
      </Link>
      <Dots />
    </nav>
  )

  const Shell = ({ children, title, sub }: { children: React.ReactNode; title: string; sub: string }) => (
    <div className="noise" style={{ minHeight: '100vh', background: P.bg }}>
      <style dangerouslySetInnerHTML={{ __html: CSS }} />
      <Nav />
      {error && <div className="fb" style={{ padding: '8px 24px', background: '#FEF2F2', borderBottom: '1px solid #FECACA', textAlign: 'center', fontSize: '12px', color: P.danger }}>{error}</div>}
      <div style={{ maxWidth: '520px', margin: '0 auto', padding: '52px 20px 48px', display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}>
        <h1 className="fd ai" style={{ fontSize: '30px', fontWeight: 800, color: P.text, letterSpacing: '-.04em', margin: '0 0 8px', lineHeight: 1.1 }}>{title}</h1>
        <p className="fb ai d1" style={{ fontSize: '14px', color: P.textSec, margin: '0 0 36px', lineHeight: 1.6, maxWidth: '400px', fontWeight: 500 }}>{sub}</p>
        {children}
      </div>
    </div>
  )

  const Back = ({ onClick }: { onClick: () => void }) => (
    <button onClick={onClick} className="fb" style={{ marginTop: '20px', background: 'none', border: 'none', color: P.textTer, fontSize: '12px', cursor: 'pointer', fontWeight: 500 }}>← Back</button>
  )

  /* AI Suggest Button */
  const AiBtn = ({ fieldKey, prompt, label }: { fieldKey: string; prompt: string; label?: string }) => (
    <button onClick={() => getAiSuggestion(fieldKey, prompt)}
      disabled={aiLoading === fieldKey}
      className="ai-btn fm"
      style={{
        fontSize: '10px', padding: '4px 10px', borderRadius: '6px',
        border: `1px solid ${P.border}`, background: 'white', color: P.textSec,
        fontWeight: 600, letterSpacing: '.02em', display: 'inline-flex', alignItems: 'center', gap: '4px',
      }}>
      {aiLoading === fieldKey ? <span style={{ animation: 'spin .8s linear infinite', display: 'inline-block' }}>⟳</span> : '✨'}
      {label || 'AI Suggest'}
    </button>
  )

  /* ─── STEP 0: WEBSITE ─── */
  if (phase === 'cards' && step === 0) return (
    <Shell title="What's your website?" sub="Jamie reads your site and fills in everything she can.">
      <div className="ai d2" style={{ width: '100%' }}>
        <div style={{
          display: 'flex', gap: '6px', padding: '4px', borderRadius: '14px',
          background: P.bgCard, border: `2px solid ${scanning ? P.accent : P.border}`,
          boxShadow: scanning ? `0 0 0 3px ${P.accentLight}` : '0 1px 4px rgba(28,25,23,.03)',
          transition: 'all .3s',
        }}>
          <div className="fm" style={{ display: 'flex', alignItems: 'center', paddingLeft: '14px', color: P.textTer, fontSize: '12px', fontWeight: 500 }}>https://</div>
          <input type="text" value={website} onChange={e => setWebsite(e.target.value)}
            placeholder="yourcompany.com" onKeyDown={e => e.key === 'Enter' && scanWebsite()} autoFocus
            className="fb" style={{ flex: 1, padding: '13px 0', background: 'none', border: 'none', outline: 'none', color: P.text, fontSize: '15px', fontWeight: 500 }} />
          <button onClick={scanWebsite} disabled={scanning || !website.trim()} className="fb"
            style={{
              padding: '10px 20px', borderRadius: '10px', border: 'none',
              background: scanning ? P.bgWash : P.gradient,
              color: scanning ? P.textSec : 'white',
              fontSize: '13px', fontWeight: 700, cursor: website.trim() && !scanning ? 'pointer' : 'default',
              transition: 'all .2s', display: 'flex', alignItems: 'center', gap: '5px',
            }}>
            {scanning ? <><span style={{ display: 'inline-block', animation: 'spin 1s linear infinite' }}>⟳</span> Reading...</> : '🔍 Scan'}
          </button>
        </div>
        <button onClick={() => setStep(1)} className="fb"
          style={{ marginTop: '16px', background: 'none', border: 'none', color: P.textTer, fontSize: '12px', cursor: 'pointer', textDecoration: 'underline', textUnderlineOffset: '3px', fontWeight: 500 }}>
          Skip — I&apos;ll fill it in myself
        </button>
      </div>
    </Shell>
  )

  /* ─── STEP 1: WHAT JAMIE LEARNED — with AI buttons ─── */
  if (phase === 'cards' && step === 1) {
    const fields = [
      { key: 'product_name', label: 'PRODUCT', value: scraped?.product_name || '', placeholder: 'Your product name', aiPrompt: `Suggest a concise product name for a company with website ${website}` },
      { key: 'product_description', label: 'WHAT YOU SELL', value: scraped?.product_description || '', placeholder: 'Describe in 1–2 sentences', aiPrompt: `Write a 1-2 sentence product description for ${editValues.product_name || scraped?.product_name || 'this product'} based on what we know: ${scraped?.product_description || 'no details yet'}. Be concise and compelling.` },
      { key: 'problem_solved', label: 'PROBLEM YOU SOLVE', value: scraped?.problem_solved || '', placeholder: 'The core pain point', aiPrompt: `What's the core problem that ${editValues.product_name || scraped?.product_name || 'this product'} solves? Product: ${editValues.product_description || scraped?.product_description || 'unknown'}. Write 1-2 sentences about the pain point.` },
      { key: 'key_differentiators', label: 'YOUR EDGE', value: scraped?.key_differentiators || '', placeholder: 'What makes you different', aiPrompt: `List 2-3 key differentiators for ${editValues.product_name || scraped?.product_name || 'this product'} vs competitors. Product: ${editValues.product_description || scraped?.product_description || 'unknown'}. Be specific and brief.` },
    ]
    return (
      <Shell title={scraped ? "Here's what Jamie found" : "Tell Jamie about your product"} sub={scraped ? "Click any field to edit. Use ✨ AI Suggest to fill gaps." : "Fill in the basics or let AI help."}>
        <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {fields.map((f, i) => (
            <div key={f.key} className={`ai d${i + 1}`}
              style={{
                padding: '12px 16px', borderRadius: '12px', background: P.bgCard, textAlign: 'left',
                border: `1.5px solid ${editField === f.key ? P.borderFocus : P.border}`,
                boxShadow: editField === f.key ? `0 0 0 3px ${P.accentLight}` : '0 1px 3px rgba(28,25,23,.02)',
                transition: 'all .2s',
              }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
                <div className="fm" style={{ fontSize: '9px', fontWeight: 700, color: P.textTer, letterSpacing: '.08em' }}>{f.label}</div>
                <AiBtn fieldKey={f.key} prompt={f.aiPrompt} />
              </div>
              {editField === f.key ? (
                <textarea autoFocus value={editValues[f.key] ?? f.value}
                  onChange={e => setEditValues(p => ({ ...p, [f.key]: e.target.value }))}
                  onBlur={() => setEditField(null)}
                  rows={2} className="fb"
                  style={{ width: '100%', background: P.accentLight, border: `1px solid ${P.accentBorder}`, borderRadius: '6px', padding: '6px 10px', color: P.text, fontSize: '13px', lineHeight: 1.6, resize: 'none', outline: 'none', fontWeight: 500 }} />
              ) : (
                <div onClick={() => setEditField(f.key)} className="fb"
                  style={{
                    fontSize: '13px', color: (editValues[f.key] || f.value) ? P.text : P.textTer,
                    lineHeight: 1.6, cursor: 'text', padding: '2px 0', fontWeight: 500,
                    borderBottom: '1px dashed transparent', transition: 'border-color .2s',
                  }}
                  onMouseEnter={e => e.currentTarget.style.borderBottomColor = P.border}
                  onMouseLeave={e => e.currentTarget.style.borderBottomColor = 'transparent'}>
                  {editValues[f.key] || f.value || f.placeholder}
                </div>
              )}
            </div>
          ))}
          <button onClick={() => { setCompanyName(editValues.product_name || scraped?.product_name || companyName); setStep(2) }}
            className="fb ai d4"
            style={{ marginTop: '6px', padding: '13px', borderRadius: '12px', border: 'none', background: P.gradient, color: 'white', fontSize: '14px', fontWeight: 700, cursor: 'pointer', boxShadow: '0 3px 12px rgba(13,148,136,.25)' }}>
            Looks good →
          </button>
          <Back onClick={() => setStep(0)} />
        </div>
      </Shell>
    )
  }

  /* ─── STEP 2: TEAM SIZE ─── */
  if (phase === 'cards' && step === 2) {
    const sizes = [
      { label: 'Just me', icon: '👤', v: '1' }, { label: '2–10', icon: '👥', v: '2-10' },
      { label: '11–50', icon: '🏢', v: '11-50' }, { label: '51–200', icon: '🏙️', v: '51-200' },
      { label: '200+', icon: '🌆', v: '200+' },
    ]
    return (
      <Shell title="How big is your team?" sub="Jamie calibrates her pitch based on your stage.">
        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', justifyContent: 'center' }}>
          {sizes.map((s, i) => (
            <button key={s.v} onClick={() => { setTeamSize(s.v); setStep(3) }}
              className={`ch fb ai d${i + 1}`}
              style={{ width: '88px', padding: '18px 6px', borderRadius: '14px', background: P.bgCard, border: `1.5px solid ${P.border}`, boxShadow: '0 1px 4px rgba(28,25,23,.03)', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px', color: P.text }}>
              <span style={{ fontSize: '26px' }}>{s.icon}</span>
              <span style={{ fontSize: '12px', fontWeight: 600 }}>{s.label}</span>
            </button>
          ))}
        </div>
        <Back onClick={() => setStep(1)} />
      </Shell>
    )
  }

  /* ─── STEP 3: INDUSTRY ─── */
  if (phase === 'cards' && step === 3) {
    const inds = [
      { l: 'SaaS', i: '💻' }, { l: 'Fintech', i: '🏦' }, { l: 'Health', i: '🏥' }, { l: 'E-comm', i: '🛒' },
      { l: 'Agency', i: '🎨' }, { l: 'Education', i: '📚' }, { l: 'AI / ML', i: '🤖' }, { l: 'Other', i: '✨' },
    ]
    return (
      <Shell title="Your industry?" sub="Helps Jamie speak the right language.">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px', width: '100%', maxWidth: '380px' }}>
          {inds.map((ind, i) => (
            <button key={ind.l} onClick={() => { setIndustry(ind.l); setStep(4) }}
              className={`ch fb ai d${(i % 4) + 1}`}
              style={{ padding: '16px 6px', borderRadius: '14px', background: P.bgCard, border: `1.5px solid ${P.border}`, boxShadow: '0 1px 3px rgba(28,25,23,.02)', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px', color: P.text }}>
              <span style={{ fontSize: '22px' }}>{ind.i}</span>
              <span style={{ fontSize: '11px', fontWeight: 600 }}>{ind.l}</span>
            </button>
          ))}
        </div>
        <Back onClick={() => setStep(2)} />
      </Shell>
    )
  }

  /* ─── STEP 4: VIBE ─── */
  if (phase === 'cards' && step === 4) {
    const vibes = [
      { label: 'Chill', emoji: '🌊', sub: '"Hey! Love what you\'re building..."', g: P.gradient },
      { label: 'Sharp', emoji: '⚡', sub: '"You\'re leaving money on the table."', g: P.gradientPurple },
      { label: 'Warm', emoji: '☀️', sub: '"I\'d love to learn about your team..."', g: P.gradientWarm },
      { label: 'Nerdy', emoji: '🤓', sub: '"Based on your stack and growth..."', g: P.gradientBlue },
    ]
    return (
      <Shell title="Pick Jamie's personality" sub="Hover to preview how she sounds.">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', width: '100%', maxWidth: '400px' }}>
          {vibes.map((v, i) => (
            <button key={v.label} onClick={() => { setVibe(v.label); setStep(5) }}
              className={`vc fb ai d${i + 1}`}
              style={{ padding: '22px 16px', borderRadius: '16px', textAlign: 'left', background: P.bgCard, border: `1.5px solid ${P.border}`, boxShadow: '0 1px 4px rgba(28,25,23,.03)', cursor: 'pointer', color: P.text, position: 'relative', overflow: 'hidden' }}
              onMouseEnter={e => { e.currentTarget.style.background = v.g; e.currentTarget.style.color = 'white'; e.currentTarget.style.borderColor = 'transparent'; e.currentTarget.style.boxShadow = '0 12px 32px rgba(0,0,0,.15)' }}
              onMouseLeave={e => { e.currentTarget.style.background = P.bgCard; e.currentTarget.style.color = P.text; e.currentTarget.style.borderColor = P.border; e.currentTarget.style.boxShadow = '0 1px 4px rgba(28,25,23,.03)' }}>
              <div style={{ fontSize: '26px', marginBottom: '8px' }}>{v.emoji}</div>
              <div className="fd" style={{ fontSize: '16px', fontWeight: 800, marginBottom: '4px', letterSpacing: '-.02em' }}>{v.label}</div>
              <div style={{ fontSize: '11px', opacity: .7, lineHeight: 1.4, fontStyle: 'italic', fontWeight: 500 }}>{v.sub}</div>
            </button>
          ))}
        </div>
        <Back onClick={() => setStep(3)} />
      </Shell>
    )
  }

  /* ─── STEP 5: CTA ─── */
  if (phase === 'cards' && step === 5) {
    const ctas = [
      { l: 'Book a demo', i: '📅', c: P.accent }, { l: 'Start free trial', i: '🚀', c: '#7C3AED' },
      { l: 'Schedule a call', i: '📞', c: '#2563EB' }, { l: 'Get a quote', i: '💰', c: P.warning },
    ]
    return (
      <Shell title="What's the goal?" sub="Every qualified conversation ends with...">
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', width: '100%', maxWidth: '360px' }}>
          {ctas.map((c, i) => (
            <button key={c.l} onClick={() => { setCta(c.l); setStep(6) }}
              className={`ch fb ai d${i + 1}`}
              style={{ padding: '14px 18px', borderRadius: '12px', background: P.bgCard, border: `1.5px solid ${P.border}`, boxShadow: '0 1px 3px rgba(28,25,23,.02)', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '12px', color: P.text, textAlign: 'left' }}>
              <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: `${c.c}10`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '20px', flexShrink: 0 }}>{c.i}</div>
              <span style={{ fontSize: '14px', fontWeight: 700 }}>{c.l}</span>
            </button>
          ))}
        </div>
        <Back onClick={() => setStep(4)} />
      </Shell>
    )
  }

  /* ─── STEP 6: CALENDAR ─── */
  if (phase === 'cards' && step === 6) return (
    <Shell title="Drop your calendar link" sub="Jamie sends qualified leads here to book time.">
      <div className="ai d2" style={{ width: '100%', maxWidth: '400px' }}>
        <div style={{ display: 'flex', gap: '6px', padding: '4px', borderRadius: '14px', background: P.bgCard, border: `2px solid ${P.border}`, boxShadow: '0 1px 4px rgba(28,25,23,.03)' }}>
          <div style={{ display: 'flex', alignItems: 'center', paddingLeft: '14px', fontSize: '16px' }}>📅</div>
          <input type="text" value={calendarLink} onChange={e => setCalendarLink(e.target.value)}
            placeholder="calendly.com/you" autoFocus className="fb"
            style={{ flex: 1, padding: '13px 0', background: 'none', border: 'none', outline: 'none', color: P.text, fontSize: '15px', fontWeight: 500 }} />
        </div>
        <button onClick={startChat} className="fb"
          style={{ marginTop: '16px', width: '100%', padding: '13px', borderRadius: '12px', border: 'none', background: P.gradient, color: 'white', fontSize: '14px', fontWeight: 700, cursor: 'pointer', boxShadow: '0 3px 12px rgba(13,148,136,.25)' }}>
          Almost done — 3 quick questions →
        </button>
        <button onClick={() => { setCalendarLink(''); startChat() }} className="fb"
          style={{ marginTop: '10px', background: 'none', border: 'none', color: P.textTer, fontSize: '12px', cursor: 'pointer', textDecoration: 'underline', textUnderlineOffset: '3px', fontWeight: 500 }}>
          Skip for now
        </button>
        <Back onClick={() => setStep(5)} />
      </div>
    </Shell>
  )

  /* ─── CHAT — with suggestion pills ─── */
  if (phase === 'chat') return (
    <div className="noise" style={{ minHeight: '100vh', background: P.bg, display: 'flex', flexDirection: 'column' }}>
      <style dangerouslySetInnerHTML={{ __html: CSS }} />
      <Nav />
      {error && <div className="fb" style={{ padding: '8px 24px', background: '#FEF2F2', borderBottom: '1px solid #FECACA', textAlign: 'center', fontSize: '12px', color: P.danger }}>{error}</div>}
      <div style={{ padding: '10px 24px', borderBottom: `1px solid ${P.borderSubtle}`, background: P.bgCard }}>
        <div style={{ maxWidth: '660px', margin: '0 auto', display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={{ width: '34px', height: '34px', borderRadius: '9px', background: P.gradient, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: '16px' }}>🤖</div>
          <div>
            <div className="fd" style={{ fontWeight: 700, fontSize: '13px', color: P.text, letterSpacing: '-.01em' }}>Jamie — Quick Questions</div>
            <div className="fb" style={{ fontSize: '11px', color: P.textTer, fontWeight: 500 }}>3 questions to finish training for {companyName || 'your company'}</div>
          </div>
        </div>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: '20px 24px' }}>
        <div style={{ maxWidth: '660px', margin: '0 auto' }}>
          {messages.map((msg, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start', marginBottom: '12px' }}>
              <div className="fb" style={{
                maxWidth: '78%', padding: '12px 16px',
                borderRadius: msg.role === 'user' ? '14px 14px 4px 14px' : '14px 14px 14px 4px',
                background: msg.role === 'user' ? P.accent : P.bgCard,
                color: msg.role === 'user' ? 'white' : P.text,
                border: msg.role === 'user' ? 'none' : `1px solid ${P.border}`,
                boxShadow: '0 1px 3px rgba(28,25,23,.03)', fontSize: '13px', lineHeight: 1.6, fontWeight: 500,
              }}>
                <span dangerouslySetInnerHTML={{ __html: msg.content.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>') }} />
              </div>
            </div>
          ))}
          {isTyping && <div style={{ display: 'flex', marginBottom: '12px' }}><div className="fb" style={{ padding: '12px 16px', borderRadius: '14px 14px 14px 4px', background: P.bgCard, border: `1px solid ${P.border}`, fontSize: '13px', color: P.textTer, fontWeight: 500 }}>Jamie is thinking...</div></div>}
          <div ref={chatEndRef} />
        </div>
      </div>
      {/* Suggestion cards */}
      {suggestions.length > 0 && !isTyping && (
        <div style={{ padding: '8px 24px 4px', background: P.bg }}>
          <div style={{ maxWidth: '660px', margin: '0 auto' }}>
            <div className="fm" style={{ fontSize: '9px', color: P.textTer, marginBottom: '6px', letterSpacing: '.06em', fontWeight: 600 }}>✨ SUGGESTED RESPONSES</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
              {suggestions.map((s, i) => (
                <button key={i} onClick={() => handleSend(s)} className="fb ai-btn"
                  style={{
                    padding: '10px 14px', borderRadius: '10px',
                    border: `1px solid ${P.border}`, background: 'white',
                    color: P.textMd, fontSize: '13px', fontWeight: 500,
                    cursor: 'pointer', textAlign: 'left', lineHeight: 1.5,
                    width: '100%', whiteSpace: 'normal', wordBreak: 'break-word',
                  }}>
                  {s}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
      <div style={{ padding: '12px 24px', borderTop: `1px solid ${P.borderSubtle}`, background: P.bgCard }}>
        <div style={{ maxWidth: '660px', margin: '0 auto', display: 'flex', gap: '8px' }}>
          <textarea ref={inputRef} value={userInput} onChange={e => setUserInput(e.target.value)} onKeyDown={handleKeyDown}
            placeholder="Type your answer... (Enter to send)" rows={2} className="fb"
            style={{ flex: 1, padding: '10px 14px', borderRadius: '10px', border: `1.5px solid ${P.border}`, background: P.bg, color: P.text, fontSize: '13px', resize: 'none', outline: 'none', lineHeight: 1.5, fontWeight: 500 }}
            onFocus={e => e.currentTarget.style.borderColor = P.accent} onBlur={e => e.currentTarget.style.borderColor = P.border} />
          <button onClick={() => handleSend()} disabled={!userInput.trim() || isTyping} className="fb"
            style={{ alignSelf: 'flex-end', padding: '10px 18px', borderRadius: '10px', background: userInput.trim() && !isTyping ? P.gradient : P.bgWash, border: 'none', color: userInput.trim() && !isTyping ? 'white' : P.textTer, fontSize: '13px', fontWeight: 700, cursor: userInput.trim() && !isTyping ? 'pointer' : 'default' }}>Send</button>
        </div>
      </div>
    </div>
  )

  /* ─── REVIEW — inline editing fixed ─── */
  if (phase === 'review' && playbook) {

    // Editable field — using state directly instead of component recreation
    const renderField = (label: string, fk: string, value: string) => {
      const isEditing = pbEdit === fk
      const displayValue = pbEdits[fk] ?? value

      const startEdit = () => setPbEdit(fk)
      const stopEdit = () => {
        // Small delay to allow AI button click to register before closing
        setTimeout(() => {
          setPbEdit(prev => prev === fk ? null : prev)
        }, 150)
      }
      const handleChange = (newVal: string) => setPbEdits(p => ({ ...p, [fk]: newVal }))

      const runAiImprove = async () => {
        setAiLoading(`pb_${fk}`)
        try {
          const res = await fetch('/api/training', { method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'chat',
              messages: [{ role: 'user', content: `Improve this ${label.toLowerCase()} for a sales playbook: "${displayValue}". Product: ${playbook.product_name}. Return ONLY the improved text, no preamble.` }],
              companyName, formData: getFormData() }) })
          const data = await res.json()
          if (data.message) {
            const clean = data.message.replace(/\*\*(.*?)\*\*/g, '$1').replace(/^(Here|Sure|Of course|I'd suggest|Based on)[^:]*:\s*/i, '').trim()
            setPbEdits(p => ({ ...p, [fk]: clean }))
          }
        } catch {}
        setAiLoading(null)
      }

      return (
        <div key={fk} style={{ marginBottom: '10px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '3px' }}>
            <div className="fm" style={{ fontSize: '9px', color: P.textTer, letterSpacing: '.06em', textTransform: 'uppercase', fontWeight: 700 }}>{label}</div>
            <button onClick={runAiImprove} disabled={aiLoading === `pb_${fk}`}
              className="ai-btn fm"
              style={{
                fontSize: '10px', padding: '4px 10px', borderRadius: '6px',
                border: `1px solid ${P.border}`, background: 'white', color: P.textSec,
                fontWeight: 600, letterSpacing: '.02em', display: 'inline-flex', alignItems: 'center', gap: '4px', cursor: 'pointer',
              }}>
              {aiLoading === `pb_${fk}` ? <span style={{ animation: 'spin .8s linear infinite', display: 'inline-block' }}>⟳</span> : '✨'}
              Improve
            </button>
          </div>
          {isEditing ? (
            <textarea autoFocus value={displayValue}
              onChange={e => handleChange(e.target.value)}
              onBlur={stopEdit}
              onKeyDown={e => { if (e.key === 'Escape') setPbEdit(null) }}
              rows={Math.max(2, Math.ceil((displayValue || '').length / 60))}
              className="fb"
              style={{
                width: '100%', background: P.accentLight,
                border: `1.5px solid ${P.accentBorder}`, borderRadius: '8px',
                padding: '8px 10px', color: P.text, fontSize: '13px',
                lineHeight: 1.6, resize: 'vertical', outline: 'none', fontWeight: 500,
                minHeight: '60px',
              }} />
          ) : (
            <div onClick={startEdit} className="fb"
              style={{
                fontSize: '13px', color: displayValue ? P.text : P.textTer,
                lineHeight: 1.6, cursor: 'text', padding: '6px 10px',
                fontWeight: 500, borderRadius: '8px',
                border: '1px dashed transparent',
                background: 'transparent',
                transition: 'all .15s',
              }}
              onMouseEnter={e => {
                e.currentTarget.style.border = `1px dashed ${P.border}`
                e.currentTarget.style.background = P.bgWash
              }}
              onMouseLeave={e => {
                e.currentTarget.style.border = '1px dashed transparent'
                e.currentTarget.style.background = 'transparent'
              }}>
              {displayValue || '(click to add)'}
            </div>
          )}
        </div>
      )
    }

    return (
      <div className="noise" style={{ minHeight: '100vh', background: P.bg }}>
        <style dangerouslySetInnerHTML={{ __html: CSS }} />
        <Nav />
        {error && <div className="fb" style={{ padding: '8px 24px', background: '#FEF2F2', borderBottom: '1px solid #FECACA', textAlign: 'center', fontSize: '12px', color: P.danger }}>{error}</div>}
        <div style={{ maxWidth: '700px', margin: '0 auto', padding: '32px 20px 64px' }}>
          <h1 className="fd" style={{ fontSize: '26px', fontWeight: 800, color: P.text, letterSpacing: '-.03em', margin: '0 0 4px' }}>Jamie&apos;s Sales Playbook</h1>
          <p className="fb" style={{ fontSize: '13px', color: P.textSec, margin: '0 0 6px', fontWeight: 500 }}>Click any field to edit. Use ✨ Improve for AI refinement.</p>
          <div className="fm" style={{ fontSize: '10px', color: P.accent, marginBottom: '24px', background: P.accentLight, display: 'inline-block', padding: '3px 10px', borderRadius: '5px', border: `1px solid ${P.accentBorder}`, fontWeight: 600 }}>✎ All fields are editable — click text or press Escape to close</div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {/* THE PITCH */}
            <div style={{ padding: '16px 20px', borderRadius: '14px', background: P.bgCard, border: `1px solid ${P.border}`, boxShadow: '0 1px 3px rgba(28,25,23,.02)', textAlign: 'left' }}>
              <div className="fm" style={{ fontSize: '10px', fontWeight: 700, color: P.accent, marginBottom: '10px', letterSpacing: '.06em' }}>THE PITCH</div>
              {renderField('Product', 'product_name', playbook.product_name)}
              {renderField('Description', 'product_description', playbook.product_description)}
              {renderField('Problem', 'problem_solved', playbook.problem_solved)}
              {renderField('Edge', 'key_differentiators', playbook.key_differentiators)}
            </div>

            {/* IDEAL CUSTOMER */}
            <div style={{ padding: '16px 20px', borderRadius: '14px', background: P.bgCard, border: `1px solid ${P.border}`, boxShadow: '0 1px 3px rgba(28,25,23,.02)', textAlign: 'left' }}>
              <div className="fm" style={{ fontSize: '10px', fontWeight: 700, color: P.accent, marginBottom: '10px', letterSpacing: '.06em' }}>IDEAL CUSTOMER</div>
              {renderField('Size', 'target_company_size', playbook.target_company_size)}
              {renderField('Industries', 'target_industries', playbook.target_industries)}
              {renderField('Buyers', 'target_roles', playbook.target_roles)}
              {renderField('Signals', 'icp_signals', playbook.icp_signals)}
            </div>

            {/* QUALIFICATION */}
            <div style={{ padding: '16px 20px', borderRadius: '14px', background: P.bgCard, border: `1px solid ${P.border}`, boxShadow: '0 1px 3px rgba(28,25,23,.02)', textAlign: 'left' }}>
              <div className="fm" style={{ fontSize: '10px', fontWeight: 700, color: P.accent, marginBottom: '10px', letterSpacing: '.06em' }}>QUALIFICATION</div>
              {playbook.qualification_questions.map((q, i) => (
                <div key={i} className="fb" style={{ padding: '8px 12px', borderRadius: '8px', marginBottom: '4px', background: P.bgWash, border: `1px solid ${P.borderSubtle}`, fontSize: '12px', color: P.text, lineHeight: 1.5, fontWeight: 500 }}>
                  <span className="fm" style={{ color: P.accent, fontWeight: 700, marginRight: '6px', fontSize: '11px' }}>{i + 1}.</span>{q}
                </div>
              ))}
              {renderField('Walk away when', 'disqualification_criteria', playbook.disqualification_criteria)}
            </div>

            {/* OBJECTIONS */}
            <div style={{ padding: '16px 20px', borderRadius: '14px', background: P.bgCard, border: `1px solid ${P.border}`, boxShadow: '0 1px 3px rgba(28,25,23,.02)', textAlign: 'left' }}>
              <div className="fm" style={{ fontSize: '10px', fontWeight: 700, color: P.accent, marginBottom: '10px', letterSpacing: '.06em' }}>OBJECTIONS</div>
              {playbook.objection_playbook.map((obj, i) => (
                <div key={i} style={{ padding: '10px 14px', borderRadius: '10px', marginBottom: '8px', background: P.bgWash, border: `1px solid ${P.borderSubtle}` }}>
                  <div className="fb" style={{ fontSize: '12px', fontWeight: 700, color: P.warning, marginBottom: '4px' }}>&ldquo;{obj.objection}&rdquo;</div>
                  <div className="fb" style={{ fontSize: '12px', color: P.textSec, lineHeight: 1.5, fontWeight: 500 }}>→ {obj.response}</div>
                </div>
              ))}
            </div>

            {/* STYLE & CTA */}
            <div style={{ padding: '16px 20px', borderRadius: '14px', background: P.bgCard, border: `1px solid ${P.border}`, boxShadow: '0 1px 3px rgba(28,25,23,.02)', textAlign: 'left' }}>
              <div className="fm" style={{ fontSize: '10px', fontWeight: 700, color: P.accent, marginBottom: '10px', letterSpacing: '.06em' }}>STYLE & CTA</div>
              {renderField('Voice', 'voice_style', playbook.voice_style)}
              {renderField('Call to action', 'call_to_action', playbook.call_to_action)}
              {renderField('Calendar', 'calendar_link', playbook.calendar_link)}
            </div>

            {/* ACTIONS */}
            <div style={{ display: 'flex', gap: '8px', marginTop: '6px' }}>
              <button onClick={savePlaybook} disabled={saving || !!profileId} className="fb"
                style={{ flex: 1, padding: '14px', borderRadius: '12px', border: 'none', background: profileId ? P.success : saving ? P.bgWash : P.gradient, color: 'white', fontSize: '15px', fontWeight: 700, cursor: saving || profileId ? 'default' : 'pointer', boxShadow: '0 3px 12px rgba(13,148,136,.25)' }}>
                {profileId ? '✓ Jamie is Live!' : saving ? 'Deploying...' : 'Approve & Deploy Jamie →'}
              </button>
              <button onClick={() => { setPhase('cards'); setStep(0); setMessages([]); setPlaybook(null); setPbEdits({}); setPbEdit(null) }} className="fb"
                style={{ padding: '14px 20px', borderRadius: '12px', background: P.bgCard, border: `1.5px solid ${P.border}`, color: P.textSec, fontSize: '13px', fontWeight: 600, cursor: 'pointer' }}>Start Over</button>
            </div>

            {profileId && (
              <div style={{ padding: '16px', borderRadius: '14px', textAlign: 'center', background: P.accentLight, border: `1px solid ${P.accentBorder}` }}>
                <div className="fd" style={{ fontSize: '15px', fontWeight: 800, color: P.accent, marginBottom: '8px', letterSpacing: '-.02em' }}>🎉 Jamie is deployed and selling for {companyName}!</div>
                <Link href="/dashboard" className="fb" style={{ display: 'inline-block', padding: '8px 20px', borderRadius: '9px', background: P.gradient, color: 'white', fontSize: '13px', fontWeight: 700, textDecoration: 'none' }}>Go to Dashboard →</Link>
              </div>
            )}
          </div>
        </div>
      </div>
    )
  }

  return null
}
