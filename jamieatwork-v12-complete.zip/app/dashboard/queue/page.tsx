'use client'

import { useState, useEffect, useCallback } from 'react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'

interface Task {
  id: string; type: string; status: string; subject: string | null; body: string
  channel: string; edited_body: string | null; created_at: string
  lead: { name: string | null; email: string | null; company_name: string | null } | null
}

const P = {
  bg: '#FFFBF9', bgWash: '#FFF5F7', bgCard: '#FFFFFF',
  border: '#E8E5DF', borderRose: '#F9D4DC', borderFocus: '#0D9488',
  text: '#1C1917', textMd: '#57534E', textSec: '#78716C', textTer: '#A8A29E',
  accent: '#0D9488', accentLight: '#F0FDFA', accentBorder: '#99F6E4',
  rose: '#F472B6', roseLight: '#FFF5F7', roseBorder: '#F9D4DC',
  gradient: 'linear-gradient(135deg,#0D9488,#06B6D4)',
  danger: '#DC2626', warning: '#EA580C', success: '#16A34A',
}

const CSS = `
@import url('https://api.fontshare.com/v2/css?f[]=satoshi@500,700,800,900&display=swap');
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&display=swap');
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&display=swap');
*{box-sizing:border-box;margin:0;padding:0;}
.fd{font-family:'Satoshi',-apple-system,sans-serif;}
.fb{font-family:'DM Sans',-apple-system,sans-serif;}
.fm{font-family:'JetBrains Mono',monospace;}
textarea:focus{border-color:${P.borderFocus} !important;box-shadow:0 0 0 3px ${P.accentLight} !important;}
`

export default function QueuePage() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [loading, setLoading] = useState(true)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editBody, setEditBody] = useState('')
  const [filter, setFilter] = useState<'all' | 'pending_review' | 'approved' | 'rejected'>('pending_review')
  const [success, setSuccess] = useState<string | null>(null)

  const supabase = createClient()

  const fetchTasks = useCallback(async () => {
    let query = supabase.from('tasks').select('*, lead:leads(name, email, company_name)').order('created_at', { ascending: false })
    if (filter !== 'all') query = query.eq('status', filter)
    const { data } = await query.limit(50)
    if (data) setTasks(data as Task[])
    setLoading(false)
  }, [filter])

  useEffect(() => { fetchTasks() }, [fetchTasks])

  const approve = async (id: string, editedBody?: string) => {
    await supabase.from('tasks').update({
      status: 'approved',
      edited_body: editedBody || null,
      reviewed_at: new Date().toISOString(),
    }).eq('id', id)
    setEditingId(null)
    setSuccess('Approved!'); setTimeout(() => setSuccess(null), 2000)
    fetchTasks()
  }

  const reject = async (id: string) => {
    await supabase.from('tasks').update({
      status: 'rejected',
      reviewed_at: new Date().toISOString(),
    }).eq('id', id)
    setSuccess('Rejected'); setTimeout(() => setSuccess(null), 2000)
    fetchTasks()
  }

  const startEdit = (task: Task) => {
    setEditingId(task.id)
    setEditBody(task.edited_body || task.body)
  }

  const typeLabel = (t: string) => {
    const m: Record<string, { label: string; color: string; bg: string }> = {
      outbound: { label: 'Outbound', color: '#2563EB', bg: '#EFF6FF' },
      inbound_reply: { label: 'Inbound', color: '#7C3AED', bg: '#F5F3FF' },
      follow_up: { label: 'Follow-up', color: P.warning, bg: '#FFF7ED' },
    }
    return m[t] || m.outbound
  }

  const statusLabel = (s: string) => {
    const m: Record<string, { label: string; color: string; bg: string; border: string }> = {
      draft: { label: 'Draft', color: P.textTer, bg: '#F5F3EE', border: P.border },
      pending_review: { label: 'Needs Review', color: P.warning, bg: '#FFF7ED', border: '#FED7AA' },
      approved: { label: 'Approved', color: P.accent, bg: P.accentLight, border: P.accentBorder },
      rejected: { label: 'Rejected', color: P.danger, bg: '#FEF2F2', border: '#FECACA' },
      sent: { label: 'Sent', color: P.success, bg: '#F0FDF4', border: '#BBF7D0' },
    }
    return m[s] || m.draft
  }

  const pendingCount = tasks.filter(t => t.status === 'pending_review').length

  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: CSS }} />
      <div style={{ minHeight: '100vh', background: P.bg, color: P.text }}>
        {/* Nav */}
        <nav style={{ position: 'sticky', top: 0, zIndex: 100, padding: '12px 24px', background: 'rgba(255,251,249,.88)', backdropFilter: 'blur(20px)', borderBottom: `1px solid ${P.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <Link href="/dashboard" style={{ display: 'flex', alignItems: 'center', gap: '8px', textDecoration: 'none', color: P.text }}>
              <div style={{ width: '28px', height: '28px', borderRadius: '8px', background: P.gradient, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: '13px', fontWeight: 800 }}>J</div>
              <span className="fd" style={{ fontSize: '15px', fontWeight: 900, letterSpacing: '-.03em' }}>jamie<span style={{ color: '#D4A0A0', fontWeight: 500 }}>@</span>work</span>
            </Link>
            <span className="fm" style={{ fontSize: '10px', color: P.textSec, padding: '3px 10px', borderRadius: '6px', border: `1px solid ${P.border}`, background: 'white', letterSpacing: '.06em', fontWeight: 600 }}>REVIEW QUEUE</span>
            {pendingCount > 0 && (
              <span className="fm" style={{ fontSize: '10px', fontWeight: 700, padding: '3px 8px', borderRadius: '100px', background: '#FFF7ED', color: P.warning, border: '1px solid #FED7AA' }}>
                {pendingCount} pending
              </span>
            )}
          </div>
          <div style={{ display: 'flex', gap: '8px' }}>
            <Link href="/dashboard/leads" className="fb" style={{ fontSize: '12px', padding: '7px 14px', borderRadius: '9px', border: `1.5px solid ${P.border}`, background: 'white', color: P.text, textDecoration: 'none', fontWeight: 600 }}>Leads</Link>
            <Link href="/dashboard" className="fb" style={{ fontSize: '12px', padding: '7px 14px', borderRadius: '9px', border: `1.5px solid ${P.border}`, background: 'white', color: P.textSec, textDecoration: 'none', fontWeight: 600 }}>← Dashboard</Link>
          </div>
        </nav>

        <div style={{ maxWidth: '800px', margin: '0 auto', padding: '32px 24px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '24px' }}>
            <div>
              <h1 className="fd" style={{ fontSize: '26px', fontWeight: 900, letterSpacing: '-.04em', marginBottom: '4px' }}>Review Queue</h1>
              <p className="fb" style={{ fontSize: '13px', color: P.textSec, fontWeight: 500 }}>Approve, edit, or reject Jamie&apos;s drafted messages before they send.</p>
            </div>
          </div>

          {/* Filter tabs */}
          <div style={{ display: 'flex', gap: '4px', marginBottom: '20px', padding: '4px', borderRadius: '10px', background: P.bgCard, border: `1px solid ${P.border}`, width: 'fit-content' }}>
            {(['pending_review', 'approved', 'rejected', 'all'] as const).map(f => (
              <button key={f} onClick={() => setFilter(f)} className="fb"
                style={{
                  padding: '6px 14px', borderRadius: '7px', border: 'none',
                  background: filter === f ? P.accent : 'transparent',
                  color: filter === f ? 'white' : P.textSec,
                  fontSize: '12px', fontWeight: 600, cursor: 'pointer', transition: 'all .15s',
                }}>
                {f === 'pending_review' ? 'Needs Review' : f === 'all' ? 'All' : f.charAt(0).toUpperCase() + f.slice(1)}
              </button>
            ))}
          </div>

          {success && <div className="fb" style={{ padding: '10px 14px', borderRadius: '10px', marginBottom: '16px', background: P.accentLight, border: `1px solid ${P.accentBorder}`, fontSize: '13px', color: P.accent, fontWeight: 600 }}>✓ {success}</div>}

          {/* Tasks */}
          {loading ? (
            <div className="fb" style={{ textAlign: 'center', padding: '48px', color: P.textTer, fontWeight: 500 }}>Loading queue...</div>
          ) : tasks.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '60px 24px', borderRadius: '16px', background: 'white', border: `1px solid ${P.border}` }}>
              <div style={{ fontSize: '36px', marginBottom: '12px' }}>📭</div>
              <p className="fb" style={{ fontSize: '14px', color: P.textSec, fontWeight: 500, marginBottom: '8px' }}>
                {filter === 'pending_review' ? 'No messages pending review.' : 'No tasks found.'}
              </p>
              <p className="fb" style={{ fontSize: '12px', color: P.textTer, fontWeight: 500 }}>
                When Jamie drafts messages, they&apos;ll appear here for your approval.
              </p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {tasks.map(task => {
                const tl = typeLabel(task.type)
                const sl = statusLabel(task.status)
                const isEditing = editingId === task.id

                return (
                  <div key={task.id} style={{
                    padding: '18px 20px', borderRadius: '14px', background: 'white',
                    border: `1px solid ${isEditing ? P.borderFocus : P.border}`,
                    boxShadow: isEditing ? `0 0 0 3px ${P.accentLight}` : '0 1px 4px rgba(28,25,23,.02)',
                    transition: 'all .2s',
                  }}>
                    {/* Header */}
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <span className="fm" style={{ fontSize: '10px', fontWeight: 600, padding: '2px 8px', borderRadius: '4px', background: tl.bg, color: tl.color }}>{tl.label}</span>
                        <span className="fm" style={{ fontSize: '10px', fontWeight: 600, padding: '2px 8px', borderRadius: '4px', background: sl.bg, color: sl.color, border: `1px solid ${sl.border}` }}>{sl.label}</span>
                        <span className="fm" style={{ fontSize: '10px', color: P.textTer }}>{task.channel}</span>
                      </div>
                      <span className="fm" style={{ fontSize: '10px', color: P.textTer }}>{new Date(task.created_at).toLocaleDateString()}</span>
                    </div>

                    {/* Lead info */}
                    {task.lead && (
                      <div className="fb" style={{ fontSize: '12px', color: P.textSec, marginBottom: '8px', fontWeight: 500 }}>
                        To: <strong style={{ color: P.text }}>{task.lead.name || 'Unknown'}</strong>
                        {task.lead.email && <span> · {task.lead.email}</span>}
                        {task.lead.company_name && <span> · {task.lead.company_name}</span>}
                      </div>
                    )}

                    {/* Subject */}
                    {task.subject && (
                      <div className="fb" style={{ fontSize: '13px', fontWeight: 700, color: P.text, marginBottom: '6px' }}>
                        Subject: {task.subject}
                      </div>
                    )}

                    {/* Body */}
                    {isEditing ? (
                      <textarea value={editBody} onChange={e => setEditBody(e.target.value)}
                        rows={6} autoFocus className="fb"
                        style={{
                          width: '100%', padding: '12px', borderRadius: '10px',
                          border: `1.5px solid ${P.accentBorder}`, background: P.accentLight,
                          color: P.text, fontSize: '13px', lineHeight: 1.6, resize: 'vertical',
                          outline: 'none', fontWeight: 500, marginBottom: '10px',
                        }} />
                    ) : (
                      <div className="fb" style={{
                        fontSize: '13px', color: P.textMd, lineHeight: 1.65, fontWeight: 500,
                        padding: '10px 14px', borderRadius: '10px', background: P.bg,
                        border: `1px solid ${P.border}`, marginBottom: '10px',
                        whiteSpace: 'pre-wrap',
                      }}>
                        {task.edited_body || task.body}
                      </div>
                    )}

                    {/* Actions */}
                    {task.status === 'pending_review' && (
                      <div style={{ display: 'flex', gap: '6px' }}>
                        {isEditing ? (
                          <>
                            <button onClick={() => approve(task.id, editBody)} className="fb"
                              style={{ padding: '8px 16px', borderRadius: '8px', border: 'none', background: P.gradient, color: 'white', fontSize: '12px', fontWeight: 700, cursor: 'pointer' }}>
                              ✓ Approve with Edits
                            </button>
                            <button onClick={() => setEditingId(null)} className="fb"
                              style={{ padding: '8px 14px', borderRadius: '8px', border: `1.5px solid ${P.border}`, background: 'white', color: P.textSec, fontSize: '12px', fontWeight: 600, cursor: 'pointer' }}>Cancel</button>
                          </>
                        ) : (
                          <>
                            <button onClick={() => approve(task.id)} className="fb"
                              style={{ padding: '8px 16px', borderRadius: '8px', border: 'none', background: P.gradient, color: 'white', fontSize: '12px', fontWeight: 700, cursor: 'pointer' }}>
                              ✓ Approve
                            </button>
                            <button onClick={() => startEdit(task)} className="fb"
                              style={{ padding: '8px 14px', borderRadius: '8px', border: `1.5px solid ${P.accentBorder}`, background: P.accentLight, color: P.accent, fontSize: '12px', fontWeight: 600, cursor: 'pointer' }}>
                              ✏️ Edit
                            </button>
                            <button onClick={() => reject(task.id)} className="fb"
                              style={{ padding: '8px 14px', borderRadius: '8px', border: '1.5px solid #FECACA', background: '#FEF2F2', color: P.danger, fontSize: '12px', fontWeight: 600, cursor: 'pointer' }}>
                              ✗ Reject
                            </button>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>
    </>
  )
}
