'use client'

import { useState, useEffect, useCallback } from 'react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'

interface Lead {
  id: string; name: string | null; email: string | null; company_name: string | null
  role_title: string | null; source: string | null; status: string; created_at: string
}

const P = {
  bg: '#FFFBF9', bgWash: '#FFF5F7', bgCard: '#FFFFFF',
  border: '#E8E5DF', borderRose: '#F9D4DC', borderFocus: '#0D9488',
  text: '#1C1917', textMd: '#57534E', textSec: '#78716C', textTer: '#A8A29E',
  accent: '#0D9488', accentLight: '#F0FDFA', accentBorder: '#99F6E4',
  rose: '#F472B6', roseLight: '#FFF5F7', roseBorder: '#F9D4DC',
  gradient: 'linear-gradient(135deg,#0D9488,#06B6D4)',
  danger: '#DC2626', warning: '#EA580C', success: '#16A34A',
}

const CSS = `
@import url('https://api.fontshare.com/v2/css?f[]=satoshi@500,700,800,900&display=swap');
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&display=swap');
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&display=swap');
*{box-sizing:border-box;margin:0;padding:0;}
.fd{font-family:'Satoshi',-apple-system,sans-serif;}
.fb{font-family:'DM Sans',-apple-system,sans-serif;}
.fm{font-family:'JetBrains Mono',monospace;}
input:focus,textarea:focus{border-color:${P.borderFocus} !important;box-shadow:0 0 0 3px ${P.accentLight} !important;}
.row-h{transition:all .15s;}.row-h:hover{background:${P.bgWash} !important;}
`

export default function LeadsPage() {
  const [leads, setLeads] = useState<Lead[]>([])
  const [loading, setLoading] = useState(true)
  const [showAdd, setShowAdd] = useState(false)
  const [showCSV, setShowCSV] = useState(false)
  const [csvText, setCsvText] = useState('')
  const [csvParsed, setCsvParsed] = useState<{ name: string; email: string; company: string; role: string }[]>([])
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({ name: '', email: '', company_name: '', role_title: '' })
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  const supabase = createClient()

  const fetchLeads = useCallback(async () => {
    const { data } = await supabase.from('leads').select('*').order('created_at', { ascending: false })
    if (data) setLeads(data)
    setLoading(false)
  }, [])

  useEffect(() => { fetchLeads() }, [fetchLeads])

  const addLead = async () => {
    if (!form.name.trim() || !form.email.trim()) return
    setSaving(true); setError(null)
    // Get company_id from first company (simplified — should use auth later)
    const { data: companies } = await supabase.from('companies').select('id').limit(1)
    const companyId = companies?.[0]?.id
    if (!companyId) { setError('No company found. Complete onboarding first.'); setSaving(false); return }

    const { error: e } = await supabase.from('leads').insert({
      company_id: companyId, name: form.name, email: form.email,
      company_name: form.company_name, role_title: form.role_title,
      source: 'manual', status: 'new',
    })
    if (e) { setError(e.message) } else {
      setForm({ name: '', email: '', company_name: '', role_title: '' })
      setShowAdd(false); setSuccess('Lead added!'); setTimeout(() => setSuccess(null), 3000)
      fetchLeads()
    }
    setSaving(false)
  }

  const parseCSV = (text: string) => {
    const lines = text.trim().split('\n')
    if (lines.length < 2) { setCsvParsed([]); return }
    const header = lines[0].toLowerCase()
    const nameIdx = header.split(',').findIndex(h => h.trim().includes('name'))
    const emailIdx = header.split(',').findIndex(h => h.trim().includes('email'))
    const compIdx = header.split(',').findIndex(h => h.trim().includes('company'))
    const roleIdx = header.split(',').findIndex(h => h.trim().includes('role') || h.trim().includes('title'))

    const parsed = lines.slice(1).map(line => {
      const cols = line.split(',').map(c => c.trim().replace(/^"|"$/g, ''))
      return {
        name: nameIdx >= 0 ? cols[nameIdx] || '' : '',
        email: emailIdx >= 0 ? cols[emailIdx] || '' : '',
        company: compIdx >= 0 ? cols[compIdx] || '' : '',
        role: roleIdx >= 0 ? cols[roleIdx] || '' : '',
      }
    }).filter(r => r.email)
    setCsvParsed(parsed)
  }

  const importCSV = async () => {
    if (csvParsed.length === 0) return
    setSaving(true); setError(null)
    const { data: companies } = await supabase.from('companies').select('id').limit(1)
    const companyId = companies?.[0]?.id
    if (!companyId) { setError('No company found. Complete onboarding first.'); setSaving(false); return }

    const rows = csvParsed.map(r => ({
      company_id: companyId, name: r.name, email: r.email,
      company_name: r.company, role_title: r.role,
      source: 'manual', status: 'new',
    }))
    const { error: e } = await supabase.from('leads').insert(rows)
    if (e) { setError(e.message) } else {
      setCsvText(''); setCsvParsed([]); setShowCSV(false)
      setSuccess(`${csvParsed.length} leads imported!`); setTimeout(() => setSuccess(null), 3000)
      fetchLeads()
    }
    setSaving(false)
  }

  const deleteLead = async (id: string) => {
    await supabase.from('leads').delete().eq('id', id)
    fetchLeads()
  }

  const statusStyle = (s: string) => {
    const m: Record<string, { bg: string; color: string; border: string }> = {
      new: { bg: '#FFF7ED', color: '#EA580C', border: '#FED7AA' },
      contacted: { bg: '#FFF5F7', color: '#BE185D', border: '#F9D4DC' },
      qualified: { bg: P.accentLight, color: P.accent, border: P.accentBorder },
      meeting_booked: { bg: P.accentLight, color: P.accent, border: P.accentBorder },
      disqualified: { bg: '#FEF2F2', color: '#DC2626', border: '#FECACA' },
      closed: { bg: '#F5F3EE', color: '#A8A29E', border: '#E8E5DF' },
    }
    return m[s] || m.new
  }

  const InputField = ({ label, value, onChange, placeholder, type }: { label: string; value: string; onChange: (v: string) => void; placeholder: string; type?: string }) => (
    <div>
      <label className="fb" style={{ fontSize: '12px', fontWeight: 600, color: P.textMd, display: 'block', marginBottom: '4px' }}>{label}</label>
      <input type={type || 'text'} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        className="fb" style={{ width: '100%', padding: '10px 12px', borderRadius: '9px', border: `1.5px solid ${P.border}`, background: P.bg, color: P.text, fontSize: '13px', fontWeight: 500, outline: 'none', transition: 'all .2s' }} />
    </div>
  )

  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: CSS }} />
      <div style={{ minHeight: '100vh', background: P.bg, color: P.text }}>
        {/* Nav */}
        <nav style={{ position: 'sticky', top: 0, zIndex: 100, padding: '12px 24px', background: 'rgba(255,251,249,.88)', backdropFilter: 'blur(20px)', borderBottom: `1px solid ${P.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <Link href="/dashboard" style={{ display: 'flex', alignItems: 'center', gap: '8px', textDecoration: 'none', color: P.text }}>
              <div style={{ width: '28px', height: '28px', borderRadius: '8px', background: P.gradient, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: '13px', fontWeight: 800 }}>J</div>
              <span className="fd" style={{ fontSize: '15px', fontWeight: 900, letterSpacing: '-.03em' }}>jamie<span style={{ color: '#D4A0A0', fontWeight: 500 }}>@</span>work</span>
            </Link>
            <span className="fm" style={{ fontSize: '10px', color: P.textSec, padding: '3px 10px', borderRadius: '6px', border: `1px solid ${P.border}`, background: 'white', letterSpacing: '.06em', fontWeight: 600 }}>LEADS</span>
          </div>
          <div style={{ display: 'flex', gap: '8px' }}>
            <Link href="/dashboard/queue" className="fb" style={{ fontSize: '12px', padding: '7px 14px', borderRadius: '9px', border: `1.5px solid ${P.border}`, background: 'white', color: P.text, textDecoration: 'none', fontWeight: 600 }}>Review Queue</Link>
            <Link href="/dashboard" className="fb" style={{ fontSize: '12px', padding: '7px 14px', borderRadius: '9px', border: `1.5px solid ${P.border}`, background: 'white', color: P.textSec, textDecoration: 'none', fontWeight: 600 }}>← Dashboard</Link>
          </div>
        </nav>

        <div style={{ maxWidth: '900px', margin: '0 auto', padding: '32px 24px' }}>
          {/* Header */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '24px' }}>
            <div>
              <h1 className="fd" style={{ fontSize: '26px', fontWeight: 900, letterSpacing: '-.04em', marginBottom: '4px' }}>Leads</h1>
              <p className="fb" style={{ fontSize: '13px', color: P.textSec, fontWeight: 500 }}>Add prospects for Jamie to engage. She&apos;ll draft messages for your review.</p>
            </div>
            <div style={{ display: 'flex', gap: '8px' }}>
              <button onClick={() => { setShowCSV(true); setShowAdd(false) }} className="fb"
                style={{ padding: '9px 16px', borderRadius: '10px', border: `1.5px solid ${P.border}`, background: 'white', color: P.text, fontSize: '13px', fontWeight: 600, cursor: 'pointer' }}>
                📄 Import CSV
              </button>
              <button onClick={() => { setShowAdd(true); setShowCSV(false) }} className="fb"
                style={{ padding: '9px 16px', borderRadius: '10px', border: 'none', background: P.gradient, color: 'white', fontSize: '13px', fontWeight: 700, cursor: 'pointer', boxShadow: '0 2px 8px rgba(13,148,136,.2)' }}>
                + Add Lead
              </button>
            </div>
          </div>

          {/* Messages */}
          {success && <div className="fb" style={{ padding: '10px 14px', borderRadius: '10px', marginBottom: '16px', background: P.accentLight, border: `1px solid ${P.accentBorder}`, fontSize: '13px', color: P.accent, fontWeight: 600 }}>✓ {success}</div>}
          {error && <div className="fb" style={{ padding: '10px 14px', borderRadius: '10px', marginBottom: '16px', background: '#FEF2F2', border: '1px solid #FECACA', fontSize: '13px', color: P.danger, fontWeight: 500 }}>{error}</div>}

          {/* Add Lead Form */}
          {showAdd && (
            <div style={{ padding: '20px', borderRadius: '16px', background: 'white', border: `1px solid ${P.border}`, marginBottom: '20px', boxShadow: '0 2px 12px rgba(28,25,23,.04)' }}>
              <div className="fd" style={{ fontSize: '15px', fontWeight: 800, marginBottom: '14px', letterSpacing: '-.01em' }}>Add a Lead</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '14px' }}>
                <InputField label="Name *" value={form.name} onChange={v => setForm(p => ({ ...p, name: v }))} placeholder="Jane Smith" />
                <InputField label="Email *" value={form.email} onChange={v => setForm(p => ({ ...p, email: v }))} placeholder="jane@company.com" type="email" />
                <InputField label="Company" value={form.company_name} onChange={v => setForm(p => ({ ...p, company_name: v }))} placeholder="Acme Corp" />
                <InputField label="Role / Title" value={form.role_title} onChange={v => setForm(p => ({ ...p, role_title: v }))} placeholder="VP of Sales" />
              </div>
              <div style={{ display: 'flex', gap: '8px' }}>
                <button onClick={addLead} disabled={saving || !form.name.trim() || !form.email.trim()} className="fb"
                  style={{ padding: '10px 20px', borderRadius: '10px', border: 'none', background: P.gradient, color: 'white', fontSize: '13px', fontWeight: 700, cursor: 'pointer' }}>
                  {saving ? 'Adding...' : 'Add Lead'}
                </button>
                <button onClick={() => setShowAdd(false)} className="fb"
                  style={{ padding: '10px 16px', borderRadius: '10px', border: `1.5px solid ${P.border}`, background: 'white', color: P.textSec, fontSize: '13px', fontWeight: 600, cursor: 'pointer' }}>Cancel</button>
              </div>
            </div>
          )}

          {/* CSV Import */}
          {showCSV && (
            <div style={{ padding: '20px', borderRadius: '16px', background: 'white', border: `1px solid ${P.border}`, marginBottom: '20px', boxShadow: '0 2px 12px rgba(28,25,23,.04)' }}>
              <div className="fd" style={{ fontSize: '15px', fontWeight: 800, marginBottom: '6px', letterSpacing: '-.01em' }}>Import from CSV</div>
              <p className="fb" style={{ fontSize: '12px', color: P.textSec, marginBottom: '12px', fontWeight: 500 }}>
                Paste CSV with headers: name, email, company, role/title. One lead per line.
              </p>
              <textarea value={csvText} onChange={e => { setCsvText(e.target.value); parseCSV(e.target.value) }}
                placeholder={"name,email,company,role\nJane Smith,jane@acme.com,Acme Corp,VP Sales\nBob Jones,bob@initech.com,Initech,CTO"}
                rows={6} className="fm"
                style={{ width: '100%', padding: '12px', borderRadius: '10px', border: `1.5px solid ${P.border}`, background: P.bg, color: P.text, fontSize: '12px', lineHeight: 1.6, resize: 'vertical', outline: 'none', marginBottom: '10px' }} />
              {csvParsed.length > 0 && (
                <div className="fb" style={{ fontSize: '12px', color: P.accent, fontWeight: 600, marginBottom: '10px' }}>
                  ✓ {csvParsed.length} leads parsed — ready to import
                </div>
              )}
              <div style={{ display: 'flex', gap: '8px' }}>
                <button onClick={importCSV} disabled={saving || csvParsed.length === 0} className="fb"
                  style={{ padding: '10px 20px', borderRadius: '10px', border: 'none', background: P.gradient, color: 'white', fontSize: '13px', fontWeight: 700, cursor: 'pointer' }}>
                  {saving ? 'Importing...' : `Import ${csvParsed.length} Leads`}
                </button>
                <button onClick={() => { setShowCSV(false); setCsvText(''); setCsvParsed([]) }} className="fb"
                  style={{ padding: '10px 16px', borderRadius: '10px', border: `1.5px solid ${P.border}`, background: 'white', color: P.textSec, fontSize: '13px', fontWeight: 600, cursor: 'pointer' }}>Cancel</button>
              </div>
            </div>
          )}

          {/* Leads Table */}
          {loading ? (
            <div className="fb" style={{ textAlign: 'center', padding: '48px', color: P.textTer, fontWeight: 500 }}>Loading leads...</div>
          ) : leads.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '60px 24px', borderRadius: '16px', background: 'white', border: `1px solid ${P.border}` }}>
              <div style={{ fontSize: '36px', marginBottom: '12px' }}>🎯</div>
              <p className="fb" style={{ fontSize: '14px', color: P.textSec, fontWeight: 500, marginBottom: '16px' }}>No leads yet. Add prospects for Jamie to engage.</p>
              <button onClick={() => setShowAdd(true)} className="fb"
                style={{ padding: '10px 24px', borderRadius: '10px', border: 'none', background: P.gradient, color: 'white', fontSize: '14px', fontWeight: 700, cursor: 'pointer' }}>+ Add Your First Lead</button>
            </div>
          ) : (
            <div style={{ borderRadius: '14px', background: 'white', border: `1px solid ${P.border}`, overflow: 'hidden' }}>
              {/* Header row */}
              <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 2fr 1.5fr 1fr 60px', gap: '12px', padding: '10px 16px', borderBottom: `1px solid ${P.border}`, background: P.bgWash }}>
                {['Name', 'Email', 'Company', 'Status', ''].map(h => (
                  <div key={h} className="fm" style={{ fontSize: '9px', fontWeight: 700, color: P.textTer, letterSpacing: '.06em' }}>{h}</div>
                ))}
              </div>
              {/* Rows */}
              {leads.map(lead => {
                const st = statusStyle(lead.status)
                return (
                  <div key={lead.id} className="row-h" style={{ display: 'grid', gridTemplateColumns: '1.5fr 2fr 1.5fr 1fr 60px', gap: '12px', padding: '12px 16px', borderBottom: `1px solid ${P.border}`, alignItems: 'center' }}>
                    <div>
                      <div className="fb" style={{ fontSize: '13px', fontWeight: 600, color: P.text }}>{lead.name || '—'}</div>
                      {lead.role_title && <div className="fb" style={{ fontSize: '11px', color: P.textTer, fontWeight: 500 }}>{lead.role_title}</div>}
                    </div>
                    <div className="fm" style={{ fontSize: '12px', color: P.textSec }}>{lead.email || '—'}</div>
                    <div className="fb" style={{ fontSize: '12px', color: P.textMd, fontWeight: 500 }}>{lead.company_name || '—'}</div>
                    <div>
                      <span className="fm" style={{ fontSize: '10px', fontWeight: 600, padding: '3px 8px', borderRadius: '5px', background: st.bg, color: st.color, border: `1px solid ${st.border}` }}>
                        {lead.status.replace('_', ' ')}
                      </span>
                    </div>
                    <div>
                      <button onClick={() => deleteLead(lead.id)}
                        style={{ background: 'none', border: 'none', color: P.textTer, cursor: 'pointer', fontSize: '14px', padding: '4px' }}
                        onMouseEnter={e => e.currentTarget.style.color = P.danger}
                        onMouseLeave={e => e.currentTarget.style.color = P.textTer}>✕</button>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>
    </>
  )
}
