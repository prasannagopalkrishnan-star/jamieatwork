'use client'

import { useState, useRef, useEffect } from 'react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'

type Step = 'info' | 'train' | 'review'

interface Message {
  role: 'jamie' | 'user'
  content: string
}

interface PlaybookData {
  product_name: string
  product_description: string
  problem_solved: string
  key_differentiators: string
  target_company_size: string
  target_industries: string
  target_roles: string
  icp_signals: string
  qualification_questions: string[]
  disqualification_criteria: string
  objection_playbook: { objection: string; response: string }[]
  voice_style: string
  call_to_action: string
  calendar_link: string
}

export default function OnboardingPage() {
  const [step, setStep] = useState<Step>('info')
  const [companyName, setCompanyName] = useState('')
  const [website, setWebsite] = useState('')
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([])
  const [messages, setMessages] = useState<Message[]>([])
  const [userInput, setUserInput] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const [playbook, setPlaybook] = useState<PlaybookData | null>(null)
  const [saving, setSaving] = useState(false)
  const [profileId, setProfileId] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const chatEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  useEffect(() => {
    if (step === 'train' && inputRef.current) {
      inputRef.current.focus()
    }
  }, [step, messages])

  // Start training — Jamie sends first message via API
  const startTraining = async () => {
    if (!companyName.trim()) return
    setStep('train')
    setIsTyping(true)
    setError(null)

    try {
      const res = await fetch('/api/training', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'chat',
          messages: [{ role: 'user', content: `Hi Jamie, I'm the founder of ${companyName}${website ? ` (${website})` : ''}. I'm ready to train you.` }],
          companyName,
        }),
      })
      const data = await res.json()
      if (data.error) throw new Error(data.error)

      setMessages([{ role: 'jamie', content: data.message }])
    } catch (err) {
      setError('Failed to connect to Jamie. Please try again.')
      console.error(err)
    }
    setIsTyping(false)
  }

  // Send message and get Jamie's response
  const handleSend = async () => {
    if (!userInput.trim() || isTyping) return
    const newMessages: Message[] = [...messages, { role: 'user', content: userInput }]
    setMessages(newMessages)
    setUserInput('')
    setIsTyping(true)
    setError(null)

    try {
      const res = await fetch('/api/training', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'chat',
          messages: newMessages,
          companyName,
        }),
      })
      const data = await res.json()
      if (data.error) throw new Error(data.error)

      const jamieMessage = data.message
      const updatedMessages: Message[] = [...newMessages, { role: 'jamie', content: jamieMessage }]
      setMessages(updatedMessages)

      // Check if training is complete (Jamie says she has everything)
      if (jamieMessage.includes('🎉') || jamieMessage.toLowerCase().includes('got everything') || jamieMessage.toLowerCase().includes('playbook')) {
        setTimeout(() => generatePlaybook(updatedMessages), 2000)
      }
    } catch (err) {
      setError('Failed to get response. Please try again.')
      console.error(err)
    }
    setIsTyping(false)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  // Generate playbook via Claude
  const generatePlaybook = async (allMessages: Message[]) => {
    setIsTyping(true)
    try {
      const res = await fetch('/api/training', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'generate_playbook',
          messages: allMessages,
          companyName,
        }),
      })
      const data = await res.json()
      if (data.error) throw new Error(data.error)

      setPlaybook(data.playbook)
      setStep('review')
    } catch (err) {
      setError('Failed to generate playbook. Please try again.')
      console.error(err)
    }
    setIsTyping(false)
  }

  // Save to Supabase
  const savePlaybook = async () => {
    if (!playbook) return
    setSaving(true)
    setError(null)
    const supabase = createClient()

    try {
      const { data: company, error: compError } = await supabase
        .from('companies')
        .insert({ name: companyName, domain: website })
        .select()
        .single()

      if (compError) throw compError

      const { data: profile, error: profError } = await supabase
        .from('onboarding_profiles')
        .insert({
          company_id: company.id,
          status: 'completed',
          product_name: playbook.product_name,
          product_description: playbook.product_description,
          problem_solved: playbook.problem_solved,
          key_differentiators: playbook.key_differentiators,
          target_company_size: playbook.target_company_size,
          target_industries: playbook.target_industries,
          target_roles: playbook.target_roles,
          icp_signals: playbook.icp_signals,
          qualification_questions: playbook.qualification_questions,
          disqualification_criteria: playbook.disqualification_criteria,
          objection_playbook: playbook.objection_playbook,
          voice_style: playbook.voice_style,
          call_to_action: playbook.call_to_action,
          calendar_link: playbook.calendar_link,
          training_transcript: messages,
          uploaded_docs: uploadedFiles,
        })
        .select()
        .single()

      if (profError) throw profError

      await supabase.from('digital_employees').insert({
        company_id: company.id,
        name: 'Jamie',
        title: 'SDR — Sales Development Rep',
        department: 'Sales',
        category: 'sdr',
        status: 'active',
      })

      if (profile) setProfileId(profile.id)
    } catch (err) {
      setError('Failed to save. Please try again.')
      console.error(err)
    }
    setSaving(false)
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files) {
      setUploadedFiles(prev => [...prev, ...Array.from(files).map(f => f.name)])
    }
  }

  const questionCount = messages.filter(m => m.role === 'jamie').length
  const totalQuestions = 5

  return (
    <div style={{ minHeight: '100vh' }}>
      {/* Nav */}
      <nav style={{
        position: 'sticky', top: 0, zIndex: 100, padding: '12px 0',
        background: 'rgba(10, 10, 15, 0.9)', backdropFilter: 'blur(20px)',
        borderBottom: '1px solid var(--border-color)',
      }}>
        <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Link href="/" style={{ fontFamily: 'var(--font-mono)', fontSize: '16px', fontWeight: 700 }}>
            <span style={{ color: 'var(--accent-primary)' }}>jamie</span>
            <span style={{ color: 'var(--text-tertiary)' }}>@</span>
            <span>work</span>
          </Link>
          <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
            {(['info', 'train', 'review'] as Step[]).map((s, i) => (
              <div key={s} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div style={{
                  width: '28px', height: '28px', borderRadius: '50%',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: '12px', fontWeight: 700, fontFamily: 'var(--font-mono)',
                  background: step === s ? 'var(--accent-primary)' :
                    (['info', 'train', 'review'].indexOf(step) > i ? 'rgba(34, 211, 167, 0.2)' : 'var(--bg-card)'),
                  color: step === s ? 'var(--bg-primary)' : 'var(--text-tertiary)',
                  border: `1px solid ${step === s ? 'var(--accent-primary)' : 'var(--border-color)'}`,
                }}>
                  {['info', 'train', 'review'].indexOf(step) > i ? '✓' : i + 1}
                </div>
                {i < 2 && <div style={{ width: '20px', height: '1px', background: ['info', 'train', 'review'].indexOf(step) > i ? 'var(--accent-primary)' : 'var(--border-color)' }} />}
              </div>
            ))}
          </div>
        </div>
      </nav>

      {/* Error banner */}
      {error && (
        <div style={{
          padding: '12px 24px', background: 'rgba(239, 68, 68, 0.1)',
          borderBottom: '1px solid rgba(239, 68, 68, 0.2)', textAlign: 'center',
          fontSize: '13px', color: 'var(--accent-danger)',
        }}>
          {error}
        </div>
      )}

      {/* STEP 1: Company Info */}
      {step === 'info' && (
        <div className="container" style={{ maxWidth: '600px', padding: '60px 24px' }}>
          <div className="animate-in">
            <h1 style={{ fontSize: '28px', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: '8px' }}>
              Let&apos;s get Jamie up to speed
            </h1>
            <p style={{ color: 'var(--text-secondary)', fontSize: '15px', marginBottom: '40px' }}>
              Quick basics, then a 5-minute conversation to train Jamie on your product and sales process.
            </p>
          </div>

          <div className="animate-in animate-delay-1" style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            <div>
              <label style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                Company Name *
              </label>
              <input type="text" value={companyName} onChange={(e) => setCompanyName(e.target.value)}
                placeholder="e.g., Acme Corp"
                style={{
                  width: '100%', padding: '12px 16px', borderRadius: 'var(--radius-sm)',
                  border: '1px solid var(--border-color)', background: 'var(--bg-card)',
                  color: 'var(--text-primary)', fontSize: '15px', fontFamily: 'var(--font-body)', outline: 'none',
                }} />
            </div>

            <div>
              <label style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                Website
              </label>
              <input type="text" value={website} onChange={(e) => setWebsite(e.target.value)}
                placeholder="e.g., acmecorp.com"
                style={{
                  width: '100%', padding: '12px 16px', borderRadius: 'var(--radius-sm)',
                  border: '1px solid var(--border-color)', background: 'var(--bg-card)',
                  color: 'var(--text-primary)', fontSize: '15px', fontFamily: 'var(--font-body)', outline: 'none',
                }} />
            </div>

            {/* File Upload */}
            <div>
              <label style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                Upload Sales Docs (optional)
              </label>
              <p style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '12px' }}>
                Pitch deck, one-pager, case studies — anything that helps Jamie learn your product.
              </p>
              <label style={{
                display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '28px',
                borderRadius: 'var(--radius-md)', border: '2px dashed var(--border-color)',
                background: 'var(--bg-secondary)', cursor: 'pointer',
              }}>
                <input type="file" multiple onChange={handleFileUpload} accept=".pdf,.doc,.docx,.ppt,.pptx,.txt,.csv" style={{ display: 'none' }} />
                <div style={{ fontSize: '24px', marginBottom: '8px' }}>📄</div>
                <div style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>Click to upload files</div>
              </label>
              {uploadedFiles.length > 0 && (
                <div style={{ marginTop: '12px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  {uploadedFiles.map((name, i) => (
                    <div key={i} style={{
                      display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 12px',
                      borderRadius: 'var(--radius-sm)', background: 'var(--bg-card)',
                      border: '1px solid var(--border-color)', fontSize: '13px',
                    }}>
                      <span>📎</span><span style={{ flex: 1 }}>{name}</span>
                      <button onClick={() => setUploadedFiles(prev => prev.filter((_, idx) => idx !== i))}
                        style={{ background: 'none', border: 'none', color: 'var(--text-tertiary)', cursor: 'pointer' }}>✕</button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <button onClick={startTraining} disabled={!companyName.trim()}
              className="btn btn-primary btn-lg"
              style={{ marginTop: '12px', width: '100%', opacity: companyName.trim() ? 1 : 0.5, cursor: companyName.trim() ? 'pointer' : 'not-allowed' }}>
              Start Training Jamie →
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: Training Chat */}
      {step === 'train' && (
        <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 53px)' }}>
          <div style={{
            padding: '12px 24px', borderBottom: '1px solid var(--border-color)', background: 'var(--bg-secondary)',
          }}>
            <div className="container" style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <div style={{
                width: '36px', height: '36px', borderRadius: '50%',
                background: 'linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))',
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '16px',
              }}>🤖</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: '14px' }}>Jamie — SDR Training</div>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)' }}>
                  Training for {companyName} · ~5 questions
                </div>
              </div>
              {/* Progress bar */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div style={{
                  width: '120px', height: '4px', borderRadius: '2px', background: 'var(--bg-card)',
                  overflow: 'hidden',
                }}>
                  <div style={{
                    width: `${Math.min((questionCount / totalQuestions) * 100, 100)}%`,
                    height: '100%', borderRadius: '2px', background: 'var(--accent-primary)',
                    transition: 'width 0.3s ease',
                  }} />
                </div>
                <span style={{ fontSize: '11px', color: 'var(--text-tertiary)', fontFamily: 'var(--font-mono)' }}>
                  {Math.min(questionCount, totalQuestions)}/{totalQuestions}
                </span>
              </div>
            </div>
          </div>

          {/* Messages */}
          <div style={{ flex: 1, overflowY: 'auto', padding: '24px' }}>
            <div className="container" style={{ maxWidth: '700px' }}>
              {messages.map((msg, i) => (
                <div key={i} style={{
                  display: 'flex', justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start',
                  marginBottom: '16px',
                }}>
                  <div style={{
                    maxWidth: '85%', padding: '14px 18px',
                    borderRadius: msg.role === 'user' ? '16px 16px 4px 16px' : '16px 16px 16px 4px',
                    background: msg.role === 'user' ? 'var(--accent-primary)' : 'var(--bg-card)',
                    color: msg.role === 'user' ? 'var(--bg-primary)' : 'var(--text-primary)',
                    border: msg.role === 'user' ? 'none' : '1px solid var(--border-color)',
                    fontSize: '14px', lineHeight: 1.6,
                  }}>
                    <span dangerouslySetInnerHTML={{
                      __html: msg.content
                        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                        .replace(/\n/g, '<br/>')
                    }} />
                  </div>
                </div>
              ))}
              {isTyping && (
                <div style={{ display: 'flex', justifyContent: 'flex-start', marginBottom: '16px' }}>
                  <div style={{
                    padding: '14px 18px', borderRadius: '16px 16px 16px 4px',
                    background: 'var(--bg-card)', border: '1px solid var(--border-color)',
                    fontSize: '14px', color: 'var(--text-tertiary)',
                  }}>
                    <span style={{ animation: 'pulse-glow 1.5s infinite' }}>Jamie is thinking...</span>
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>
          </div>

          {/* Input */}
          <div style={{ padding: '16px 24px', borderTop: '1px solid var(--border-color)', background: 'var(--bg-secondary)' }}>
            <div className="container" style={{ maxWidth: '700px', display: 'flex', gap: '12px' }}>
              <textarea ref={inputRef} value={userInput} onChange={(e) => setUserInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Type your answer... (Enter to send, Shift+Enter for new line)"
                rows={2}
                style={{
                  flex: 1, padding: '12px 16px', borderRadius: 'var(--radius-sm)',
                  border: '1px solid var(--border-color)', background: 'var(--bg-card)',
                  color: 'var(--text-primary)', fontSize: '14px', fontFamily: 'var(--font-body)',
                  resize: 'none', outline: 'none', lineHeight: 1.5,
                }} />
              <button onClick={handleSend} disabled={!userInput.trim() || isTyping}
                className="btn btn-primary" style={{ alignSelf: 'flex-end', opacity: userInput.trim() && !isTyping ? 1 : 0.5 }}>
                Send
              </button>
            </div>
          </div>
        </div>
      )}

      {/* STEP 3: Review Playbook */}
      {step === 'review' && playbook && (
        <div className="container" style={{ maxWidth: '800px', padding: '40px 24px 80px' }}>
          <div style={{ marginBottom: '32px' }}>
            <h1 style={{ fontSize: '28px', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: '8px' }}>
              Jamie&apos;s Sales Playbook
            </h1>
            <p style={{ color: 'var(--text-secondary)', fontSize: '15px' }}>
              Review what Jamie learned. Edit anything that&apos;s off, then approve to go live.
            </p>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {/* The Pitch */}
            <div className="card">
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--accent-primary)', marginBottom: '12px', fontFamily: 'var(--font-mono)' }}>THE PITCH</h3>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Product</div>
                <div style={{ fontSize: '14px', lineHeight: 1.6 }}>{playbook.product_name}</div>
              </div>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Description</div>
                <div style={{ fontSize: '14px', lineHeight: 1.6 }}>{playbook.product_description}</div>
              </div>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Problem Solved</div>
                <div style={{ fontSize: '14px', lineHeight: 1.6 }}>{playbook.problem_solved}</div>
              </div>
              <div>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Differentiators</div>
                <div style={{ fontSize: '14px', lineHeight: 1.6 }}>{playbook.key_differentiators}</div>
              </div>
            </div>

            {/* ICP */}
            <div className="card">
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--accent-primary)', marginBottom: '12px', fontFamily: 'var(--font-mono)' }}>IDEAL CUSTOMER PROFILE</h3>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Company Size & Type</div>
                <div style={{ fontSize: '14px', lineHeight: 1.6 }}>{playbook.target_company_size}</div>
              </div>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Industries</div>
                <div style={{ fontSize: '14px', lineHeight: 1.6 }}>{playbook.target_industries}</div>
              </div>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Decision Makers</div>
                <div style={{ fontSize: '14px', lineHeight: 1.6 }}>{playbook.target_roles}</div>
              </div>
              <div>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Buying Signals</div>
                <div style={{ fontSize: '14px', lineHeight: 1.6 }}>{playbook.icp_signals}</div>
              </div>
            </div>

            {/* Qualification */}
            <div className="card">
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--accent-primary)', marginBottom: '12px', fontFamily: 'var(--font-mono)' }}>QUALIFICATION FRAMEWORK</h3>
              <div style={{ marginBottom: '16px' }}>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '8px' }}>Questions Jamie Will Ask</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  {playbook.qualification_questions.map((q, i) => (
                    <div key={i} style={{
                      padding: '10px 14px', borderRadius: 'var(--radius-sm)',
                      background: 'var(--bg-secondary)', border: '1px solid var(--border-color)',
                      fontSize: '13px', lineHeight: 1.5,
                    }}>
                      <span style={{ color: 'var(--accent-primary)', fontFamily: 'var(--font-mono)', marginRight: '8px' }}>{i + 1}.</span>
                      {q}
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Walk Away When</div>
                <div style={{ fontSize: '14px', lineHeight: 1.6, color: 'var(--accent-danger)' }}>{playbook.disqualification_criteria}</div>
              </div>
            </div>

            {/* Objections */}
            <div className="card">
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--accent-primary)', marginBottom: '12px', fontFamily: 'var(--font-mono)' }}>OBJECTION PLAYBOOK</h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {playbook.objection_playbook.map((obj, i) => (
                  <div key={i} style={{
                    padding: '14px 16px', borderRadius: 'var(--radius-sm)',
                    background: 'var(--bg-secondary)', border: '1px solid var(--border-color)',
                  }}>
                    <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--accent-warning)', marginBottom: '6px' }}>
                      &ldquo;{obj.objection}&rdquo;
                    </div>
                    <div style={{ fontSize: '13px', color: 'var(--text-secondary)', lineHeight: 1.5 }}>
                      → {obj.response}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Style & CTA */}
            <div className="card">
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--accent-primary)', marginBottom: '12px', fontFamily: 'var(--font-mono)' }}>STYLE & CALL TO ACTION</h3>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Voice</div>
                <div style={{ fontSize: '14px', lineHeight: 1.6 }}>{playbook.voice_style}</div>
              </div>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Call to Action</div>
                <div style={{ fontSize: '14px', lineHeight: 1.6 }}>{playbook.call_to_action}</div>
              </div>
              {playbook.calendar_link && (
                <div>
                  <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Calendar Link</div>
                  <a href={playbook.calendar_link} target="_blank" rel="noopener noreferrer"
                    style={{ fontSize: '14px', fontFamily: 'var(--font-mono)', color: 'var(--accent-primary)' }}>
                    {playbook.calendar_link}
                  </a>
                </div>
              )}
            </div>

            {/* Actions */}
            <div style={{ display: 'flex', gap: '12px', marginTop: '12px' }}>
              <button onClick={savePlaybook} disabled={saving || !!profileId}
                className="btn btn-primary btn-lg" style={{ flex: 1 }}>
                {profileId ? '✓ Jamie is Live!' : saving ? 'Deploying...' : 'Approve & Deploy Jamie →'}
              </button>
              <button onClick={() => { setStep('train'); setMessages([]); setPlaybook(null) }}
                className="btn btn-secondary btn-lg">
                Retrain
              </button>
            </div>

            {profileId && (
              <div style={{
                padding: '16px 20px', borderRadius: 'var(--radius-md)',
                background: 'rgba(34, 211, 167, 0.08)', border: '1px solid rgba(34, 211, 167, 0.2)',
                textAlign: 'center',
              }}>
                <div style={{ fontSize: '15px', fontWeight: 600, color: 'var(--accent-primary)', marginBottom: '8px' }}>
                  🎉 Jamie is deployed and ready to sell for {companyName}!
                </div>
                <Link href="/dashboard" className="btn btn-primary" style={{ fontSize: '13px', marginTop: '8px' }}>
                  Go to Dashboard →
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
