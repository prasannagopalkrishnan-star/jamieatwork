import { NextRequest, NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
})

const TRAINING_SYSTEM_PROMPT = `You are Jamie, an AI SDR (Sales Development Rep) being trained by a startup founder. You're in an onboarding conversation where the founder is teaching you about their product so you can sell for them.

Your job is to:
1. Acknowledge what they told you (briefly, 1-2 sentences max)
2. Ask the NEXT question from the sequence below
3. Be warm, concise, and professional — like a sharp new hire on day one

QUESTION SEQUENCE (ask these in order, one per turn):
Q1: "What do you sell, and what problem does it solve for your customers?"
Q2: "Who's your ideal buyer — what type of company, how big, and who's the decision-maker?"
Q3: "What makes you different from alternatives? And what are the top 2-3 objections prospects raise?"
Q4: "How should I figure out if a lead is worth your time — and when should I walk away?"
Q5: "Last one — what's the CTA you want me to drive toward? (e.g., book a demo, start a trial) How should I sound when talking to prospects? And drop your calendar link if you have one."

After Q5 is answered, respond with:
"🎉 Got everything I need! Let me build your Sales Playbook..."

RULES:
- Ask exactly ONE question per turn
- Keep acknowledgments SHORT (1-2 sentences)
- Don't repeat information back at length
- Be conversational, not robotic
- If their answer is vague, gently ask for more specifics before moving on
- Track which question you're on based on conversation history`

const PLAYBOOK_SYSTEM_PROMPT = `You are an expert sales strategist. Given a training conversation between a startup founder and their AI SDR, extract and structure the information into a clean Sales Playbook.

Return ONLY valid JSON with this exact structure — no markdown, no backticks, no explanation:

{
  "product_name": "string",
  "product_description": "1-2 sentence description",
  "problem_solved": "the core pain point",
  "key_differentiators": "what makes them different",
  "target_company_size": "company size/type",
  "target_industries": "industries they target",
  "target_roles": "job titles of buyers",
  "icp_signals": "signals that indicate a prospect is a good fit",
  "qualification_questions": ["question 1", "question 2", "question 3"],
  "disqualification_criteria": "when to walk away",
  "objection_playbook": [
    {"objection": "the objection", "response": "how to handle it"}
  ],
  "voice_style": "how Jamie should sound",
  "call_to_action": "what Jamie drives toward",
  "calendar_link": "URL or empty string"
}

Be precise. Extract real information from the conversation. If something wasn't mentioned, use reasonable defaults based on context. Ensure qualification_questions is an array of clean, individual questions. Ensure objection_playbook has clean objection/response pairs.`

export async function POST(request: NextRequest) {
  try {
    const { action, messages, companyName } = await request.json()

    if (action === 'chat') {
      // Training conversation
      const response = await client.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 500,
        system: TRAINING_SYSTEM_PROMPT,
        messages: messages.map((m: { role: string; content: string }) => ({
          role: m.role === 'jamie' ? 'assistant' : 'user',
          content: m.content,
        })),
      })

      const text = response.content[0].type === 'text' ? response.content[0].text : ''
      return NextResponse.json({ message: text })
    }

    if (action === 'generate_playbook') {
      // Generate structured playbook from conversation
      const transcript = messages
        .map((m: { role: string; content: string }) => `${m.role === 'jamie' ? 'Jamie' : 'Founder'}: ${m.content}`)
        .join('\n\n')

      const response = await client.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 2000,
        system: PLAYBOOK_SYSTEM_PROMPT,
        messages: [
          {
            role: 'user',
            content: `Here is the training conversation for ${companyName}:\n\n${transcript}\n\nGenerate the Sales Playbook JSON.`,
          },
        ],
      })

      const text = response.content[0].type === 'text' ? response.content[0].text : '{}'
      
      // Parse JSON, handling potential markdown wrapping
      const cleaned = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim()
      const playbook = JSON.parse(cleaned)
      
      return NextResponse.json({ playbook })
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
  } catch (error) {
    console.error('Training API error:', error)
    return NextResponse.json({ error: 'Something went wrong' }, { status: 500 })
  }
}
