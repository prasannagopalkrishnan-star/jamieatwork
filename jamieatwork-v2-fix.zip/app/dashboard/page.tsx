import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'

export const dynamic = 'force-dynamic'

interface DigitalEmployee {
  id: string
  company_id: string | null
  name: string
  title: string
  department: string | null
  manager_name: string | null
  manager_email: string | null
  employee_id: string | null
  category: string | null
  status: string
  created_at: string
}

interface Ticket {
  id: string
  company_id: string | null
  employee_id: string | null
  ticket_ref: string | null
  submitter_name: string | null
  submitter_email: string | null
  category: string | null
  question: string
  response: string | null
  status: string
  escalated: boolean
  created_at: string
  resolved_at: string | null
}

export default async function DashboardPage() {
  const supabase = await createClient()

  const { data: employees, error: empError } = await supabase
    .from('digital_employees')
    .select('*')
    .order('created_at', { ascending: false })

  const { data: tickets, error: tickError } = await supabase
    .from('tickets')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(10)

  const activeCount = employees?.filter((e: DigitalEmployee) => e.status === 'active').length ?? 0
  const resolvedToday = tickets?.filter((t: Ticket) => {
    const today = new Date().toISOString().split('T')[0]
    return t.status === 'resolved' && t.resolved_at?.startsWith(today)
  }).length ?? 0
  const openTickets = tickets?.filter((t: Ticket) => t.status === 'open').length ?? 0

  return (
    <div style={{ minHeight: '100vh' }}>
      {/* Top Bar */}
      <nav style={{
        position: 'sticky',
        top: 0,
        zIndex: 100,
        padding: '12px 0',
        background: 'rgba(10, 10, 15, 0.9)',
        backdropFilter: 'blur(20px)',
        borderBottom: '1px solid var(--border-color)',
      }}>
        <div className="container" style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '24px' }}>
            <Link href="/" style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '16px',
              fontWeight: 700,
            }}>
              <span style={{ color: 'var(--accent-primary)' }}>jamie</span>
              <span style={{ color: 'var(--text-tertiary)' }}>@</span>
              <span>work</span>
            </Link>
            <span style={{
              fontSize: '12px',
              color: 'var(--text-tertiary)',
              fontFamily: 'var(--font-mono)',
              padding: '2px 10px',
              borderRadius: 'var(--radius-full)',
              border: '1px solid var(--border-color)',
            }}>
              DASHBOARD
            </span>
          </div>
          <Link href="/" className="btn btn-secondary" style={{ fontSize: '12px', padding: '6px 14px' }}>
            ← Back to Marketplace
          </Link>
        </div>
      </nav>

      <div className="container" style={{ padding: '40px 24px' }}>
        {/* Header */}
        <div style={{ marginBottom: '36px' }}>
          <h1 style={{ fontSize: '28px', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: '8px' }}>
            Command Center
          </h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: '15px' }}>
            Monitor and manage your digital workforce.
          </p>
        </div>

        {/* Stats Grid */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(4, 1fr)',
          gap: '16px',
          marginBottom: '40px',
        }}>
          {[
            { label: 'Active Employees', value: activeCount, color: 'var(--accent-primary)' },
            { label: 'Total Employees', value: employees?.length ?? 0, color: 'var(--text-primary)' },
            { label: 'Open Tickets', value: openTickets, color: 'var(--accent-warning)' },
            { label: 'Resolved Today', value: resolvedToday, color: 'var(--accent-primary)' },
          ].map((stat) => (
            <div key={stat.label} className="card" style={{ padding: '20px' }}>
              <div style={{
                fontSize: '32px',
                fontWeight: 700,
                fontFamily: 'var(--font-mono)',
                color: stat.color,
                marginBottom: '4px',
              }}>
                {stat.value}
              </div>
              <div style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Two Column Layout */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
          {/* Employees Panel */}
          <div>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '16px',
            }}>
              <h2 style={{ fontSize: '18px', fontWeight: 600 }}>Digital Employees</h2>
              <Link href="/dashboard/employees/new" className="btn btn-primary" style={{
                fontSize: '12px',
                padding: '6px 14px',
              }}>
                + Add Employee
              </Link>
            </div>

            {employees && employees.length > 0 ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {employees.map((emp: DigitalEmployee) => (
                  <div key={emp.id} className="card" style={{ padding: '16px' }}>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                    }}>
                      <div>
                        <div style={{ fontWeight: 600, fontSize: '15px', marginBottom: '2px' }}>
                          {emp.name}
                        </div>
                        <div style={{
                          fontSize: '13px',
                          color: 'var(--text-secondary)',
                        }}>
                          {emp.title}
                        </div>
                      </div>
                      <span className={`badge badge-${emp.status}`}>
                        {emp.status === 'active' ? '● Active' : emp.status === 'setup' ? '○ Setup' : '◌ Inactive'}
                      </span>
                    </div>
                    <div style={{
                      display: 'flex',
                      gap: '8px',
                      marginTop: '12px',
                      fontSize: '12px',
                      color: 'var(--text-tertiary)',
                      fontFamily: 'var(--font-mono)',
                    }}>
                      {emp.department && <span>{emp.department}</span>}
                      {emp.category && (
                        <span style={{
                          padding: '2px 8px',
                          borderRadius: 'var(--radius-full)',
                          background: 'var(--bg-secondary)',
                          border: '1px solid var(--border-color)',
                        }}>
                          {emp.category}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="card" style={{
                padding: '40px',
                textAlign: 'center',
                color: 'var(--text-tertiary)',
              }}>
                <div style={{ fontSize: '32px', marginBottom: '12px' }}>🤖</div>
                <p style={{ fontSize: '14px', marginBottom: '16px' }}>No digital employees yet.</p>
                <Link href="/dashboard/employees/new" className="btn btn-primary" style={{ fontSize: '13px' }}>
                  Deploy Your First Employee
                </Link>
              </div>
            )}
          </div>

          {/* Tickets Panel */}
          <div>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '16px',
            }}>
              <h2 style={{ fontSize: '18px', fontWeight: 600 }}>Recent Tickets</h2>
              <span style={{
                fontSize: '12px',
                color: 'var(--text-tertiary)',
                fontFamily: 'var(--font-mono)',
              }}>
                Last 10
              </span>
            </div>

            {tickets && tickets.length > 0 ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {tickets.map((ticket: Ticket) => (
                  <div key={ticket.id} className="card" style={{ padding: '14px 16px' }}>
                    <div style={{
                      display: 'flex',
                      alignItems: 'flex-start',
                      justifyContent: 'space-between',
                      gap: '12px',
                    }}>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{
                          fontSize: '13px',
                          fontWeight: 500,
                          marginBottom: '4px',
                          whiteSpace: 'nowrap',
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                        }}>
                          {ticket.question}
                        </div>
                        <div style={{
                          fontSize: '11px',
                          color: 'var(--text-tertiary)',
                          fontFamily: 'var(--font-mono)',
                        }}>
                          {ticket.ticket_ref} · {ticket.submitter_name ?? 'Unknown'} · {ticket.category ?? 'general'} · {new Date(ticket.created_at).toLocaleDateString()}
                        </div>
                      </div>
                      <span className={`badge ${
                        ticket.status === 'resolved' ? 'badge-active' :
                        ticket.status === 'escalated' ? 'badge-inactive' :
                        'badge-setup'
                      }`} style={{ flexShrink: 0 }}>
                        {ticket.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="card" style={{
                padding: '40px',
                textAlign: 'center',
                color: 'var(--text-tertiary)',
              }}>
                <div style={{ fontSize: '32px', marginBottom: '12px' }}>📭</div>
                <p style={{ fontSize: '14px' }}>No tickets yet. They&apos;ll appear here once employees start handling queries.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
