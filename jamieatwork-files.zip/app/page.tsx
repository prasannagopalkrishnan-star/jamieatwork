import Link from 'next/link'

const FEATURED_EMPLOYEES = [
  {
    name: 'Jamie Chen',
    role: 'Benefits Enrollment Specialist',
    company: 'Meridian Health Systems',
    capabilities: ['Open enrollment guidance', 'Plan comparisons', 'Life event changes', 'Claims support'],
    status: 'active' as const,
    avatar: '🏥',
  },
  {
    name: 'Alex Rivera',
    role: 'IT Help Desk Analyst',
    company: 'Available for Hire',
    capabilities: ['Password resets', 'Software provisioning', 'Troubleshooting', 'Onboarding setup'],
    status: 'setup' as const,
    avatar: '💻',
  },
  {
    name: 'Morgan Lee',
    role: 'Compliance Officer',
    company: 'Available for Hire',
    capabilities: ['Policy enforcement', 'Audit preparation', 'Training tracking', 'Regulatory updates'],
    status: 'setup' as const,
    avatar: '📋',
  },
]

const STATS = [
  { label: 'Tickets Resolved', value: '12,847', icon: '⚡' },
  { label: 'Avg Response Time', value: '< 3s', icon: '🕐' },
  { label: 'Satisfaction Rate', value: '94.2%', icon: '✨' },
  { label: 'Cost Savings', value: '68%', icon: '📉' },
]

export default function Home() {
  return (
    <div style={{ minHeight: '100vh' }}>
      {/* Navigation */}
      <nav style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100,
        padding: '16px 0',
        background: 'rgba(10, 10, 15, 0.85)',
        backdropFilter: 'blur(20px)',
        borderBottom: '1px solid var(--border-color)',
      }}>
        <div className="container" style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
          <Link href="/" style={{
            fontFamily: 'var(--font-mono)',
            fontSize: '18px',
            fontWeight: 700,
            letterSpacing: '-0.02em',
          }}>
            <span style={{ color: 'var(--accent-primary)' }}>jamie</span>
            <span style={{ color: 'var(--text-tertiary)' }}>@</span>
            <span>work</span>
          </Link>

          <div style={{ display: 'flex', gap: '8px' }}>
            <Link href="/dashboard" className="btn btn-secondary" style={{ fontSize: '13px', padding: '8px 16px' }}>
              Dashboard
            </Link>
            <Link href="/dashboard" className="btn btn-primary" style={{ fontSize: '13px', padding: '8px 16px' }}>
              Get Started
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section style={{
        paddingTop: '160px',
        paddingBottom: '100px',
        position: 'relative',
        overflow: 'hidden',
      }}>
        {/* Background gradient orbs */}
        <div style={{
          position: 'absolute',
          top: '10%',
          left: '20%',
          width: '400px',
          height: '400px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(34, 211, 167, 0.08) 0%, transparent 70%)',
          filter: 'blur(60px)',
          pointerEvents: 'none',
        }} />
        <div style={{
          position: 'absolute',
          top: '30%',
          right: '10%',
          width: '300px',
          height: '300px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(99, 102, 241, 0.08) 0%, transparent 70%)',
          filter: 'blur(60px)',
          pointerEvents: 'none',
        }} />

        <div className="container" style={{ position: 'relative', textAlign: 'center' }}>
          <div className="animate-in" style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '8px',
            padding: '6px 16px',
            borderRadius: 'var(--radius-full)',
            border: '1px solid var(--border-color)',
            background: 'var(--bg-card)',
            fontSize: '13px',
            color: 'var(--text-secondary)',
            marginBottom: '32px',
          }}>
            <span style={{
              width: '6px',
              height: '6px',
              borderRadius: '50%',
              background: 'var(--accent-primary)',
              animation: 'pulse-glow 2s infinite',
            }} />
            AI-Powered Digital Workforce
          </div>

          <h1 className="animate-in animate-delay-1" style={{
            fontSize: 'clamp(40px, 6vw, 72px)',
            fontWeight: 700,
            lineHeight: 1.05,
            letterSpacing: '-0.03em',
            marginBottom: '24px',
          }}>
            Hire AI employees<br />
            <span className="glow-text">that actually work.</span>
          </h1>

          <p className="animate-in animate-delay-2" style={{
            fontSize: '18px',
            color: 'var(--text-secondary)',
            maxWidth: '560px',
            margin: '0 auto 40px',
            lineHeight: 1.6,
          }}>
            Digital employees that join your org, answer questions, resolve tickets, 
            and integrate with your existing tools — 24/7, no PTO required.
          </p>

          <div className="animate-in animate-delay-3" style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
            <Link href="/dashboard" className="btn btn-primary btn-lg">
              Deploy Your First Employee →
            </Link>
            <a href="#employees" className="btn btn-secondary btn-lg">
              Browse Catalog
            </a>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section style={{
        borderTop: '1px solid var(--border-color)',
        borderBottom: '1px solid var(--border-color)',
        padding: '32px 0',
        background: 'var(--bg-secondary)',
      }}>
        <div className="container" style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(4, 1fr)',
          gap: '24px',
        }}>
          {STATS.map((stat) => (
            <div key={stat.label} style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '24px', marginBottom: '4px' }}>{stat.icon}</div>
              <div style={{
                fontSize: '28px',
                fontWeight: 700,
                fontFamily: 'var(--font-mono)',
                color: 'var(--accent-primary)',
              }}>{stat.value}</div>
              <div style={{
                fontSize: '13px',
                color: 'var(--text-secondary)',
                marginTop: '4px',
              }}>{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Employee Catalog */}
      <section id="employees" style={{ padding: '80px 0' }}>
        <div className="container">
          <div style={{ marginBottom: '48px' }}>
            <h2 style={{
              fontSize: '32px',
              fontWeight: 700,
              letterSpacing: '-0.02em',
              marginBottom: '12px',
            }}>
              Digital Employee Catalog
            </h2>
            <p style={{ color: 'var(--text-secondary)', fontSize: '16px' }}>
              Pre-trained specialists ready to deploy into your organization.
            </p>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))',
            gap: '20px',
          }}>
            {FEATURED_EMPLOYEES.map((emp, i) => (
              <div key={emp.name} className={`card animate-in animate-delay-${i + 1}`}>
                <div style={{
                  display: 'flex',
                  alignItems: 'flex-start',
                  justifyContent: 'space-between',
                  marginBottom: '16px',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div style={{
                      width: '48px',
                      height: '48px',
                      borderRadius: 'var(--radius-md)',
                      background: 'var(--bg-secondary)',
                      border: '1px solid var(--border-color)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '22px',
                    }}>
                      {emp.avatar}
                    </div>
                    <div>
                      <h3 style={{ fontSize: '16px', fontWeight: 600 }}>{emp.name}</h3>
                      <p style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>{emp.role}</p>
                    </div>
                  </div>
                  <span className={`badge badge-${emp.status}`}>
                    {emp.status === 'active' ? '● Live' : '○ Available'}
                  </span>
                </div>

                <p style={{
                  fontSize: '12px',
                  color: 'var(--text-tertiary)',
                  fontFamily: 'var(--font-mono)',
                  marginBottom: '16px',
                }}>
                  {emp.company}
                </p>

                <div style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '6px',
                  marginBottom: '20px',
                }}>
                  {emp.capabilities.map((cap) => (
                    <span key={cap} style={{
                      padding: '4px 10px',
                      borderRadius: 'var(--radius-full)',
                      background: 'var(--bg-secondary)',
                      border: '1px solid var(--border-color)',
                      fontSize: '11px',
                      color: 'var(--text-secondary)',
                    }}>
                      {cap}
                    </span>
                  ))}
                </div>

                <Link href="/dashboard" className="btn btn-secondary" style={{
                  width: '100%',
                  fontSize: '13px',
                }}>
                  {emp.status === 'active' ? 'View Dashboard' : 'Deploy Now'}
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section style={{
        padding: '80px 0',
        borderTop: '1px solid var(--border-color)',
        background: 'var(--bg-secondary)',
      }}>
        <div className="container">
          <h2 style={{
            fontSize: '32px',
            fontWeight: 700,
            letterSpacing: '-0.02em',
            marginBottom: '48px',
            textAlign: 'center',
          }}>
            Deploy in <span className="glow-text">three steps</span>
          </h2>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: '24px',
          }}>
            {[
              {
                step: '01',
                title: 'Choose a Specialist',
                desc: 'Browse our catalog of pre-trained digital employees — benefits, IT, compliance, and more.',
              },
              {
                step: '02',
                title: 'Configure & Train',
                desc: 'Upload your company docs, set policies, and customize personality to match your culture.',
              },
              {
                step: '03',
                title: 'Go Live',
                desc: 'Your digital employee gets an email, phone number, and portal access. They start working immediately.',
              },
            ].map((item) => (
              <div key={item.step} className="card" style={{ textAlign: 'center', padding: '32px' }}>
                <div style={{
                  fontFamily: 'var(--font-mono)',
                  fontSize: '36px',
                  fontWeight: 700,
                  color: 'var(--accent-primary)',
                  marginBottom: '16px',
                  opacity: 0.6,
                }}>
                  {item.step}
                </div>
                <h3 style={{ fontSize: '18px', fontWeight: 600, marginBottom: '8px' }}>
                  {item.title}
                </h3>
                <p style={{ fontSize: '14px', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer style={{
        padding: '40px 0',
        borderTop: '1px solid var(--border-color)',
      }}>
        <div className="container" style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}>
          <div style={{
            fontFamily: 'var(--font-mono)',
            fontSize: '14px',
            color: 'var(--text-tertiary)',
          }}>
            © 2026 jamie@work
          </div>
          <div style={{
            fontSize: '13px',
            color: 'var(--text-tertiary)',
          }}>
            AI digital employees for the modern enterprise
          </div>
        </div>
      </footer>
    </div>
  )
}
