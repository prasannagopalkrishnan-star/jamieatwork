export interface Company {
  id: string
  name: string
  industry: string | null
  created_at: string
}

export interface DigitalEmployee {
  id: string
  company_id: string | null
  name: string
  role: string
  capabilities: string[]
  status: 'active' | 'inactive' | 'setup'
  personality: Record<string, any> | null
  system_prompt: string | null
  created_at: string
}

export interface Ticket {
  id: string
  digital_employee_id: string | null
  employee_name: string | null
  query: string
  response: string | null
  status: 'open' | 'resolved' | 'escalated'
  channel: string | null
  created_at: string
  resolved_at: string | null
}
