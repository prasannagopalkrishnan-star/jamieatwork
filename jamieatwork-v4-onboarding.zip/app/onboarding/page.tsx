'use client'

import { useState, useRef, useEffect } from 'react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'

type Step = 'info' | 'train' | 'review'

interface Message {
  role: 'jamie' | 'user'
  content: string
}

interface PlaybookData {
  product_name: string
  product_description: string
  problem_solved: string
  key_differentiators: string
  target_company_size: string
  target_industries: string
  target_roles: string
  icp_signals: string
  qualification_questions: string[]
  disqualification_criteria: string
  objection_playbook: { objection: string; response: string }[]
  voice_style: string
  call_to_action: string
  calendar_link: string
}

const JAMIE_QUESTIONS = [
  "Hey! I'm Jamie, your new SDR. I'm excited to start selling for you — but first I need to learn about your product. Let's start simple: **What's the name of your product or company, and what do you sell?**",
  "Got it! Now tell me: **What's the core problem you solve for your customers?** Try to describe the pain point they feel before they find you.",
  "That's helpful. **What makes you different from alternatives?** Could be competitors, doing nothing, or DIY solutions. What's your edge?",
  "Now let's talk about who you sell to. **Describe your ideal customer** — company size, industry, the job title of the person who buys. Be as specific as you can.",
  "**What signals tell you a company needs your product right now?** Things like: they just raised funding, they posted a certain job listing, they're using a competitor, they hit a growth milestone, etc.",
  "Perfect. Now let's build your qualification criteria. **What 3-5 questions should I ask a prospect to figure out if they're a real opportunity?** For example: 'Do you currently have a solution for X?' or 'What's your timeline?'",
  "**When should I disqualify a lead?** What are the deal-breakers — too small, wrong industry, no budget, already locked into a competitor? Tell me the red flags.",
  "Let's prep for pushback. **What are the top 3 objections you hear, and how do you handle each one?** For example: 'It's too expensive' → here's how you respond.",
  "Almost done! **How should I sound when talking to prospects?** Casual and friendly? Professional and consultative? Technical? Give me a vibe or paste an example email you've sent that captures your tone.",
  "Last two things: **What's the call-to-action I should drive toward?** (e.g., 'Book a 15-min demo', 'Start a free trial', 'Schedule a call with the founder'). And **paste your calendar link** if you have one (like Calendly).",
]

export default function OnboardingPage() {
  const [step, setStep] = useState<Step>('info')
  const [companyName, setCompanyName] = useState('')
  const [website, setWebsite] = useState('')
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([])
  const [messages, setMessages] = useState<Message[]>([])
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [userInput, setUserInput] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const [playbook, setPlaybook] = useState<PlaybookData | null>(null)
  const [saving, setSaving] = useState(false)
  const [profileId, setProfileId] = useState<string | null>(null)
  const chatEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  // Start training chat
  const startTraining = () => {
    if (!companyName.trim()) return
    setStep('train')
    setTimeout(() => {
      setMessages([{ role: 'jamie', content: JAMIE_QUESTIONS[0] }])
    }, 500)
  }

  // Handle user response in training
  const handleSend = () => {
    if (!userInput.trim()) return
    const newMessages = [...messages, { role: 'user' as const, content: userInput }]
    setMessages(newMessages)
    setUserInput('')
    setIsTyping(true)

    const nextQ = currentQuestion + 1
    setTimeout(() => {
      setIsTyping(false)
      if (nextQ < JAMIE_QUESTIONS.length) {
        setMessages([...newMessages, { role: 'jamie', content: JAMIE_QUESTIONS[nextQ] }])
        setCurrentQuestion(nextQ)
      } else {
        // Training complete — generate playbook
        setMessages([...newMessages, { 
          role: 'jamie', 
          content: "🎉 **That's everything I need!** Let me put together your Sales Playbook. Give me a moment..." 
        }])
        setTimeout(() => generatePlaybook(newMessages), 1500)
      }
    }, 800 + Math.random() * 600)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  // Parse training conversation into playbook
  const generatePlaybook = (allMessages: Message[]) => {
    const userResponses = allMessages.filter(m => m.role === 'user').map(m => m.content)
    
    // Parse qualification questions from response
    const qualLines = (userResponses[5] || '').split(/\n|[0-9]+[\.\)]\s*/).filter(l => l.trim())
    
    // Parse objections
    const objectionText = userResponses[7] || ''
    const objections: { objection: string; response: string }[] = []
    const objParts = objectionText.split(/\n/).filter(l => l.trim())
    for (let i = 0; i < objParts.length; i++) {
      const part = objParts[i]
      const arrowSplit = part.split(/→|->|:/)
      if (arrowSplit.length >= 2) {
        objections.push({ objection: arrowSplit[0].trim(), response: arrowSplit.slice(1).join(':').trim() })
      } else if (part.trim()) {
        objections.push({ objection: part.trim(), response: objParts[i + 1]?.trim() || '' })
        i++
      }
    }

    // Parse CTA and calendar from last response
    const lastResponse = userResponses[9] || ''
    const calMatch = lastResponse.match(/(https?:\/\/[^\s]+)/)?.[1] || ''
    const ctaText = lastResponse.replace(calMatch, '').trim()

    const pb: PlaybookData = {
      product_name: userResponses[0] || '',
      product_description: userResponses[0] || '',
      problem_solved: userResponses[1] || '',
      key_differentiators: userResponses[2] || '',
      target_company_size: userResponses[3] || '',
      target_industries: userResponses[3] || '',
      target_roles: userResponses[3] || '',
      icp_signals: userResponses[4] || '',
      qualification_questions: qualLines.length > 0 ? qualLines : [userResponses[5] || ''],
      disqualification_criteria: userResponses[6] || '',
      objection_playbook: objections.length > 0 ? objections : [{ objection: objectionText, response: '' }],
      voice_style: userResponses[8] || 'professional but friendly',
      call_to_action: ctaText || 'Book a demo',
      calendar_link: calMatch,
    }

    setPlaybook(pb)
    setStep('review')
  }

  // Save to Supabase
  const savePlaybook = async () => {
    if (!playbook) return
    setSaving(true)
    const supabase = createClient()

    // Create or get company
    const { data: company } = await supabase
      .from('companies')
      .insert({ name: companyName, domain: website })
      .select()
      .single()

    if (company) {
      const { data: profile } = await supabase
        .from('onboarding_profiles')
        .insert({
          company_id: company.id,
          status: 'completed',
          product_name: playbook.product_name,
          product_description: playbook.product_description,
          problem_solved: playbook.problem_solved,
          key_differentiators: playbook.key_differentiators,
          target_company_size: playbook.target_company_size,
          target_industries: playbook.target_industries,
          target_roles: playbook.target_roles,
          icp_signals: playbook.icp_signals,
          qualification_questions: playbook.qualification_questions,
          disqualification_criteria: playbook.disqualification_criteria,
          objection_playbook: playbook.objection_playbook,
          voice_style: playbook.voice_style,
          call_to_action: playbook.call_to_action,
          calendar_link: playbook.calendar_link,
          training_transcript: messages,
          uploaded_docs: uploadedFiles,
        })
        .select()
        .single()

      // Create SDR Jamie as a digital employee for this company
      await supabase
        .from('digital_employees')
        .insert({
          company_id: company.id,
          name: 'Jamie',
          title: 'SDR — Sales Development Rep',
          department: 'Sales',
          category: 'sdr',
          status: 'active',
        })

      if (profile) setProfileId(profile.id)
    }

    setSaving(false)
  }

  // File upload handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files) {
      const names = Array.from(files).map(f => f.name)
      setUploadedFiles(prev => [...prev, ...names])
    }
  }

  return (
    <div style={{ minHeight: '100vh' }}>
      {/* Nav */}
      <nav style={{
        position: 'sticky',
        top: 0,
        zIndex: 100,
        padding: '12px 0',
        background: 'rgba(10, 10, 15, 0.9)',
        backdropFilter: 'blur(20px)',
        borderBottom: '1px solid var(--border-color)',
      }}>
        <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Link href="/" style={{ fontFamily: 'var(--font-mono)', fontSize: '16px', fontWeight: 700 }}>
            <span style={{ color: 'var(--accent-primary)' }}>jamie</span>
            <span style={{ color: 'var(--text-tertiary)' }}>@</span>
            <span>work</span>
          </Link>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            {/* Progress indicator */}
            <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
              {(['info', 'train', 'review'] as Step[]).map((s, i) => (
                <div key={s} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <div style={{
                    width: '24px',
                    height: '24px',
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '11px',
                    fontWeight: 700,
                    fontFamily: 'var(--font-mono)',
                    background: step === s ? 'var(--accent-primary)' : 
                      (['info', 'train', 'review'].indexOf(step) > i ? 'rgba(34, 211, 167, 0.2)' : 'var(--bg-card)'),
                    color: step === s ? 'var(--bg-primary)' : 'var(--text-tertiary)',
                    border: `1px solid ${step === s ? 'var(--accent-primary)' : 'var(--border-color)'}`,
                  }}>
                    {i + 1}
                  </div>
                  {i < 2 && (
                    <div style={{
                      width: '24px',
                      height: '1px',
                      background: ['info', 'train', 'review'].indexOf(step) > i ? 'var(--accent-primary)' : 'var(--border-color)',
                    }} />
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </nav>

      {/* Step 1: Company Info & Upload */}
      {step === 'info' && (
        <div className="container" style={{ maxWidth: '600px', padding: '60px 24px' }}>
          <div className="animate-in">
            <h1 style={{ fontSize: '28px', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: '8px' }}>
              Let&apos;s get Jamie up to speed
            </h1>
            <p style={{ color: 'var(--text-secondary)', fontSize: '15px', marginBottom: '40px' }}>
              First, some basics about your company. Then we&apos;ll train Jamie on your product and sales process.
            </p>
          </div>

          <div className="animate-in animate-delay-1" style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            <div>
              <label style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                Company Name *
              </label>
              <input
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                placeholder="e.g., Acme Corp"
                style={{
                  width: '100%',
                  padding: '12px 16px',
                  borderRadius: 'var(--radius-sm)',
                  border: '1px solid var(--border-color)',
                  background: 'var(--bg-card)',
                  color: 'var(--text-primary)',
                  fontSize: '15px',
                  fontFamily: 'var(--font-body)',
                  outline: 'none',
                }}
              />
            </div>

            <div>
              <label style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                Website
              </label>
              <input
                type="text"
                value={website}
                onChange={(e) => setWebsite(e.target.value)}
                placeholder="e.g., acmecorp.com"
                style={{
                  width: '100%',
                  padding: '12px 16px',
                  borderRadius: 'var(--radius-sm)',
                  border: '1px solid var(--border-color)',
                  background: 'var(--bg-card)',
                  color: 'var(--text-primary)',
                  fontSize: '15px',
                  fontFamily: 'var(--font-body)',
                  outline: 'none',
                }}
              />
            </div>

            {/* Document Upload */}
            <div>
              <label style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                Upload Sales Docs (optional)
              </label>
              <p style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '12px' }}>
                Pitch deck, product one-pager, case studies, battle cards — whatever you have.
              </p>
              <label style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                padding: '32px',
                borderRadius: 'var(--radius-md)',
                border: '2px dashed var(--border-color)',
                background: 'var(--bg-secondary)',
                cursor: 'pointer',
                transition: 'all 0.2s',
              }}>
                <input
                  type="file"
                  multiple
                  onChange={handleFileUpload}
                  accept=".pdf,.doc,.docx,.ppt,.pptx,.txt,.csv"
                  style={{ display: 'none' }}
                />
                <div style={{ fontSize: '24px', marginBottom: '8px' }}>📄</div>
                <div style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
                  Click to upload or drag files here
                </div>
                <div style={{ fontSize: '11px', color: 'var(--text-tertiary)', marginTop: '4px' }}>
                  PDF, DOC, PPT, TXT
                </div>
              </label>

              {uploadedFiles.length > 0 && (
                <div style={{ marginTop: '12px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  {uploadedFiles.map((name, i) => (
                    <div key={i} style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      padding: '8px 12px',
                      borderRadius: 'var(--radius-sm)',
                      background: 'var(--bg-card)',
                      border: '1px solid var(--border-color)',
                      fontSize: '13px',
                    }}>
                      <span>📎</span>
                      <span style={{ flex: 1 }}>{name}</span>
                      <button
                        onClick={() => setUploadedFiles(prev => prev.filter((_, idx) => idx !== i))}
                        style={{
                          background: 'none',
                          border: 'none',
                          color: 'var(--text-tertiary)',
                          cursor: 'pointer',
                          fontSize: '14px',
                        }}
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <button
              onClick={startTraining}
              disabled={!companyName.trim()}
              className="btn btn-primary btn-lg"
              style={{
                marginTop: '12px',
                width: '100%',
                opacity: companyName.trim() ? 1 : 0.5,
                cursor: companyName.trim() ? 'pointer' : 'not-allowed',
              }}
            >
              Start Training Jamie →
            </button>
          </div>
        </div>
      )}

      {/* Step 2: Training Chat */}
      {step === 'train' && (
        <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 53px)' }}>
          {/* Chat header */}
          <div style={{
            padding: '16px 24px',
            borderBottom: '1px solid var(--border-color)',
            background: 'var(--bg-secondary)',
          }}>
            <div className="container" style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <div style={{
                width: '36px',
                height: '36px',
                borderRadius: '50%',
                background: 'linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '16px',
              }}>
                🤖
              </div>
              <div>
                <div style={{ fontWeight: 600, fontSize: '14px' }}>Jamie — SDR Training</div>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)' }}>
                  Question {Math.min(currentQuestion + 1, JAMIE_QUESTIONS.length)} of {JAMIE_QUESTIONS.length} · Training for {companyName}
                </div>
              </div>
            </div>
          </div>

          {/* Messages */}
          <div style={{
            flex: 1,
            overflowY: 'auto',
            padding: '24px',
          }}>
            <div className="container" style={{ maxWidth: '700px' }}>
              {messages.map((msg, i) => (
                <div key={i} style={{
                  display: 'flex',
                  justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start',
                  marginBottom: '16px',
                }}>
                  <div style={{
                    maxWidth: '85%',
                    padding: '14px 18px',
                    borderRadius: msg.role === 'user' 
                      ? '16px 16px 4px 16px' 
                      : '16px 16px 16px 4px',
                    background: msg.role === 'user' ? 'var(--accent-primary)' : 'var(--bg-card)',
                    color: msg.role === 'user' ? 'var(--bg-primary)' : 'var(--text-primary)',
                    border: msg.role === 'user' ? 'none' : '1px solid var(--border-color)',
                    fontSize: '14px',
                    lineHeight: 1.6,
                  }}>
                    <span dangerouslySetInnerHTML={{ 
                      __html: msg.content
                        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                        .replace(/\n/g, '<br/>')
                    }} />
                  </div>
                </div>
              ))}

              {isTyping && (
                <div style={{
                  display: 'flex',
                  justifyContent: 'flex-start',
                  marginBottom: '16px',
                }}>
                  <div style={{
                    padding: '14px 18px',
                    borderRadius: '16px 16px 16px 4px',
                    background: 'var(--bg-card)',
                    border: '1px solid var(--border-color)',
                    fontSize: '14px',
                    color: 'var(--text-tertiary)',
                  }}>
                    Jamie is typing...
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>
          </div>

          {/* Input */}
          <div style={{
            padding: '16px 24px',
            borderTop: '1px solid var(--border-color)',
            background: 'var(--bg-secondary)',
          }}>
            <div className="container" style={{ maxWidth: '700px', display: 'flex', gap: '12px' }}>
              <textarea
                ref={inputRef}
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Type your answer... (Enter to send, Shift+Enter for new line)"
                rows={2}
                style={{
                  flex: 1,
                  padding: '12px 16px',
                  borderRadius: 'var(--radius-sm)',
                  border: '1px solid var(--border-color)',
                  background: 'var(--bg-card)',
                  color: 'var(--text-primary)',
                  fontSize: '14px',
                  fontFamily: 'var(--font-body)',
                  resize: 'none',
                  outline: 'none',
                  lineHeight: 1.5,
                }}
              />
              <button
                onClick={handleSend}
                disabled={!userInput.trim() || isTyping}
                className="btn btn-primary"
                style={{
                  alignSelf: 'flex-end',
                  opacity: userInput.trim() && !isTyping ? 1 : 0.5,
                }}
              >
                Send
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Step 3: Review Playbook */}
      {step === 'review' && playbook && (
        <div className="container" style={{ maxWidth: '800px', padding: '40px 24px 80px' }}>
          <div style={{ marginBottom: '32px' }}>
            <h1 style={{ fontSize: '28px', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: '8px' }}>
              Jamie&apos;s Sales Playbook
            </h1>
            <p style={{ color: 'var(--text-secondary)', fontSize: '15px' }}>
              Review what Jamie learned. Edit anything that&apos;s off, then approve to go live.
            </p>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {/* Product */}
            <div className="card">
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--accent-primary)', marginBottom: '12px', fontFamily: 'var(--font-mono)' }}>
                THE PITCH
              </h3>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Product</div>
                <div style={{ fontSize: '14px', lineHeight: 1.6 }}>{playbook.product_name}</div>
              </div>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Problem Solved</div>
                <div style={{ fontSize: '14px', lineHeight: 1.6 }}>{playbook.problem_solved}</div>
              </div>
              <div>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Differentiators</div>
                <div style={{ fontSize: '14px', lineHeight: 1.6 }}>{playbook.key_differentiators}</div>
              </div>
            </div>

            {/* ICP */}
            <div className="card">
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--accent-primary)', marginBottom: '12px', fontFamily: 'var(--font-mono)' }}>
                IDEAL CUSTOMER PROFILE
              </h3>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Target Customer</div>
                <div style={{ fontSize: '14px', lineHeight: 1.6 }}>{playbook.target_company_size}</div>
              </div>
              <div>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Buying Signals</div>
                <div style={{ fontSize: '14px', lineHeight: 1.6 }}>{playbook.icp_signals}</div>
              </div>
            </div>

            {/* Qualification */}
            <div className="card">
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--accent-primary)', marginBottom: '12px', fontFamily: 'var(--font-mono)' }}>
                QUALIFICATION FRAMEWORK
              </h3>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '8px' }}>Questions to Ask</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  {playbook.qualification_questions.map((q, i) => (
                    <div key={i} style={{
                      padding: '8px 12px',
                      borderRadius: 'var(--radius-sm)',
                      background: 'var(--bg-secondary)',
                      border: '1px solid var(--border-color)',
                      fontSize: '13px',
                    }}>
                      {i + 1}. {q}
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Disqualification Criteria</div>
                <div style={{ fontSize: '14px', lineHeight: 1.6, color: 'var(--accent-danger)' }}>{playbook.disqualification_criteria}</div>
              </div>
            </div>

            {/* Objections */}
            <div className="card">
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--accent-primary)', marginBottom: '12px', fontFamily: 'var(--font-mono)' }}>
                OBJECTION PLAYBOOK
              </h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {playbook.objection_playbook.map((obj, i) => (
                  <div key={i} style={{
                    padding: '12px 16px',
                    borderRadius: 'var(--radius-sm)',
                    background: 'var(--bg-secondary)',
                    border: '1px solid var(--border-color)',
                  }}>
                    <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--accent-warning)', marginBottom: '4px' }}>
                      Objection: {obj.objection}
                    </div>
                    <div style={{ fontSize: '13px', color: 'var(--text-secondary)', lineHeight: 1.5 }}>
                      → {obj.response}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Style & CTA */}
            <div className="card">
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--accent-primary)', marginBottom: '12px', fontFamily: 'var(--font-mono)' }}>
                STYLE & CALL TO ACTION
              </h3>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Voice Style</div>
                <div style={{ fontSize: '14px', lineHeight: 1.6 }}>{playbook.voice_style}</div>
              </div>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Call to Action</div>
                <div style={{ fontSize: '14px', lineHeight: 1.6 }}>{playbook.call_to_action}</div>
              </div>
              {playbook.calendar_link && (
                <div>
                  <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Calendar Link</div>
                  <div style={{ fontSize: '14px', fontFamily: 'var(--font-mono)', color: 'var(--accent-primary)' }}>{playbook.calendar_link}</div>
                </div>
              )}
            </div>

            {/* Actions */}
            <div style={{ display: 'flex', gap: '12px', marginTop: '12px' }}>
              <button
                onClick={savePlaybook}
                disabled={saving || !!profileId}
                className="btn btn-primary btn-lg"
                style={{ flex: 1 }}
              >
                {profileId ? '✓ Jamie is Live!' : saving ? 'Deploying Jamie...' : 'Approve & Deploy Jamie →'}
              </button>
              <button
                onClick={() => { setStep('train'); setCurrentQuestion(0); setMessages([]); setPlaybook(null) }}
                className="btn btn-secondary btn-lg"
              >
                Retrain
              </button>
            </div>

            {profileId && (
              <div style={{
                padding: '16px 20px',
                borderRadius: 'var(--radius-md)',
                background: 'rgba(34, 211, 167, 0.08)',
                border: '1px solid rgba(34, 211, 167, 0.2)',
                textAlign: 'center',
              }}>
                <div style={{ fontSize: '15px', fontWeight: 600, color: 'var(--accent-primary)', marginBottom: '8px' }}>
                  🎉 Jamie is deployed and ready to sell for {companyName}!
                </div>
                <Link href="/dashboard" className="btn btn-primary" style={{ fontSize: '13px', marginTop: '8px' }}>
                  Go to Dashboard →
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
