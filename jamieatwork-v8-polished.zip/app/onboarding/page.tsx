'use client'

import { useState, useRef, useEffect } from 'react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'

/* ─── STRIPE/VERCEL WARM PALETTE ─── */
const P = {
  bg: '#FAF9F7',
  bgWash: '#F5F3EE',
  bgCard: '#FFFFFF',
  border: '#E8E5DF',
  borderSubtle: '#F0EDE8',
  borderFocus: '#0D9488',
  text: '#1C1917',
  textMd: '#44403C',
  textSecondary: '#78716C',
  textTertiary: '#A8A29E',
  accent: '#0D9488',
  accentHover: '#0F766E',
  accentLight: '#F0FDFA',
  accentBorder: '#99F6E4',
  secondary: '#D946EF',
  success: '#16A34A',
  successLight: '#F0FDF4',
  warning: '#EA580C',
  danger: '#DC2626',
  gradient: 'linear-gradient(135deg, #0D9488, #06B6D4)',
  gradientWarm: 'linear-gradient(135deg, #EA580C, #F97316)',
  gradientPurple: 'linear-gradient(135deg, #7C3AED, #A855F7)',
  gradientBlue: 'linear-gradient(135deg, #2563EB, #0EA5E9)',
}

type Phase = 'cards' | 'chat' | 'review'
interface Message { role: 'jamie' | 'user'; content: string }
interface PlaybookData {
  product_name: string; product_description: string; problem_solved: string
  key_differentiators: string; target_company_size: string; target_industries: string
  target_roles: string; icp_signals: string; qualification_questions: string[]
  disqualification_criteria: string
  objection_playbook: { objection: string; response: string }[]
  voice_style: string; call_to_action: string; calendar_link: string
}
interface ScrapedData {
  product_name: string; product_description: string; problem_solved: string
  key_differentiators: string; suggested_industries: string; suggested_roles: string
}

const FONTS = `
@import url('https://api.fontshare.com/v2/css?f[]=satoshi@700,800,900&display=swap');
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&display=swap');
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&display=swap');
`

const GLOBAL_STYLES = `
${FONTS}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { background: ${P.bg}; }
.font-display { font-family: 'Satoshi', -apple-system, sans-serif; }
.font-body { font-family: 'DM Sans', -apple-system, sans-serif; }
.font-mono { font-family: 'JetBrains Mono', monospace; }
.noise { position: relative; }
.noise::before {
  content: ''; position: absolute; inset: 0; opacity: 0.025; pointer-events: none;
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
}
@keyframes fadeUp {
  from { opacity: 0; transform: translateY(16px); }
  to { opacity: 1; transform: translateY(0); }
}
@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
@keyframes shimmer {
  0% { background-position: -200% 0; }
  100% { background-position: 200% 0; }
}
.animate-in { animation: fadeUp 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards; opacity: 0; }
.delay-1 { animation-delay: 0.08s; }
.delay-2 { animation-delay: 0.16s; }
.delay-3 { animation-delay: 0.24s; }
.delay-4 { animation-delay: 0.32s; }
.card-hover { transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1); }
.card-hover:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(28,25,23,0.1); border-color: ${P.accent}; }
.vibe-card { transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1); }
.vibe-card:hover { transform: translateY(-3px) scale(1.02); }
`

export default function OnboardingPage() {
  const [cardStep, setCardStep] = useState(0)
  const [website, setWebsite] = useState('')
  const [companyName, setCompanyName] = useState('')
  const [scanning, setScanning] = useState(false)
  const [scanDone, setScanDone] = useState(false)
  const [scraped, setScraped] = useState<ScrapedData | null>(null)
  const [editField, setEditField] = useState<string | null>(null)
  const [editValues, setEditValues] = useState<Record<string, string>>({})
  const [teamSize, setTeamSize] = useState('')
  const [industry, setIndustry] = useState('')
  const [vibe, setVibe] = useState('')
  const [cta, setCta] = useState('')
  const [calendarLink, setCalendarLink] = useState('')
  const [phase, setPhase] = useState<Phase>('cards')
  const [messages, setMessages] = useState<Message[]>([])
  const [userInput, setUserInput] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const [playbook, setPlaybook] = useState<PlaybookData | null>(null)
  const [saving, setSaving] = useState(false)
  const [profileId, setProfileId] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [pbEditing, setPbEditing] = useState<string | null>(null)
  const [pbEdits, setPbEdits] = useState<Record<string, string>>({})
  const chatEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])
  useEffect(() => { if (phase === 'chat' && inputRef.current) inputRef.current.focus() }, [phase, messages])

  const totalCards = 7
  const getFormData = () => ({
    product_name: editValues.product_name || scraped?.product_name || companyName,
    product_description: editValues.product_description || scraped?.product_description || '',
    problem_solved: editValues.problem_solved || scraped?.problem_solved || '',
    key_differentiators: editValues.key_differentiators || scraped?.key_differentiators || '',
    company_size: teamSize, industry, target_roles: editValues.target_roles || scraped?.suggested_roles || '',
    tone: vibe, cta_type: cta, calendar_link: calendarLink,
  })

  const scanWebsite = async () => {
    if (!website.trim()) return
    setScanning(true); setError(null)
    try {
      const res = await fetch('/api/training', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'scrape_website', website }) })
      const data = await res.json()
      if (data.extracted) { setScraped(data.extracted); setCompanyName(data.extracted.product_name || '') }
      setScanDone(true); setTimeout(() => setCardStep(1), 500)
    } catch { setScanDone(true); setTimeout(() => setCardStep(1), 300) }
    setScanning(false)
  }

  const startChat = async () => {
    setPhase('chat'); setIsTyping(true); setError(null)
    try {
      const res = await fetch('/api/training', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'chat',
          messages: [{ role: 'user', content: `Hi Jamie, I'm the founder of ${companyName || 'my company'}. Ready for your questions.` }],
          companyName: companyName || 'the company', formData: getFormData() }) })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      setMessages([{ role: 'jamie', content: data.message }])
    } catch { setError('Failed to connect.') }
    setIsTyping(false)
  }

  const handleSend = async () => {
    if (!userInput.trim() || isTyping) return
    const newMsgs: Message[] = [...messages, { role: 'user', content: userInput }]
    setMessages(newMsgs); setUserInput(''); setIsTyping(true); setError(null)
    try {
      const res = await fetch('/api/training', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'chat', messages: newMsgs, companyName, formData: getFormData() }) })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      const updated: Message[] = [...newMsgs, { role: 'jamie', content: data.message }]
      setMessages(updated)
      if (data.message.includes('🎉') || data.message.toLowerCase().includes('got everything') || data.message.toLowerCase().includes('playbook now'))
        setTimeout(() => generatePlaybook(updated), 1500)
    } catch { setError('Failed to get response.') }
    setIsTyping(false)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend() } }

  const generatePlaybook = async (msgs: Message[]) => {
    setIsTyping(true)
    try {
      const res = await fetch('/api/training', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'generate_playbook', messages: msgs, companyName, formData: getFormData() }) })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      setPlaybook(data.playbook); setPhase('review')
    } catch { setError('Failed to generate playbook.') }
    setIsTyping(false)
  }

  const savePlaybook = async () => {
    if (!playbook) return
    setSaving(true); setError(null)
    const supabase = createClient()
    // Apply any inline edits to playbook
    const finalPlaybook = { ...playbook }
    Object.entries(pbEdits).forEach(([key, val]) => {
      if (key in finalPlaybook) (finalPlaybook as Record<string, unknown>)[key] = val
    })
    try {
      const { data: company, error: ce } = await supabase.from('companies')
        .insert({ name: companyName || finalPlaybook.product_name, domain: website }).select().single()
      if (ce) throw ce
      const { data: profile, error: pe } = await supabase.from('onboarding_profiles').insert({
        company_id: company.id, status: 'completed', ...finalPlaybook,
        training_transcript: messages, uploaded_docs: [],
      }).select().single()
      if (pe) throw pe
      await supabase.from('digital_employees').insert({
        company_id: company.id, name: 'Jamie', title: 'SDR — Sales Development Rep',
        department: 'Sales', category: 'sdr', status: 'active',
      })
      if (profile) setProfileId(profile.id)
    } catch { setError('Failed to save.') }
    setSaving(false)
  }

  /* ─── SHARED COMPONENTS ─── */
  const Dots = () => {
    const cur = phase === 'cards' ? cardStep : phase === 'chat' ? totalCards : totalCards + 1
    return (
      <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
        {Array.from({ length: totalCards + 1 }).map((_, i) => (
          <div key={i} style={{
            width: i === cur ? '20px' : '6px', height: '6px', borderRadius: '3px',
            background: i < cur ? P.accent : i === cur ? P.accent : P.border,
            opacity: i < cur ? 0.3 : 1, transition: 'all 0.5s cubic-bezier(0.16,1,0.3,1)',
          }} />
        ))}
      </div>
    )
  }

  const Shell = ({ children, title, sub }: { children: React.ReactNode; title: string; sub: string }) => (
    <div className="noise" style={{ minHeight: '100vh', background: P.bg }}>
      <style dangerouslySetInnerHTML={{ __html: GLOBAL_STYLES }} />
      <nav style={{
        position: 'sticky', top: 0, zIndex: 100, padding: '14px 28px',
        background: 'rgba(250,249,247,0.8)', backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)',
        borderBottom: `1px solid ${P.borderSubtle}`,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: '10px', textDecoration: 'none', color: P.text }}>
          <div style={{ width: '30px', height: '30px', borderRadius: '9px', background: P.gradient,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: 'white', fontSize: '14px', fontWeight: 800, fontFamily: "'Satoshi', sans-serif",
          }}>J</div>
          <span className="font-display" style={{ fontSize: '15px', fontWeight: 800, letterSpacing: '-0.03em' }}>
            jamie<span style={{ color: P.textTertiary, fontWeight: 400 }}>@</span>work
          </span>
        </Link>
        <Dots />
      </nav>
      {error && <div style={{ padding: '10px 28px', background: '#FEF2F2', borderBottom: '1px solid #FECACA', textAlign: 'center', fontSize: '13px', color: P.danger }} className="font-body">{error}</div>}
      <div style={{ maxWidth: '540px', margin: '0 auto', padding: '72px 24px 60px', display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}>
        <h1 className="font-display animate-in" style={{ fontSize: '34px', fontWeight: 800, color: P.text, letterSpacing: '-0.04em', margin: '0 0 10px', lineHeight: 1.1 }}>{title}</h1>
        <p className="font-body animate-in delay-1" style={{ fontSize: '15px', color: P.textSecondary, margin: '0 0 44px', lineHeight: 1.6, maxWidth: '420px' }}>{sub}</p>
        {children}
      </div>
    </div>
  )

  const Back = ({ onClick }: { onClick: () => void }) => (
    <button onClick={onClick} className="font-body" style={{ marginTop: '28px', background: 'none', border: 'none', color: P.textTertiary, fontSize: '13px', cursor: 'pointer', letterSpacing: '-0.01em' }}>← Back</button>
  )

  /* ─── STEP 0: WEBSITE ─── */
  if (phase === 'cards' && cardStep === 0) return (
    <Shell title="What's your website?" sub="Jamie reads your site and fills in everything she can — you just review.">
      <div className="animate-in delay-2" style={{ width: '100%' }}>
        <div style={{
          display: 'flex', gap: '8px', padding: '5px', borderRadius: '16px',
          background: P.bgCard, border: `2px solid ${scanning ? P.accent : P.border}`,
          boxShadow: scanning ? `0 0 0 4px ${P.accentLight}` : '0 2px 8px rgba(28,25,23,0.04)',
          transition: 'all 0.3s',
        }}>
          <div className="font-mono" style={{ display: 'flex', alignItems: 'center', paddingLeft: '16px', color: P.textTertiary, fontSize: '13px' }}>https://</div>
          <input type="text" value={website} onChange={e => setWebsite(e.target.value)}
            placeholder="yourcompany.com" onKeyDown={e => e.key === 'Enter' && scanWebsite()} autoFocus
            className="font-body" style={{ flex: 1, padding: '15px 0', background: 'none', border: 'none', outline: 'none', color: P.text, fontSize: '16px' }} />
          <button onClick={scanWebsite} disabled={scanning || !website.trim()} className="font-body"
            style={{
              padding: '12px 22px', borderRadius: '12px', border: 'none',
              background: scanning ? P.bgWash : P.gradient,
              color: scanning ? P.textSecondary : 'white',
              fontSize: '14px', fontWeight: 600, cursor: website.trim() && !scanning ? 'pointer' : 'default',
              transition: 'all 0.2s', display: 'flex', alignItems: 'center', gap: '6px',
            }}>
            {scanning ? <><span style={{ display: 'inline-block', animation: 'spin 1s linear infinite' }}>⟳</span> Reading...</> : '🔍 Scan'}
          </button>
        </div>
        <button onClick={() => { setScanDone(true); setCardStep(1) }} className="font-body"
          style={{ marginTop: '20px', background: 'none', border: 'none', color: P.textTertiary, fontSize: '13px', cursor: 'pointer', textDecoration: 'underline', textUnderlineOffset: '3px' }}>
          Skip — I&apos;ll fill it in myself
        </button>
      </div>
    </Shell>
  )

  /* ─── STEP 1: WHAT JAMIE LEARNED ─── */
  if (phase === 'cards' && cardStep === 1) {
    const fields = [
      { key: 'product_name', label: 'PRODUCT', value: scraped?.product_name || '', placeholder: 'Your product name' },
      { key: 'product_description', label: 'WHAT YOU SELL', value: scraped?.product_description || '', placeholder: 'Describe in 1–2 sentences' },
      { key: 'problem_solved', label: 'PROBLEM YOU SOLVE', value: scraped?.problem_solved || '', placeholder: 'The core pain point' },
      { key: 'key_differentiators', label: 'YOUR EDGE', value: scraped?.key_differentiators || '', placeholder: 'What makes you different' },
    ]
    return (
      <Shell title={scraped ? "Here's what Jamie found" : "Tell Jamie about your product"} sub={scraped ? "Click any field to edit. When it looks right, continue." : "Fill in the basics — takes about 2 minutes."}>
        <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: '10px' }}>
          {fields.map((f, i) => (
            <div key={f.key} className={`animate-in delay-${i + 1}`}
              onClick={() => setEditField(f.key)}
              style={{
                padding: '14px 18px', borderRadius: '14px', background: P.bgCard, textAlign: 'left',
                border: `1.5px solid ${editField === f.key ? P.borderFocus : P.border}`,
                boxShadow: editField === f.key ? `0 0 0 3px ${P.accentLight}` : '0 1px 4px rgba(28,25,23,0.03)',
                cursor: 'text', transition: 'all 0.2s',
              }}>
              <div className="font-mono" style={{ fontSize: '10px', fontWeight: 600, color: P.textTertiary, marginBottom: '5px', letterSpacing: '0.08em' }}>{f.label}</div>
              {editField === f.key ? (
                <textarea autoFocus value={editValues[f.key] ?? f.value}
                  onChange={e => setEditValues(p => ({ ...p, [f.key]: e.target.value }))} onBlur={() => setEditField(null)}
                  rows={2} className="font-body"
                  style={{ width: '100%', background: 'none', border: 'none', outline: 'none', color: P.text, fontSize: '14px', lineHeight: 1.6, resize: 'none' }} />
              ) : (
                <div className="font-body" style={{ fontSize: '14px', color: (editValues[f.key] || f.value) ? P.text : P.textTertiary, lineHeight: 1.6 }}>
                  {editValues[f.key] || f.value || f.placeholder}
                </div>
              )}
            </div>
          ))}
          <button onClick={() => { setCompanyName(editValues.product_name || scraped?.product_name || companyName); setCardStep(2) }}
            className="font-body animate-in delay-4"
            style={{ marginTop: '8px', padding: '15px', borderRadius: '14px', border: 'none', background: P.gradient, color: 'white', fontSize: '15px', fontWeight: 600, cursor: 'pointer', boxShadow: '0 4px 14px rgba(13,148,136,0.25)' }}>
            Looks good →
          </button>
          <Back onClick={() => setCardStep(0)} />
        </div>
      </Shell>
    )
  }

  /* ─── STEP 2: TEAM SIZE ─── */
  if (phase === 'cards' && cardStep === 2) {
    const sizes = [
      { label: 'Just me', icon: '👤', v: '1' }, { label: '2–10', icon: '👥', v: '2-10' },
      { label: '11–50', icon: '🏢', v: '11-50' }, { label: '51–200', icon: '🏙️', v: '51-200' },
      { label: '200+', icon: '🌆', v: '200+' },
    ]
    return (
      <Shell title="How big is your team?" sub="Jamie calibrates her pitch based on your stage.">
        <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', justifyContent: 'center' }}>
          {sizes.map((s, i) => (
            <button key={s.v} onClick={() => { setTeamSize(s.v); setCardStep(3) }}
              className={`card-hover font-body animate-in delay-${i + 1}`}
              style={{ width: '94px', padding: '22px 8px', borderRadius: '16px', background: P.bgCard, border: `1.5px solid ${P.border}`, boxShadow: '0 2px 8px rgba(28,25,23,0.04)', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px', color: P.text }}>
              <span style={{ fontSize: '30px' }}>{s.icon}</span>
              <span style={{ fontSize: '13px', fontWeight: 500 }}>{s.label}</span>
            </button>
          ))}
        </div>
        <Back onClick={() => setCardStep(1)} />
      </Shell>
    )
  }

  /* ─── STEP 3: INDUSTRY ─── */
  if (phase === 'cards' && cardStep === 3) {
    const inds = [
      { l: 'SaaS', i: '💻' }, { l: 'Fintech', i: '🏦' }, { l: 'Health', i: '🏥' }, { l: 'E-comm', i: '🛒' },
      { l: 'Agency', i: '🎨' }, { l: 'Education', i: '📚' }, { l: 'AI / ML', i: '🤖' }, { l: 'Other', i: '✨' },
    ]
    return (
      <Shell title="Your industry?" sub="Helps Jamie speak the right language.">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '10px', width: '100%', maxWidth: '400px' }}>
          {inds.map((ind, i) => (
            <button key={ind.l} onClick={() => { setIndustry(ind.l); setCardStep(4) }}
              className={`card-hover font-body animate-in delay-${(i % 4) + 1}`}
              style={{ padding: '20px 8px', borderRadius: '16px', background: P.bgCard, border: `1.5px solid ${P.border}`, boxShadow: '0 2px 8px rgba(28,25,23,0.04)', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px', color: P.text }}>
              <span style={{ fontSize: '26px' }}>{ind.i}</span>
              <span style={{ fontSize: '12px', fontWeight: 500 }}>{ind.l}</span>
            </button>
          ))}
        </div>
        <Back onClick={() => setCardStep(2)} />
      </Shell>
    )
  }

  /* ─── STEP 4: VIBE ─── */
  if (phase === 'cards' && cardStep === 4) {
    const vibes = [
      { label: 'Chill', emoji: '🌊', sub: '"Hey! Love what you\'re building..."', g: P.gradient },
      { label: 'Sharp', emoji: '⚡', sub: '"You\'re leaving money on the table."', g: P.gradientPurple },
      { label: 'Warm', emoji: '☀️', sub: '"I\'d love to learn about your team..."', g: P.gradientWarm },
      { label: 'Nerdy', emoji: '🤓', sub: '"Based on your stack and growth..."', g: P.gradientBlue },
    ]
    return (
      <Shell title="Pick Jamie's personality" sub="Hover to preview how she'll sound.">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', width: '100%', maxWidth: '420px' }}>
          {vibes.map((v, i) => (
            <button key={v.label}
              onClick={() => { setVibe(v.label); setCardStep(5) }}
              className={`vibe-card font-body animate-in delay-${i + 1}`}
              style={{ padding: '26px 18px', borderRadius: '18px', textAlign: 'left', background: P.bgCard, border: `1.5px solid ${P.border}`, boxShadow: '0 2px 8px rgba(28,25,23,0.04)', cursor: 'pointer', color: P.text, position: 'relative', overflow: 'hidden' }}
              onMouseEnter={e => { e.currentTarget.style.background = v.g; e.currentTarget.style.color = 'white'; e.currentTarget.style.borderColor = 'transparent'; e.currentTarget.style.boxShadow = '0 12px 32px rgba(0,0,0,0.15)' }}
              onMouseLeave={e => { e.currentTarget.style.background = P.bgCard; e.currentTarget.style.color = P.text; e.currentTarget.style.borderColor = P.border; e.currentTarget.style.boxShadow = '0 2px 8px rgba(28,25,23,0.04)' }}>
              <div style={{ fontSize: '30px', marginBottom: '10px' }}>{v.emoji}</div>
              <div className="font-display" style={{ fontSize: '17px', fontWeight: 800, marginBottom: '6px', letterSpacing: '-0.02em' }}>{v.label}</div>
              <div style={{ fontSize: '12px', opacity: 0.7, lineHeight: 1.4, fontStyle: 'italic' }}>{v.sub}</div>
            </button>
          ))}
        </div>
        <Back onClick={() => setCardStep(3)} />
      </Shell>
    )
  }

  /* ─── STEP 5: CTA ─── */
  if (phase === 'cards' && cardStep === 5) {
    const ctas = [
      { l: 'Book a demo', i: '📅', c: P.accent }, { l: 'Start free trial', i: '🚀', c: '#7C3AED' },
      { l: 'Schedule a call', i: '📞', c: '#2563EB' }, { l: 'Get a quote', i: '💰', c: P.warning },
    ]
    return (
      <Shell title="What's the goal?" sub="Every qualified conversation should end with...">
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', width: '100%', maxWidth: '380px' }}>
          {ctas.map((c, i) => (
            <button key={c.l} onClick={() => { setCta(c.l); setCardStep(6) }}
              className={`card-hover font-body animate-in delay-${i + 1}`}
              style={{ padding: '16px 20px', borderRadius: '14px', background: P.bgCard, border: `1.5px solid ${P.border}`, boxShadow: '0 2px 8px rgba(28,25,23,0.04)', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '14px', color: P.text, textAlign: 'left' }}>
              <div style={{ width: '44px', height: '44px', borderRadius: '12px', background: `${c.c}10`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '22px', flexShrink: 0 }}>{c.i}</div>
              <span style={{ fontSize: '15px', fontWeight: 600 }}>{c.l}</span>
            </button>
          ))}
        </div>
        <Back onClick={() => setCardStep(4)} />
      </Shell>
    )
  }

  /* ─── STEP 6: CALENDAR ─── */
  if (phase === 'cards' && cardStep === 6) return (
    <Shell title="Drop your calendar link" sub="Jamie sends qualified leads here to book time with you.">
      <div className="animate-in delay-2" style={{ width: '100%', maxWidth: '420px' }}>
        <div style={{
          display: 'flex', gap: '8px', padding: '5px', borderRadius: '16px',
          background: P.bgCard, border: `2px solid ${P.border}`, boxShadow: '0 2px 8px rgba(28,25,23,0.04)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', paddingLeft: '16px', fontSize: '18px' }}>📅</div>
          <input type="text" value={calendarLink} onChange={e => setCalendarLink(e.target.value)}
            placeholder="calendly.com/you" autoFocus className="font-body"
            style={{ flex: 1, padding: '15px 0', background: 'none', border: 'none', outline: 'none', color: P.text, fontSize: '16px' }} />
        </div>
        <button onClick={startChat} className="font-body"
          style={{ marginTop: '20px', width: '100%', padding: '15px', borderRadius: '14px', border: 'none', background: P.gradient, color: 'white', fontSize: '15px', fontWeight: 600, cursor: 'pointer', boxShadow: '0 4px 14px rgba(13,148,136,0.25)' }}>
          Almost done — 3 quick questions →
        </button>
        <button onClick={() => { setCalendarLink(''); startChat() }} className="font-body"
          style={{ marginTop: '12px', background: 'none', border: 'none', color: P.textTertiary, fontSize: '13px', cursor: 'pointer', textDecoration: 'underline', textUnderlineOffset: '3px' }}>
          Skip for now
        </button>
        <Back onClick={() => setCardStep(5)} />
      </div>
    </Shell>
  )

  /* ─── CHAT ─── */
  if (phase === 'chat') return (
    <div className="noise" style={{ minHeight: '100vh', background: P.bg, display: 'flex', flexDirection: 'column' }}>
      <style dangerouslySetInnerHTML={{ __html: GLOBAL_STYLES }} />
      <nav style={{ position: 'sticky', top: 0, zIndex: 100, padding: '14px 28px', background: 'rgba(250,249,247,0.8)', backdropFilter: 'blur(20px)', borderBottom: `1px solid ${P.borderSubtle}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: '10px', textDecoration: 'none', color: P.text }}>
          <div style={{ width: '30px', height: '30px', borderRadius: '9px', background: P.gradient, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: '14px', fontWeight: 800 }}>J</div>
          <span className="font-display" style={{ fontSize: '15px', fontWeight: 800, letterSpacing: '-0.03em' }}>jamie<span style={{ color: P.textTertiary, fontWeight: 400 }}>@</span>work</span>
        </Link>
        <Dots />
      </nav>
      {error && <div style={{ padding: '10px 28px', background: '#FEF2F2', borderBottom: '1px solid #FECACA', textAlign: 'center', fontSize: '13px', color: P.danger }} className="font-body">{error}</div>}
      <div style={{ padding: '12px 28px', borderBottom: `1px solid ${P.borderSubtle}`, background: P.bgCard }}>
        <div style={{ maxWidth: '680px', margin: '0 auto', display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{ width: '38px', height: '38px', borderRadius: '10px', background: P.gradient, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: '18px' }}>🤖</div>
          <div>
            <div className="font-display" style={{ fontWeight: 700, fontSize: '14px', color: P.text, letterSpacing: '-0.02em' }}>Jamie — Quick Questions</div>
            <div className="font-body" style={{ fontSize: '12px', color: P.textTertiary }}>3 questions to finish training for {companyName || 'your company'}</div>
          </div>
        </div>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: '24px 28px' }}>
        <div style={{ maxWidth: '680px', margin: '0 auto' }}>
          {messages.map((msg, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start', marginBottom: '14px' }}>
              <div className="font-body" style={{
                maxWidth: '78%', padding: '14px 18px',
                borderRadius: msg.role === 'user' ? '16px 16px 4px 16px' : '16px 16px 16px 4px',
                background: msg.role === 'user' ? P.accent : P.bgCard,
                color: msg.role === 'user' ? 'white' : P.text,
                border: msg.role === 'user' ? 'none' : `1px solid ${P.border}`,
                boxShadow: '0 1px 4px rgba(28,25,23,0.04)', fontSize: '14px', lineHeight: 1.65,
              }}>
                <span dangerouslySetInnerHTML={{ __html: msg.content.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>') }} />
              </div>
            </div>
          ))}
          {isTyping && <div style={{ display: 'flex', marginBottom: '14px' }}><div className="font-body" style={{ padding: '14px 18px', borderRadius: '16px 16px 16px 4px', background: P.bgCard, border: `1px solid ${P.border}`, fontSize: '14px', color: P.textTertiary }}>Jamie is thinking...</div></div>}
          <div ref={chatEndRef} />
        </div>
      </div>
      <div style={{ padding: '16px 28px', borderTop: `1px solid ${P.borderSubtle}`, background: P.bgCard }}>
        <div style={{ maxWidth: '680px', margin: '0 auto', display: 'flex', gap: '10px' }}>
          <textarea ref={inputRef} value={userInput} onChange={e => setUserInput(e.target.value)} onKeyDown={handleKeyDown}
            placeholder="Type your answer... (Enter to send)" rows={2} className="font-body"
            style={{ flex: 1, padding: '12px 16px', borderRadius: '12px', border: `1.5px solid ${P.border}`, background: P.bg, color: P.text, fontSize: '14px', resize: 'none', outline: 'none', lineHeight: 1.5 }}
            onFocus={e => e.currentTarget.style.borderColor = P.accent} onBlur={e => e.currentTarget.style.borderColor = P.border} />
          <button onClick={handleSend} disabled={!userInput.trim() || isTyping} className="font-body"
            style={{ alignSelf: 'flex-end', padding: '12px 20px', borderRadius: '12px', background: userInput.trim() && !isTyping ? P.gradient : P.bgWash, border: 'none', color: userInput.trim() && !isTyping ? 'white' : P.textTertiary, fontSize: '14px', fontWeight: 600, cursor: userInput.trim() && !isTyping ? 'pointer' : 'default' }}>Send</button>
        </div>
      </div>
    </div>
  )

  /* ─── REVIEW ─── */
  if (phase === 'review' && playbook) {
    const EditableField = ({ label, fieldKey, value }: { label: string; fieldKey: string; value: string }) => (
      <div style={{ marginBottom: '12px' }} onClick={() => setPbEditing(fieldKey)}>
        <div className="font-mono" style={{ fontSize: '10px', color: P.textTertiary, marginBottom: '4px', letterSpacing: '0.06em', textTransform: 'uppercase' }}>{label}</div>
        {pbEditing === fieldKey ? (
          <textarea autoFocus value={pbEdits[fieldKey] ?? value}
            onChange={e => setPbEdits(p => ({ ...p, [fieldKey]: e.target.value }))}
            onBlur={() => setPbEditing(null)} rows={2} className="font-body"
            style={{ width: '100%', background: P.accentLight, border: `1.5px solid ${P.accentBorder}`, borderRadius: '8px', padding: '8px 12px', color: P.text, fontSize: '14px', lineHeight: 1.6, resize: 'none', outline: 'none' }} />
        ) : (
          <div className="font-body" style={{ fontSize: '14px', color: P.text, lineHeight: 1.6, cursor: 'text', padding: '2px 0', borderBottom: `1px dashed transparent` }}
            onMouseEnter={e => e.currentTarget.style.borderBottomColor = P.border}
            onMouseLeave={e => e.currentTarget.style.borderBottomColor = 'transparent'}>
            {pbEdits[fieldKey] || value}
          </div>
        )}
      </div>
    )

    return (
      <div className="noise" style={{ minHeight: '100vh', background: P.bg }}>
        <style dangerouslySetInnerHTML={{ __html: GLOBAL_STYLES }} />
        <nav style={{ position: 'sticky', top: 0, zIndex: 100, padding: '14px 28px', background: 'rgba(250,249,247,0.8)', backdropFilter: 'blur(20px)', borderBottom: `1px solid ${P.borderSubtle}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: '10px', textDecoration: 'none', color: P.text }}>
            <div style={{ width: '30px', height: '30px', borderRadius: '9px', background: P.gradient, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: '14px', fontWeight: 800 }}>J</div>
            <span className="font-display" style={{ fontSize: '15px', fontWeight: 800, letterSpacing: '-0.03em' }}>jamie<span style={{ color: P.textTertiary, fontWeight: 400 }}>@</span>work</span>
          </Link>
          <Dots />
        </nav>
        {error && <div style={{ padding: '10px 28px', background: '#FEF2F2', borderBottom: '1px solid #FECACA', textAlign: 'center', fontSize: '13px', color: P.danger }} className="font-body">{error}</div>}
        <div style={{ maxWidth: '720px', margin: '0 auto', padding: '40px 24px 80px' }}>
          <h1 className="font-display" style={{ fontSize: '30px', fontWeight: 800, color: P.text, letterSpacing: '-0.03em', margin: '0 0 6px' }}>Jamie&apos;s Sales Playbook</h1>
          <p className="font-body" style={{ fontSize: '14px', color: P.textSecondary, margin: '0 0 8px' }}>Click any field to edit inline. Deploy when it looks right.</p>
          <div className="font-mono" style={{ fontSize: '11px', color: P.accent, marginBottom: '32px', background: P.accentLight, display: 'inline-block', padding: '4px 12px', borderRadius: '6px', border: `1px solid ${P.accentBorder}` }}>✎ All fields are editable</div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {[
              { title: 'THE PITCH', fields: [['Product', 'product_name', playbook.product_name], ['Description', 'product_description', playbook.product_description], ['Problem', 'problem_solved', playbook.problem_solved], ['Edge', 'key_differentiators', playbook.key_differentiators]] },
              { title: 'IDEAL CUSTOMER', fields: [['Size', 'target_company_size', playbook.target_company_size], ['Industries', 'target_industries', playbook.target_industries], ['Buyers', 'target_roles', playbook.target_roles], ['Signals', 'icp_signals', playbook.icp_signals]] },
            ].map(section => (
              <div key={section.title} style={{ padding: '20px 24px', borderRadius: '16px', background: P.bgCard, border: `1px solid ${P.border}`, boxShadow: '0 1px 4px rgba(28,25,23,0.03)', textAlign: 'left' }}>
                <div className="font-mono" style={{ fontSize: '11px', fontWeight: 700, color: P.accent, marginBottom: '14px', letterSpacing: '0.08em' }}>{section.title}</div>
                {section.fields.map(([label, key, val]) => <EditableField key={key} label={label as string} fieldKey={key as string} value={val as string} />)}
              </div>
            ))}

            <div style={{ padding: '20px 24px', borderRadius: '16px', background: P.bgCard, border: `1px solid ${P.border}`, boxShadow: '0 1px 4px rgba(28,25,23,0.03)', textAlign: 'left' }}>
              <div className="font-mono" style={{ fontSize: '11px', fontWeight: 700, color: P.accent, marginBottom: '14px', letterSpacing: '0.08em' }}>QUALIFICATION</div>
              {playbook.qualification_questions.map((q, i) => (
                <div key={i} className="font-body" style={{ padding: '10px 14px', borderRadius: '10px', marginBottom: '6px', background: P.bgWash, border: `1px solid ${P.borderSubtle}`, fontSize: '13px', color: P.text, lineHeight: 1.5 }}>
                  <span className="font-mono" style={{ color: P.accent, fontWeight: 700, marginRight: '8px', fontSize: '12px' }}>{i + 1}.</span>{q}
                </div>
              ))}
              <EditableField label="Walk away when" fieldKey="disqualification_criteria" value={playbook.disqualification_criteria} />
            </div>

            <div style={{ padding: '20px 24px', borderRadius: '16px', background: P.bgCard, border: `1px solid ${P.border}`, boxShadow: '0 1px 4px rgba(28,25,23,0.03)', textAlign: 'left' }}>
              <div className="font-mono" style={{ fontSize: '11px', fontWeight: 700, color: P.accent, marginBottom: '14px', letterSpacing: '0.08em' }}>OBJECTIONS</div>
              {playbook.objection_playbook.map((obj, i) => (
                <div key={i} style={{ padding: '14px 16px', borderRadius: '12px', marginBottom: '10px', background: P.bgWash, border: `1px solid ${P.borderSubtle}` }}>
                  <div className="font-body" style={{ fontSize: '13px', fontWeight: 600, color: P.warning, marginBottom: '6px' }}>&ldquo;{obj.objection}&rdquo;</div>
                  <div className="font-body" style={{ fontSize: '13px', color: P.textSecondary, lineHeight: 1.5 }}>→ {obj.response}</div>
                </div>
              ))}
            </div>

            <div style={{ padding: '20px 24px', borderRadius: '16px', background: P.bgCard, border: `1px solid ${P.border}`, boxShadow: '0 1px 4px rgba(28,25,23,0.03)', textAlign: 'left' }}>
              <div className="font-mono" style={{ fontSize: '11px', fontWeight: 700, color: P.accent, marginBottom: '14px', letterSpacing: '0.08em' }}>STYLE & CTA</div>
              <EditableField label="Voice" fieldKey="voice_style" value={playbook.voice_style} />
              <EditableField label="Call to action" fieldKey="call_to_action" value={playbook.call_to_action} />
              <EditableField label="Calendar" fieldKey="calendar_link" value={playbook.calendar_link} />
            </div>

            <div style={{ display: 'flex', gap: '10px', marginTop: '8px' }}>
              <button onClick={savePlaybook} disabled={saving || !!profileId} className="font-body"
                style={{ flex: 1, padding: '16px', borderRadius: '14px', border: 'none', background: profileId ? P.success : saving ? P.bgWash : P.gradient, color: 'white', fontSize: '16px', fontWeight: 700, cursor: saving || profileId ? 'default' : 'pointer', boxShadow: '0 4px 14px rgba(13,148,136,0.25)' }}>
                {profileId ? '✓ Jamie is Live!' : saving ? 'Deploying...' : 'Approve & Deploy Jamie →'}
              </button>
              <button onClick={() => { setPhase('cards'); setCardStep(0); setMessages([]); setPlaybook(null); setPbEdits({}) }} className="font-body"
                style={{ padding: '16px 24px', borderRadius: '14px', background: P.bgCard, border: `1.5px solid ${P.border}`, color: P.textSecondary, fontSize: '14px', fontWeight: 600, cursor: 'pointer' }}>Start Over</button>
            </div>

            {profileId && (
              <div style={{ padding: '20px', borderRadius: '16px', textAlign: 'center', background: P.accentLight, border: `1px solid ${P.accentBorder}` }}>
                <div className="font-display" style={{ fontSize: '16px', fontWeight: 800, color: P.accent, marginBottom: '10px', letterSpacing: '-0.02em' }}>🎉 Jamie is deployed and selling for {companyName}!</div>
                <Link href="/dashboard" className="font-body" style={{ display: 'inline-block', padding: '10px 24px', borderRadius: '10px', background: P.gradient, color: 'white', fontSize: '14px', fontWeight: 600, textDecoration: 'none' }}>Go to Dashboard →</Link>
              </div>
            )}
          </div>
        </div>
      </div>
    )
  }

  return null
}
