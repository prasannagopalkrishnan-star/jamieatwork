'use client'

import { useState, useRef, useEffect } from 'react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'

type Step = 'info' | 'train' | 'review'

interface Message {
  role: 'jamie' | 'user'
  content: string
}

interface FormData {
  product_name: string
  product_description: string
  problem_solved: string
  key_differentiators: string
  company_size: string
  industry: string
  target_roles: string
  tone: string
  cta_type: string
  calendar_link: string
}

interface PlaybookData {
  product_name: string
  product_description: string
  problem_solved: string
  key_differentiators: string
  target_company_size: string
  target_industries: string
  target_roles: string
  icp_signals: string
  qualification_questions: string[]
  disqualification_criteria: string
  objection_playbook: { objection: string; response: string }[]
  voice_style: string
  call_to_action: string
  calendar_link: string
}

const COMPANY_SIZES = ['1-10', '11-50', '51-200', '201-1000', '1000+']
const INDUSTRIES = ['SaaS / Software', 'Fintech', 'Healthcare / Biotech', 'E-commerce', 'Agency / Services', 'Education', 'Other']
const TONES = ['Casual & friendly', 'Professional & consultative', 'Bold & direct', 'Technical & precise', 'Warm & empathetic']
const CTA_TYPES = ['Book a demo', 'Start a free trial', 'Schedule a call', 'Get a quote', 'Sign up']

function RadioGroup({ label, options, value, onChange }: { label: string; options: string[]; value: string; onChange: (v: string) => void }) {
  return (
    <div>
      <label style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '8px' }}>{label}</label>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
        {options.map(opt => (
          <button key={opt} onClick={() => onChange(opt)} type="button"
            style={{
              padding: '8px 16px', borderRadius: 'var(--radius-full)',
              border: `1px solid ${value === opt ? 'var(--accent-primary)' : 'var(--border-color)'}`,
              background: value === opt ? 'rgba(34, 211, 167, 0.12)' : 'var(--bg-card)',
              color: value === opt ? 'var(--accent-primary)' : 'var(--text-secondary)',
              fontSize: '13px', fontWeight: 500, cursor: 'pointer', transition: 'all 0.15s',
            }}>
            {opt}
          </button>
        ))}
      </div>
    </div>
  )
}

function TextInput({ label, value, onChange, placeholder, multiline = false }: {
  label: string; value: string; onChange: (v: string) => void; placeholder: string; multiline?: boolean
}) {
  const style = {
    width: '100%', padding: '10px 14px', borderRadius: 'var(--radius-sm)',
    border: '1px solid var(--border-color)', background: 'var(--bg-card)',
    color: 'var(--text-primary)', fontSize: '14px', fontFamily: 'var(--font-body)',
    outline: 'none', lineHeight: 1.5, resize: 'none' as const,
  }
  return (
    <div>
      <label style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>{label}</label>
      {multiline ? (
        <textarea value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} rows={3} style={style} />
      ) : (
        <input type="text" value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} style={style} />
      )}
    </div>
  )
}

export default function OnboardingPage() {
  const [step, setStep] = useState<Step>('info')
  const [companyName, setCompanyName] = useState('')
  const [website, setWebsite] = useState('')
  const [scraping, setScraping] = useState(false)
  const [scraped, setScraped] = useState(false)
  const [formData, setFormData] = useState<FormData>({
    product_name: '', product_description: '', problem_solved: '', key_differentiators: '',
    company_size: '', industry: '', target_roles: '', tone: '', cta_type: '', calendar_link: '',
  })
  const [messages, setMessages] = useState<Message[]>([])
  const [userInput, setUserInput] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const [playbook, setPlaybook] = useState<PlaybookData | null>(null)
  const [saving, setSaving] = useState(false)
  const [profileId, setProfileId] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const chatEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])
  useEffect(() => { if (step === 'train' && inputRef.current) inputRef.current.focus() }, [step, messages])

  const updateForm = (field: keyof FormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  // Scrape website
  const scrapeWebsite = async () => {
    if (!website.trim()) return
    setScraping(true)
    setError(null)
    try {
      const res = await fetch('/api/training', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'scrape_website', website }),
      })
      const data = await res.json()
      if (data.extracted) {
        setFormData(prev => ({
          ...prev,
          product_name: data.extracted.product_name || prev.product_name,
          product_description: data.extracted.product_description || prev.product_description,
          problem_solved: data.extracted.problem_solved || prev.problem_solved,
          key_differentiators: data.extracted.key_differentiators || prev.key_differentiators,
          target_roles: data.extracted.suggested_roles || prev.target_roles,
        }))
        setScraped(true)
      } else {
        setError(data.error || 'Could not read website — fill in manually')
      }
    } catch {
      setError('Could not reach website — fill in manually')
    }
    setScraping(false)
  }

  // Proceed to training chat
  const startTraining = async () => {
    if (!formData.product_name.trim() || !formData.company_size || !formData.tone || !formData.cta_type) return
    setStep('train')
    setIsTyping(true)
    setError(null)

    try {
      const res = await fetch('/api/training', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'chat',
          messages: [{ role: 'user', content: `Hi Jamie, I'm the founder of ${companyName}. I've filled in the basics — ready for your questions.` }],
          companyName,
          formData,
        }),
      })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      setMessages([{ role: 'jamie', content: data.message }])
    } catch {
      setError('Failed to connect to Jamie. Try again.')
    }
    setIsTyping(false)
  }

  // Chat send
  const handleSend = async () => {
    if (!userInput.trim() || isTyping) return
    const newMessages: Message[] = [...messages, { role: 'user', content: userInput }]
    setMessages(newMessages)
    setUserInput('')
    setIsTyping(true)
    setError(null)

    try {
      const res = await fetch('/api/training', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'chat', messages: newMessages, companyName, formData }),
      })
      const data = await res.json()
      if (data.error) throw new Error(data.error)

      const updatedMessages: Message[] = [...newMessages, { role: 'jamie', content: data.message }]
      setMessages(updatedMessages)

      if (data.message.includes('🎉') || data.message.toLowerCase().includes('got everything') || data.message.toLowerCase().includes('playbook now')) {
        setTimeout(() => generatePlaybook(updatedMessages), 1500)
      }
    } catch {
      setError('Failed to get response. Try again.')
    }
    setIsTyping(false)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend() }
  }

  const generatePlaybook = async (allMessages: Message[]) => {
    setIsTyping(true)
    try {
      const res = await fetch('/api/training', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'generate_playbook', messages: allMessages, companyName, formData }),
      })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      setPlaybook(data.playbook)
      setStep('review')
    } catch {
      setError('Failed to generate playbook. Try again.')
    }
    setIsTyping(false)
  }

  const savePlaybook = async () => {
    if (!playbook) return
    setSaving(true)
    setError(null)
    const supabase = createClient()
    try {
      const { data: company, error: compError } = await supabase
        .from('companies').insert({ name: companyName, domain: website }).select().single()
      if (compError) throw compError

      const { data: profile, error: profError } = await supabase
        .from('onboarding_profiles').insert({
          company_id: company.id, status: 'completed',
          product_name: playbook.product_name, product_description: playbook.product_description,
          problem_solved: playbook.problem_solved, key_differentiators: playbook.key_differentiators,
          target_company_size: playbook.target_company_size, target_industries: playbook.target_industries,
          target_roles: playbook.target_roles, icp_signals: playbook.icp_signals,
          qualification_questions: playbook.qualification_questions,
          disqualification_criteria: playbook.disqualification_criteria,
          objection_playbook: playbook.objection_playbook,
          voice_style: playbook.voice_style, call_to_action: playbook.call_to_action,
          calendar_link: playbook.calendar_link,
          training_transcript: messages, uploaded_docs: [],
        }).select().single()
      if (profError) throw profError

      await supabase.from('digital_employees').insert({
        company_id: company.id, name: 'Jamie', title: 'SDR — Sales Development Rep',
        department: 'Sales', category: 'sdr', status: 'active',
      })
      if (profile) setProfileId(profile.id)
    } catch {
      setError('Failed to save. Try again.')
    }
    setSaving(false)
  }

  const questionCount = messages.filter(m => m.role === 'jamie').length
  const formReady = formData.product_name.trim() && formData.company_size && formData.tone && formData.cta_type

  return (
    <div style={{ minHeight: '100vh' }}>
      {/* Nav */}
      <nav style={{
        position: 'sticky', top: 0, zIndex: 100, padding: '12px 0',
        background: 'rgba(10, 10, 15, 0.9)', backdropFilter: 'blur(20px)',
        borderBottom: '1px solid var(--border-color)',
      }}>
        <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Link href="/" style={{ fontFamily: 'var(--font-mono)', fontSize: '16px', fontWeight: 700 }}>
            <span style={{ color: 'var(--accent-primary)' }}>jamie</span>
            <span style={{ color: 'var(--text-tertiary)' }}>@</span>
            <span>work</span>
          </Link>
          <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
            {(['info', 'train', 'review'] as Step[]).map((s, i) => (
              <div key={s} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div style={{
                  width: '28px', height: '28px', borderRadius: '50%',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: '12px', fontWeight: 700, fontFamily: 'var(--font-mono)',
                  background: step === s ? 'var(--accent-primary)' :
                    (['info', 'train', 'review'].indexOf(step) > i ? 'rgba(34, 211, 167, 0.2)' : 'var(--bg-card)'),
                  color: step === s ? 'var(--bg-primary)' : 'var(--text-tertiary)',
                  border: `1px solid ${step === s ? 'var(--accent-primary)' : 'var(--border-color)'}`,
                }}>
                  {['info', 'train', 'review'].indexOf(step) > i ? '✓' : i + 1}
                </div>
                {i < 2 && <div style={{ width: '20px', height: '1px', background: ['info', 'train', 'review'].indexOf(step) > i ? 'var(--accent-primary)' : 'var(--border-color)' }} />}
              </div>
            ))}
          </div>
        </div>
      </nav>

      {error && (
        <div style={{
          padding: '10px 24px', background: 'rgba(239, 68, 68, 0.1)',
          borderBottom: '1px solid rgba(239, 68, 68, 0.2)', textAlign: 'center',
          fontSize: '13px', color: 'var(--accent-danger)',
        }}>{error}</div>
      )}

      {/* STEP 1: Info + Radio Buttons */}
      {step === 'info' && (
        <div className="container" style={{ maxWidth: '640px', padding: '48px 24px 80px' }}>
          <div className="animate-in">
            <h1 style={{ fontSize: '28px', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: '8px' }}>
              Train Jamie in under 10 minutes
            </h1>
            <p style={{ color: 'var(--text-secondary)', fontSize: '15px', marginBottom: '36px' }}>
              Enter your website and Jamie will learn your product. Then confirm a few details and answer 3 quick questions.
            </p>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
            {/* Website + Scrape */}
            <div className="animate-in animate-delay-1">
              <div style={{ display: 'flex', gap: '12px' }}>
                <div style={{ flex: 1 }}>
                  <TextInput label="Company Name *" value={companyName} onChange={setCompanyName} placeholder="e.g., Acme Corp" />
                </div>
                <div style={{ flex: 1 }}>
                  <label style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>Website</label>
                  <div style={{ display: 'flex', gap: '8px' }}>
                    <input type="text" value={website} onChange={e => setWebsite(e.target.value)}
                      placeholder="yoursite.com"
                      style={{
                        flex: 1, padding: '10px 14px', borderRadius: 'var(--radius-sm)',
                        border: '1px solid var(--border-color)', background: 'var(--bg-card)',
                        color: 'var(--text-primary)', fontSize: '14px', fontFamily: 'var(--font-body)', outline: 'none',
                      }} />
                    <button onClick={scrapeWebsite} disabled={!website.trim() || scraping}
                      className="btn btn-secondary" style={{ fontSize: '12px', padding: '8px 14px', whiteSpace: 'nowrap' }}>
                      {scraping ? 'Reading...' : scraped ? '✓ Done' : '🔍 Auto-fill'}
                    </button>
                  </div>
                </div>
              </div>
              {scraped && (
                <div style={{
                  marginTop: '8px', padding: '8px 12px', borderRadius: 'var(--radius-sm)',
                  background: 'rgba(34, 211, 167, 0.08)', border: '1px solid rgba(34, 211, 167, 0.15)',
                  fontSize: '12px', color: 'var(--accent-primary)',
                }}>
                  ✓ Jamie read your website and pre-filled the fields below. Review and edit as needed.
                </div>
              )}
            </div>

            {/* Pre-filled product info */}
            <div className="animate-in animate-delay-2" style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{ fontSize: '16px', fontWeight: 600, paddingTop: '8px', borderTop: '1px solid var(--border-color)' }}>
                Your Product
              </div>
              <TextInput label="Product Name *" value={formData.product_name} onChange={v => updateForm('product_name', v)} placeholder="What's the product called?" />
              <TextInput label="What do you sell?" value={formData.product_description} onChange={v => updateForm('product_description', v)} placeholder="1-2 sentence description" multiline />
              <TextInput label="What problem do you solve?" value={formData.problem_solved} onChange={v => updateForm('problem_solved', v)} placeholder="The core pain point" multiline />
              <TextInput label="What makes you different?" value={formData.key_differentiators} onChange={v => updateForm('key_differentiators', v)} placeholder="Your edge over alternatives" multiline />
            </div>

            {/* Quick selects */}
            <div className="animate-in animate-delay-3" style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{ fontSize: '16px', fontWeight: 600, paddingTop: '8px', borderTop: '1px solid var(--border-color)' }}>
                Your Ideal Customer
              </div>
              <RadioGroup label="Target Company Size *" options={COMPANY_SIZES} value={formData.company_size} onChange={v => updateForm('company_size', v)} />
              <RadioGroup label="Industry" options={INDUSTRIES} value={formData.industry} onChange={v => updateForm('industry', v)} />
              <TextInput label="Buyer Job Titles" value={formData.target_roles} onChange={v => updateForm('target_roles', v)} placeholder="e.g., VP of Sales, CTO, Head of Ops" />
            </div>

            <div className="animate-in animate-delay-4" style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{ fontSize: '16px', fontWeight: 600, paddingTop: '8px', borderTop: '1px solid var(--border-color)' }}>
                Jamie&apos;s Style
              </div>
              <RadioGroup label="How should Jamie sound? *" options={TONES} value={formData.tone} onChange={v => updateForm('tone', v)} />
              <RadioGroup label="Call to Action *" options={CTA_TYPES} value={formData.cta_type} onChange={v => updateForm('cta_type', v)} />
              <TextInput label="Calendar Link (optional)" value={formData.calendar_link} onChange={v => updateForm('calendar_link', v)} placeholder="https://calendly.com/you" />
            </div>

            <button onClick={startTraining} disabled={!formReady}
              className="btn btn-primary btn-lg"
              style={{ marginTop: '8px', width: '100%', opacity: formReady ? 1 : 0.5, cursor: formReady ? 'pointer' : 'not-allowed' }}>
              Continue — 3 Quick Questions →
            </button>
            <p style={{ fontSize: '12px', color: 'var(--text-tertiary)', textAlign: 'center' }}>
              Jamie needs to ask about objections, qualification, and any special instructions. Takes ~3 minutes.
            </p>
          </div>
        </div>
      )}

      {/* STEP 2: Training Chat (3 questions) */}
      {step === 'train' && (
        <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 53px)' }}>
          <div style={{ padding: '12px 24px', borderBottom: '1px solid var(--border-color)', background: 'var(--bg-secondary)' }}>
            <div className="container" style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <div style={{
                width: '36px', height: '36px', borderRadius: '50%',
                background: 'linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))',
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '16px',
              }}>🤖</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: '14px' }}>Jamie — Final Questions</div>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)' }}>3 quick questions for {companyName}</div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div style={{ width: '80px', height: '4px', borderRadius: '2px', background: 'var(--bg-card)', overflow: 'hidden' }}>
                  <div style={{
                    width: `${Math.min((questionCount / 3) * 100, 100)}%`, height: '100%',
                    borderRadius: '2px', background: 'var(--accent-primary)', transition: 'width 0.3s',
                  }} />
                </div>
                <span style={{ fontSize: '11px', color: 'var(--text-tertiary)', fontFamily: 'var(--font-mono)' }}>{Math.min(questionCount, 3)}/3</span>
              </div>
            </div>
          </div>

          <div style={{ flex: 1, overflowY: 'auto', padding: '24px' }}>
            <div className="container" style={{ maxWidth: '700px' }}>
              {messages.map((msg, i) => (
                <div key={i} style={{
                  display: 'flex', justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start',
                  marginBottom: '16px',
                }}>
                  <div style={{
                    maxWidth: '85%', padding: '14px 18px',
                    borderRadius: msg.role === 'user' ? '16px 16px 4px 16px' : '16px 16px 16px 4px',
                    background: msg.role === 'user' ? 'var(--accent-primary)' : 'var(--bg-card)',
                    color: msg.role === 'user' ? 'var(--bg-primary)' : 'var(--text-primary)',
                    border: msg.role === 'user' ? 'none' : '1px solid var(--border-color)',
                    fontSize: '14px', lineHeight: 1.6,
                  }}>
                    <span dangerouslySetInnerHTML={{
                      __html: msg.content.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>')
                    }} />
                  </div>
                </div>
              ))}
              {isTyping && (
                <div style={{ display: 'flex', justifyContent: 'flex-start', marginBottom: '16px' }}>
                  <div style={{
                    padding: '14px 18px', borderRadius: '16px 16px 16px 4px',
                    background: 'var(--bg-card)', border: '1px solid var(--border-color)',
                    fontSize: '14px', color: 'var(--text-tertiary)',
                  }}>Jamie is thinking...</div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>
          </div>

          <div style={{ padding: '16px 24px', borderTop: '1px solid var(--border-color)', background: 'var(--bg-secondary)' }}>
            <div className="container" style={{ maxWidth: '700px', display: 'flex', gap: '12px' }}>
              <textarea ref={inputRef} value={userInput} onChange={e => setUserInput(e.target.value)}
                onKeyDown={handleKeyDown} placeholder="Type your answer... (Enter to send)"
                rows={2}
                style={{
                  flex: 1, padding: '12px 16px', borderRadius: 'var(--radius-sm)',
                  border: '1px solid var(--border-color)', background: 'var(--bg-card)',
                  color: 'var(--text-primary)', fontSize: '14px', fontFamily: 'var(--font-body)',
                  resize: 'none', outline: 'none', lineHeight: 1.5,
                }} />
              <button onClick={handleSend} disabled={!userInput.trim() || isTyping}
                className="btn btn-primary" style={{ alignSelf: 'flex-end', opacity: userInput.trim() && !isTyping ? 1 : 0.5 }}>
                Send
              </button>
            </div>
          </div>
        </div>
      )}

      {/* STEP 3: Review Playbook */}
      {step === 'review' && playbook && (
        <div className="container" style={{ maxWidth: '800px', padding: '40px 24px 80px' }}>
          <div style={{ marginBottom: '32px' }}>
            <h1 style={{ fontSize: '28px', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: '8px' }}>
              Jamie&apos;s Sales Playbook
            </h1>
            <p style={{ color: 'var(--text-secondary)', fontSize: '15px' }}>
              Review what Jamie learned. Edit anything that&apos;s off, then approve to go live.
            </p>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            <div className="card">
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--accent-primary)', marginBottom: '12px', fontFamily: 'var(--font-mono)' }}>THE PITCH</h3>
              {[
                ['Product', playbook.product_name],
                ['Description', playbook.product_description],
                ['Problem Solved', playbook.problem_solved],
                ['Differentiators', playbook.key_differentiators],
              ].map(([label, val]) => (
                <div key={label} style={{ marginBottom: '12px' }}>
                  <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>{label}</div>
                  <div style={{ fontSize: '14px', lineHeight: 1.6 }}>{val}</div>
                </div>
              ))}
            </div>

            <div className="card">
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--accent-primary)', marginBottom: '12px', fontFamily: 'var(--font-mono)' }}>IDEAL CUSTOMER PROFILE</h3>
              {[
                ['Company Size', playbook.target_company_size],
                ['Industries', playbook.target_industries],
                ['Decision Makers', playbook.target_roles],
                ['Buying Signals', playbook.icp_signals],
              ].map(([label, val]) => (
                <div key={label} style={{ marginBottom: '12px' }}>
                  <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>{label}</div>
                  <div style={{ fontSize: '14px', lineHeight: 1.6 }}>{val}</div>
                </div>
              ))}
            </div>

            <div className="card">
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--accent-primary)', marginBottom: '12px', fontFamily: 'var(--font-mono)' }}>QUALIFICATION FRAMEWORK</h3>
              <div style={{ marginBottom: '16px' }}>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '8px' }}>Questions Jamie Will Ask</div>
                {playbook.qualification_questions.map((q, i) => (
                  <div key={i} style={{
                    padding: '10px 14px', borderRadius: 'var(--radius-sm)', marginBottom: '6px',
                    background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', fontSize: '13px',
                  }}>
                    <span style={{ color: 'var(--accent-primary)', fontFamily: 'var(--font-mono)', marginRight: '8px' }}>{i + 1}.</span>{q}
                  </div>
                ))}
              </div>
              <div>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Walk Away When</div>
                <div style={{ fontSize: '14px', lineHeight: 1.6, color: 'var(--accent-danger)' }}>{playbook.disqualification_criteria}</div>
              </div>
            </div>

            <div className="card">
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--accent-primary)', marginBottom: '12px', fontFamily: 'var(--font-mono)' }}>OBJECTION PLAYBOOK</h3>
              {playbook.objection_playbook.map((obj, i) => (
                <div key={i} style={{
                  padding: '14px 16px', borderRadius: 'var(--radius-sm)', marginBottom: '12px',
                  background: 'var(--bg-secondary)', border: '1px solid var(--border-color)',
                }}>
                  <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--accent-warning)', marginBottom: '6px' }}>&ldquo;{obj.objection}&rdquo;</div>
                  <div style={{ fontSize: '13px', color: 'var(--text-secondary)', lineHeight: 1.5 }}>→ {obj.response}</div>
                </div>
              ))}
            </div>

            <div className="card">
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--accent-primary)', marginBottom: '12px', fontFamily: 'var(--font-mono)' }}>STYLE & CTA</h3>
              {[
                ['Voice', playbook.voice_style],
                ['Call to Action', playbook.call_to_action],
              ].map(([label, val]) => (
                <div key={label} style={{ marginBottom: '12px' }}>
                  <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>{label}</div>
                  <div style={{ fontSize: '14px', lineHeight: 1.6 }}>{val}</div>
                </div>
              ))}
              {playbook.calendar_link && (
                <div>
                  <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', marginBottom: '4px' }}>Calendar</div>
                  <a href={playbook.calendar_link} target="_blank" rel="noopener noreferrer"
                    style={{ fontSize: '14px', fontFamily: 'var(--font-mono)', color: 'var(--accent-primary)' }}>{playbook.calendar_link}</a>
                </div>
              )}
            </div>

            <div style={{ display: 'flex', gap: '12px', marginTop: '12px' }}>
              <button onClick={savePlaybook} disabled={saving || !!profileId}
                className="btn btn-primary btn-lg" style={{ flex: 1 }}>
                {profileId ? '✓ Jamie is Live!' : saving ? 'Deploying...' : 'Approve & Deploy Jamie →'}
              </button>
              <button onClick={() => { setStep('info'); setMessages([]); setPlaybook(null) }}
                className="btn btn-secondary btn-lg">Edit Info</button>
            </div>

            {profileId && (
              <div style={{
                padding: '16px 20px', borderRadius: 'var(--radius-md)',
                background: 'rgba(34, 211, 167, 0.08)', border: '1px solid rgba(34, 211, 167, 0.2)', textAlign: 'center',
              }}>
                <div style={{ fontSize: '15px', fontWeight: 600, color: 'var(--accent-primary)', marginBottom: '8px' }}>
                  🎉 Jamie is deployed and selling for {companyName}!
                </div>
                <Link href="/dashboard" className="btn btn-primary" style={{ fontSize: '13px', marginTop: '8px' }}>Go to Dashboard →</Link>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
