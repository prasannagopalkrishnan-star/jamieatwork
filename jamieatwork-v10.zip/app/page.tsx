import Link from 'next/link'

const SDR_CAPABILITIES = [
  { icon: '🎯', title: 'Inbound Chat', desc: 'Engages visitors, qualifies them, books meetings on your calendar.' },
  { icon: '✉️', title: 'Outbound Email', desc: 'Personalized outreach based on your ICP. No generic templates.' },
  { icon: '🔍', title: 'Lead Qualification', desc: 'Scores leads against your framework, filters out bad fits.' },
  { icon: '📅', title: 'Meeting Booking', desc: 'Qualified leads get booked directly. No scheduling ping-pong.' },
  { icon: '🔄', title: 'Follow-ups', desc: 'Persistent but natural follow-up until they respond or opt out.' },
  { icon: '📊', title: 'Pipeline View', desc: 'Every lead, conversation, and meeting in one dashboard.' },
]

const HOW_IT_WORKS = [
  { step: '01', title: 'Drop your website', desc: 'Jamie reads your site and pre-fills product, ICP, and differentiators. You just review.', time: '2 min' },
  { step: '02', title: 'Pick her personality', desc: 'Choose Jamie\'s tone, your CTA, and target market with visual cards. No forms.', time: '3 min' },
  { step: '03', title: 'Answer 3 questions', desc: 'Jamie asks about objections, qualification, and special context. Done.', time: '5 min' },
]

export default function Home() {
  return (
    <>
      <style>{`
        @import url('https://api.fontshare.com/v2/css?f[]=satoshi@500,700,800,900&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #FAF9F7; }
        .fd { font-family: 'Satoshi', -apple-system, sans-serif; }
        .fb { font-family: 'DM Sans', -apple-system, sans-serif; }
        .fm { font-family: 'JetBrains Mono', monospace; }
        @keyframes fadeUp { from { opacity:0; transform:translateY(14px); } to { opacity:1; transform:translateY(0); } }
        @keyframes pulse { 0%,100%{opacity:1;} 50%{opacity:.4;} }
        .ai { animation: fadeUp .5s cubic-bezier(.16,1,.3,1) forwards; opacity:0; }
        .d1{animation-delay:.08s;}.d2{animation-delay:.16s;}.d3{animation-delay:.24s;}.d4{animation-delay:.32s;}
        .ch{transition:all .2s cubic-bezier(.16,1,.3,1);}
        .ch:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(28,25,23,.08);border-color:#0D9488;}
        .noise{position:relative;}
        .noise::before{content:'';position:absolute;inset:0;opacity:.02;pointer-events:none;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");}
      `}</style>

      <div className="noise" style={{ minHeight: '100vh', background: '#FAF9F7', color: '#1C1917' }}>
        {/* ── NAV ── */}
        <nav style={{
          position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100, padding: '12px 0',
          background: 'rgba(250,249,247,.85)', backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)',
          borderBottom: '1px solid #E8E5DF',
        }}>
          <div style={{ maxWidth: '1080px', margin: '0 auto', padding: '0 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: '8px', textDecoration: 'none', color: '#1C1917' }}>
              <div style={{ width: '28px', height: '28px', borderRadius: '8px', background: 'linear-gradient(135deg,#0D9488,#06B6D4)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: '13px', fontWeight: 800 }}>J</div>
              <span className="fd" style={{ fontSize: '15px', fontWeight: 800, letterSpacing: '-.03em' }}>jamie<span style={{ color: '#A8A29E', fontWeight: 500 }}>@</span>work</span>
            </Link>
            <div style={{ display: 'flex', gap: '8px' }}>
              <Link href="/dashboard" className="fb" style={{ fontSize: '13px', padding: '7px 16px', borderRadius: '9px', border: '1.5px solid #E8E5DF', background: 'white', color: '#1C1917', textDecoration: 'none', fontWeight: 600 }}>Dashboard</Link>
              <Link href="/onboarding" className="fb" style={{ fontSize: '13px', padding: '7px 16px', borderRadius: '9px', background: 'linear-gradient(135deg,#0D9488,#06B6D4)', color: 'white', textDecoration: 'none', fontWeight: 700, border: 'none' }}>Hire Jamie →</Link>
            </div>
          </div>
        </nav>

        {/* ── HERO — compact, punchy ── */}
        <section style={{ paddingTop: '100px', paddingBottom: '48px', position: 'relative', overflow: 'hidden' }}>
          {/* Subtle glow */}
          <div style={{ position: 'absolute', top: '0', left: '20%', width: '500px', height: '400px', borderRadius: '50%', background: 'radial-gradient(circle, rgba(13,148,136,.05) 0%, transparent 70%)', filter: 'blur(40px)', pointerEvents: 'none' }} />

          <div style={{ maxWidth: '1080px', margin: '0 auto', padding: '0 24px', position: 'relative' }}>
            {/* Two column hero */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '48px', alignItems: 'center' }}>
              {/* Left — copy */}
              <div>
                <div className="ai fb" style={{
                  display: 'inline-flex', alignItems: 'center', gap: '7px', padding: '5px 14px',
                  borderRadius: '100px', border: '1px solid #E8E5DF', background: 'white',
                  fontSize: '12px', color: '#78716C', marginBottom: '20px', fontWeight: 500,
                }}>
                  <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#0D9488', animation: 'pulse 2s infinite' }} />
                  AI Sales Development Rep
                </div>

                <h1 className="ai d1 fd" style={{ fontSize: '48px', fontWeight: 900, lineHeight: 1.05, letterSpacing: '-.045em', marginBottom: '16px' }}>
                  Your first SDR.<br />
                  <span style={{ background: 'linear-gradient(135deg,#0D9488,#06B6D4)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                    Trained in 10 min.
                  </span>
                </h1>

                <p className="ai d2 fb" style={{ fontSize: '16px', color: '#57534E', lineHeight: 1.65, marginBottom: '28px', maxWidth: '440px', fontWeight: 500 }}>
                  Jamie learns your product, pitch, and ICP — then qualifies leads, sends outreach, and books meetings. 24/7.
                </p>

                <div className="ai d3" style={{ display: 'flex', gap: '10px', marginBottom: '16px' }}>
                  <Link href="/onboarding" className="fb" style={{
                    padding: '12px 28px', borderRadius: '12px',
                    background: 'linear-gradient(135deg,#0D9488,#06B6D4)', color: 'white',
                    fontSize: '15px', fontWeight: 700, textDecoration: 'none',
                    boxShadow: '0 3px 12px rgba(13,148,136,.25)',
                  }}>Hire Jamie — Free to Start →</Link>
                  <a href="#how-it-works" className="fb" style={{
                    padding: '12px 24px', borderRadius: '12px',
                    background: 'white', border: '1.5px solid #E8E5DF', color: '#1C1917',
                    fontSize: '15px', fontWeight: 600, textDecoration: 'none',
                  }}>How It Works</a>
                </div>

                <p className="ai d4 fb" style={{ fontSize: '12px', color: '#A8A29E', fontWeight: 500 }}>
                  For startups doing $0–$1M ARR who can&apos;t afford a full-time SDR.
                </p>
              </div>

              {/* Right — stats + mini preview */}
              <div className="ai d2" style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {/* Comparison card */}
                <div style={{ padding: '24px', borderRadius: '18px', background: 'white', border: '1px solid #E8E5DF', boxShadow: '0 2px 8px rgba(28,25,23,.04)' }}>
                  <div className="fm" style={{ fontSize: '10px', fontWeight: 600, color: '#A8A29E', marginBottom: '16px', letterSpacing: '.08em' }}>HUMAN SDR vs JAMIE</div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                    {[
                      { label: 'Cost', human: '$70K+/yr', jamie: '$0 to start', jColor: '#0D9488' },
                      { label: 'Ramp time', human: '3 months', jamie: '10 minutes', jColor: '#0D9488' },
                      { label: 'Availability', human: '40 hrs/wk', jamie: '24/7/365', jColor: '#0D9488' },
                      { label: 'Tenure', human: '~14 months', jamie: 'Forever', jColor: '#0D9488' },
                    ].map(r => (
                      <div key={r.label}>
                        <div className="fb" style={{ fontSize: '11px', color: '#A8A29E', marginBottom: '6px', fontWeight: 600 }}>{r.label}</div>
                        <div className="fm" style={{ fontSize: '13px', color: '#DC2626', fontWeight: 600, textDecoration: 'line-through', opacity: .7, marginBottom: '2px' }}>{r.human}</div>
                        <div className="fm" style={{ fontSize: '14px', color: r.jColor, fontWeight: 700 }}>{r.jamie}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Social proof placeholder */}
                <div style={{ padding: '16px 20px', borderRadius: '14px', background: '#F5F3EE', border: '1px solid #E8E5DF', display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: 'linear-gradient(135deg,#0D9488,#06B6D4)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '18px', flexShrink: 0 }}>🤖</div>
                  <div>
                    <div className="fb" style={{ fontSize: '13px', fontWeight: 700, color: '#1C1917' }}>Jamie is ready in 3 steps</div>
                    <div className="fb" style={{ fontSize: '12px', color: '#78716C', fontWeight: 500 }}>Website scan → Pick personality → 3 questions → Live</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ── CAPABILITIES — tighter grid ── */}
        <section style={{ padding: '48px 0', borderTop: '1px solid #E8E5DF' }}>
          <div style={{ maxWidth: '1080px', margin: '0 auto', padding: '0 24px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '24px' }}>
              <h2 className="fd" style={{ fontSize: '24px', fontWeight: 800, letterSpacing: '-.03em' }}>What Jamie Does</h2>
              <span className="fb" style={{ color: '#A8A29E', fontSize: '13px', fontWeight: 500 }}>Full SDR skill set, trained on your product</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px' }}>
              {SDR_CAPABILITIES.map(cap => (
                <div key={cap.title} className="ch" style={{
                  padding: '20px', borderRadius: '14px', background: 'white',
                  border: '1px solid #E8E5DF', boxShadow: '0 1px 3px rgba(28,25,23,.02)', cursor: 'default',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
                    <span style={{ fontSize: '22px' }}>{cap.icon}</span>
                    <h3 className="fd" style={{ fontSize: '15px', fontWeight: 700, letterSpacing: '-.01em' }}>{cap.title}</h3>
                  </div>
                  <p className="fb" style={{ fontSize: '13px', color: '#78716C', lineHeight: 1.55, fontWeight: 500 }}>{cap.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── HOW IT WORKS ── */}
        <section id="how-it-works" style={{ padding: '48px 0', borderTop: '1px solid #E8E5DF', background: '#F5F3EE' }}>
          <div style={{ maxWidth: '1080px', margin: '0 auto', padding: '0 24px' }}>
            <h2 className="fd" style={{ fontSize: '24px', fontWeight: 800, letterSpacing: '-.03em', marginBottom: '32px', textAlign: 'center' }}>
              Ready in{' '}
              <span style={{ background: 'linear-gradient(135deg,#0D9488,#06B6D4)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>10 minutes</span>
            </h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px' }}>
              {HOW_IT_WORKS.map(item => (
                <div key={item.step} style={{
                  padding: '28px 22px', borderRadius: '16px', background: 'white',
                  border: '1px solid #E8E5DF', textAlign: 'center',
                }}>
                  <div className="fm" style={{ fontSize: '32px', fontWeight: 700, color: '#0D9488', marginBottom: '12px', opacity: .45 }}>{item.step}</div>
                  <h3 className="fd" style={{ fontSize: '17px', fontWeight: 700, marginBottom: '6px', letterSpacing: '-.01em' }}>{item.title}</h3>
                  <p className="fb" style={{ fontSize: '13px', color: '#78716C', lineHeight: 1.55, marginBottom: '12px', fontWeight: 500 }}>{item.desc}</p>
                  <span className="fm" style={{ fontSize: '11px', color: '#0D9488', padding: '3px 10px', borderRadius: '100px', border: '1px solid #99F6E4', background: '#F0FDFA', fontWeight: 600 }}>~{item.time}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── CTA ── */}
        <section style={{ padding: '56px 0', textAlign: 'center' }}>
          <div style={{ maxWidth: '520px', margin: '0 auto', padding: '0 24px' }}>
            <h2 className="fd" style={{ fontSize: '28px', fontWeight: 800, letterSpacing: '-.03em', marginBottom: '12px' }}>
              Stop doing SDR work yourself.
            </h2>
            <p className="fb" style={{ fontSize: '15px', color: '#78716C', marginBottom: '24px', lineHeight: 1.6, fontWeight: 500 }}>
              Hire Jamie, teach her your pitch in 10 minutes, and let her fill your calendar.
            </p>
            <Link href="/onboarding" className="fb" style={{
              display: 'inline-block', padding: '13px 30px', borderRadius: '12px',
              background: 'linear-gradient(135deg,#0D9488,#06B6D4)', color: 'white',
              fontSize: '15px', fontWeight: 700, textDecoration: 'none',
              boxShadow: '0 3px 12px rgba(13,148,136,.25)',
            }}>Hire SDR Jamie →</Link>
          </div>
        </section>

        {/* ── FOOTER ── */}
        <footer style={{ padding: '28px 0', borderTop: '1px solid #E8E5DF' }}>
          <div style={{ maxWidth: '1080px', margin: '0 auto', padding: '0 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span className="fm" style={{ fontSize: '12px', color: '#A8A29E' }}>© 2026 jamie@work</span>
            <span className="fb" style={{ fontSize: '12px', color: '#A8A29E' }}>AI digital employees for startups</span>
          </div>
        </footer>
      </div>
    </>
  )
}
