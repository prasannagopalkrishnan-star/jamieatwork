import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'

export const dynamic = 'force-dynamic'

interface Lead {
  id: string; name: string | null; email: string | null; company_name: string | null
  role_title: string | null; source: string | null; status: string
  qualification_score: number | null; created_at: string
}
interface DigitalEmployee {
  id: string; name: string; title: string; department: string | null
  category: string | null; status: string; created_at: string
}
interface Ticket {
  id: string; ticket_ref: string | null; submitter_name: string | null
  category: string | null; question: string; status: string; created_at: string
}

const statusBadge = (status: string) => {
  const map: Record<string, { bg: string; color: string; border: string }> = {
    active: { bg: '#F0FDFA', color: '#0D9488', border: '#99F6E4' },
    qualified: { bg: '#F0FDFA', color: '#0D9488', border: '#99F6E4' },
    meeting_booked: { bg: '#F0FDFA', color: '#0D9488', border: '#99F6E4' },
    resolved: { bg: '#F0FDFA', color: '#0D9488', border: '#99F6E4' },
    new: { bg: '#FFF7ED', color: '#EA580C', border: '#FED7AA' },
    contacted: { bg: '#FFF7ED', color: '#EA580C', border: '#FED7AA' },
    open: { bg: '#FFF7ED', color: '#EA580C', border: '#FED7AA' },
    setup: { bg: '#FFF7ED', color: '#EA580C', border: '#FED7AA' },
    disqualified: { bg: '#FEF2F2', color: '#DC2626', border: '#FECACA' },
    inactive: { bg: '#F5F3EE', color: '#A8A29E', border: '#E8E5DF' },
    closed: { bg: '#F5F3EE', color: '#A8A29E', border: '#E8E5DF' },
    escalated: { bg: '#FEF2F2', color: '#DC2626', border: '#FECACA' },
  }
  const s = map[status] || map.new
  return s
}

export default async function DashboardPage() {
  const supabase = await createClient()
  const { data: employees } = await supabase.from('digital_employees').select('*').order('created_at', { ascending: false })
  const { data: leads } = await supabase.from('leads').select('*').order('created_at', { ascending: false }).limit(10)
  const { data: tickets } = await supabase.from('tickets').select('*').order('created_at', { ascending: false }).limit(10)

  const activeEmployees = employees?.filter((e: DigitalEmployee) => e.status === 'active').length ?? 0
  const totalLeads = leads?.length ?? 0
  const qualifiedLeads = leads?.filter((l: Lead) => l.status === 'qualified' || l.status === 'meeting_booked').length ?? 0
  const meetingsBooked = leads?.filter((l: Lead) => l.status === 'meeting_booked').length ?? 0

  return (
    <>
      <style>{`
        @import url('https://api.fontshare.com/v2/css?f[]=satoshi@700,800,900&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        .font-display { font-family: 'Satoshi', -apple-system, sans-serif; }
        .font-body { font-family: 'DM Sans', -apple-system, sans-serif; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        .noise { position: relative; }
        .noise::before {
          content: ''; position: absolute; inset: 0; opacity: 0.02; pointer-events: none;
          background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
        }
        .row-hover { transition: all 0.15s ease; }
        .row-hover:hover { background: #F5F3EE !important; }
      `}</style>

      <div className="noise" style={{ minHeight: '100vh', background: '#FAF9F7', color: '#1C1917' }}>
        {/* Nav */}
        <nav style={{
          position: 'sticky', top: 0, zIndex: 100, padding: '12px 0',
          background: 'rgba(250,249,247,0.85)', backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)',
          borderBottom: '1px solid #E8E5DF',
        }}>
          <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 28px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
              <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: '10px', textDecoration: 'none', color: '#1C1917' }}>
                <div style={{ width: '28px', height: '28px', borderRadius: '8px', background: 'linear-gradient(135deg, #0D9488, #06B6D4)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: '13px', fontWeight: 800 }}>J</div>
                <span className="font-display" style={{ fontSize: '15px', fontWeight: 800, letterSpacing: '-0.03em' }}>
                  jamie<span style={{ color: '#A8A29E', fontWeight: 400 }}>@</span>work
                </span>
              </Link>
              <span className="font-mono" style={{
                fontSize: '10px', color: '#78716C', padding: '3px 10px', borderRadius: '6px',
                border: '1px solid #E8E5DF', background: 'white', letterSpacing: '0.06em',
              }}>DASHBOARD</span>
            </div>
            <div style={{ display: 'flex', gap: '8px' }}>
              <Link href="/onboarding" className="font-body" style={{
                fontSize: '12px', padding: '7px 16px', borderRadius: '9px',
                background: 'linear-gradient(135deg, #0D9488, #06B6D4)', color: 'white',
                textDecoration: 'none', fontWeight: 600, border: 'none',
              }}>+ Train Jamie</Link>
              <Link href="/" className="font-body" style={{
                fontSize: '12px', padding: '7px 16px', borderRadius: '9px',
                border: '1.5px solid #E8E5DF', background: 'white', color: '#44403C',
                textDecoration: 'none', fontWeight: 600,
              }}>← Home</Link>
            </div>
          </div>
        </nav>

        <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '40px 28px' }}>
          {/* Header */}
          <div style={{ marginBottom: '32px' }}>
            <h1 className="font-display" style={{ fontSize: '28px', fontWeight: 800, letterSpacing: '-0.03em', marginBottom: '6px' }}>
              SDR Command Center
            </h1>
            <p className="font-body" style={{ color: '#78716C', fontSize: '15px' }}>
              Monitor Jamie&apos;s pipeline activity and lead engagement.
            </p>
          </div>

          {/* Stats */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '14px', marginBottom: '36px' }}>
            {[
              { label: 'Active Agents', value: activeEmployees, color: '#0D9488' },
              { label: 'Total Leads', value: totalLeads, color: '#1C1917' },
              { label: 'Qualified', value: qualifiedLeads, color: '#7C3AED' },
              { label: 'Meetings Booked', value: meetingsBooked, color: '#0D9488' },
            ].map(stat => (
              <div key={stat.label} style={{
                padding: '20px', borderRadius: '16px', background: 'white',
                border: '1px solid #E8E5DF', boxShadow: '0 1px 3px rgba(28,25,23,0.03)',
              }}>
                <div className="font-mono" style={{ fontSize: '32px', fontWeight: 700, color: stat.color, marginBottom: '2px' }}>
                  {stat.value}
                </div>
                <div className="font-body" style={{ fontSize: '13px', color: '#78716C' }}>{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Two Column */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
            {/* Leads */}
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                <h2 className="font-display" style={{ fontSize: '17px', fontWeight: 700, letterSpacing: '-0.01em' }}>Recent Leads</h2>
                <span className="font-mono" style={{ fontSize: '11px', color: '#A8A29E' }}>Pipeline</span>
              </div>
              {leads && leads.length > 0 ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  {leads.map((lead: Lead) => {
                    const badge = statusBadge(lead.status)
                    return (
                      <div key={lead.id} className="row-hover" style={{
                        padding: '13px 16px', borderRadius: '12px', background: 'white',
                        border: '1px solid #E8E5DF', boxShadow: '0 1px 2px rgba(28,25,23,0.02)',
                        display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '12px',
                      }}>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div className="font-body" style={{ fontWeight: 600, fontSize: '14px', marginBottom: '2px', color: '#1C1917' }}>
                            {lead.name ?? 'Unknown'}
                          </div>
                          <div className="font-mono" style={{ fontSize: '11px', color: '#A8A29E' }}>
                            {lead.role_title ?? ''}{lead.company_name ? ` · ${lead.company_name}` : ''} · {lead.source ?? 'manual'} · {new Date(lead.created_at).toLocaleDateString()}
                          </div>
                        </div>
                        <span className="font-mono" style={{
                          fontSize: '10px', fontWeight: 600, padding: '3px 10px', borderRadius: '6px',
                          background: badge.bg, color: badge.color, border: `1px solid ${badge.border}`,
                          whiteSpace: 'nowrap', letterSpacing: '0.02em',
                        }}>
                          {lead.status.replace('_', ' ')}
                        </span>
                      </div>
                    )
                  })}
                </div>
              ) : (
                <div style={{
                  padding: '48px 24px', borderRadius: '16px', background: 'white',
                  border: '1px solid #E8E5DF', textAlign: 'center',
                }}>
                  <div style={{ fontSize: '32px', marginBottom: '12px' }}>🎯</div>
                  <p className="font-body" style={{ fontSize: '14px', color: '#78716C', marginBottom: '16px' }}>
                    No leads yet. Train Jamie and she&apos;ll start filling your pipeline.
                  </p>
                  <Link href="/onboarding" className="font-body" style={{
                    display: 'inline-block', padding: '8px 20px', borderRadius: '10px',
                    background: 'linear-gradient(135deg, #0D9488, #06B6D4)', color: 'white',
                    fontSize: '13px', fontWeight: 600, textDecoration: 'none',
                  }}>Train Jamie</Link>
                </div>
              )}
            </div>

            {/* Activity */}
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                <h2 className="font-display" style={{ fontSize: '17px', fontWeight: 700, letterSpacing: '-0.01em' }}>Recent Activity</h2>
                <span className="font-mono" style={{ fontSize: '11px', color: '#A8A29E' }}>Last 10</span>
              </div>
              {tickets && tickets.length > 0 ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  {tickets.map((ticket: Ticket) => {
                    const badge = statusBadge(ticket.status)
                    return (
                      <div key={ticket.id} className="row-hover" style={{
                        padding: '13px 16px', borderRadius: '12px', background: 'white',
                        border: '1px solid #E8E5DF', boxShadow: '0 1px 2px rgba(28,25,23,0.02)',
                        display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '12px',
                      }}>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div className="font-body" style={{
                            fontSize: '13px', fontWeight: 500, marginBottom: '3px', color: '#1C1917',
                            whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
                          }}>
                            {ticket.question}
                          </div>
                          <div className="font-mono" style={{ fontSize: '11px', color: '#A8A29E' }}>
                            {ticket.ticket_ref} · {ticket.submitter_name ?? 'Unknown'} · {new Date(ticket.created_at).toLocaleDateString()}
                          </div>
                        </div>
                        <span className="font-mono" style={{
                          fontSize: '10px', fontWeight: 600, padding: '3px 10px', borderRadius: '6px',
                          background: badge.bg, color: badge.color, border: `1px solid ${badge.border}`,
                          whiteSpace: 'nowrap', letterSpacing: '0.02em',
                        }}>
                          {ticket.status}
                        </span>
                      </div>
                    )
                  })}
                </div>
              ) : (
                <div style={{
                  padding: '48px 24px', borderRadius: '16px', background: 'white',
                  border: '1px solid #E8E5DF', textAlign: 'center',
                }}>
                  <div style={{ fontSize: '32px', marginBottom: '12px' }}>📭</div>
                  <p className="font-body" style={{ fontSize: '14px', color: '#78716C' }}>
                    No activity yet. Conversations will appear here once Jamie starts engaging leads.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Agents */}
          <div style={{ marginTop: '36px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
              <h2 className="font-display" style={{ fontSize: '17px', fontWeight: 700, letterSpacing: '-0.01em' }}>Your Digital Employees</h2>
            </div>
            {employees && employees.length > 0 ? (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '10px' }}>
                {employees.map((emp: DigitalEmployee) => {
                  const badge = statusBadge(emp.status)
                  return (
                    <div key={emp.id} style={{
                      padding: '16px 18px', borderRadius: '14px', background: 'white',
                      border: '1px solid #E8E5DF', boxShadow: '0 1px 3px rgba(28,25,23,0.03)',
                      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                    }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                        <div style={{
                          width: '36px', height: '36px', borderRadius: '10px',
                          background: emp.status === 'active' ? 'linear-gradient(135deg, #0D9488, #06B6D4)' : '#F5F3EE',
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                          color: emp.status === 'active' ? 'white' : '#A8A29E', fontSize: '16px',
                        }}>🤖</div>
                        <div>
                          <div className="font-display" style={{ fontWeight: 700, fontSize: '14px', letterSpacing: '-0.01em' }}>{emp.name}</div>
                          <div className="font-body" style={{ fontSize: '12px', color: '#78716C' }}>{emp.title}</div>
                        </div>
                      </div>
                      <span className="font-mono" style={{
                        fontSize: '10px', fontWeight: 600, padding: '3px 10px', borderRadius: '6px',
                        background: badge.bg, color: badge.color, border: `1px solid ${badge.border}`,
                        letterSpacing: '0.02em',
                      }}>
                        {emp.status === 'active' ? '● Active' : emp.status === 'setup' ? '○ Setup' : '◌ Inactive'}
                      </span>
                    </div>
                  )
                })}
              </div>
            ) : (
              <div style={{
                padding: '36px', borderRadius: '16px', background: 'white',
                border: '1px solid #E8E5DF', textAlign: 'center',
              }}>
                <p className="font-body" style={{ fontSize: '14px', color: '#78716C' }}>No agents deployed yet.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  )
}
