import Link from 'next/link'

const SDR_CAPABILITIES = [
  { icon: '🎯', title: 'Inbound Chat', desc: 'Engages website visitors instantly, qualifies them with your criteria, and books meetings on your calendar.' },
  { icon: '✉️', title: 'Outbound Email', desc: 'Crafts personalized outreach based on your ICP and value prop. No more generic templates.' },
  { icon: '🔍', title: 'Lead Qualification', desc: 'Asks the right questions, scores leads against your framework, and filters out bad fits automatically.' },
  { icon: '📅', title: 'Meeting Booking', desc: 'When a lead qualifies, Jamie books directly on your calendar. No back-and-forth scheduling.' },
  { icon: '🔄', title: 'Follow-up Sequences', desc: 'Prospects go quiet? Jamie follows up persistently but naturally until they respond or opt out.' },
  { icon: '📊', title: 'Pipeline Dashboard', desc: 'Track every lead, conversation, and meeting. Full visibility into your AI-powered pipeline.' },
]

const HOW_IT_WORKS = [
  { step: '01', title: 'Drop your website', desc: 'Jamie reads your site and pre-fills everything — product, ICP, differentiators. You just review.', time: '2 min' },
  { step: '02', title: 'Pick her personality', desc: 'Choose Jamie\'s vibe, your CTA, and target market with visual cards. No forms, just taps.', time: '3 min' },
  { step: '03', title: '3 quick questions', desc: 'Jamie asks about objections, qualification, and special instructions. A 5-minute conversation.', time: '5 min' },
]

export default function Home() {
  return (
    <>
      <style>{`
        @import url('https://api.fontshare.com/v2/css?f[]=satoshi@700,800,900&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        .font-display { font-family: 'Satoshi', -apple-system, sans-serif; }
        .font-body { font-family: 'DM Sans', -apple-system, sans-serif; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
        .anim-in { animation: fadeUp 0.6s cubic-bezier(0.16,1,0.3,1) forwards; opacity: 0; }
        .d1 { animation-delay: 0.1s; } .d2 { animation-delay: 0.2s; } .d3 { animation-delay: 0.3s; } .d4 { animation-delay: 0.4s; }
        .cap-card { transition: all 0.25s cubic-bezier(0.16,1,0.3,1); }
        .cap-card:hover { transform: translateY(-3px); box-shadow: 0 12px 32px rgba(28,25,23,0.1); border-color: #0D9488; }
        .noise { position: relative; }
        .noise::before {
          content: ''; position: absolute; inset: 0; opacity: 0.02; pointer-events: none;
          background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
        }
      `}</style>

      <div className="noise" style={{ minHeight: '100vh', background: '#FAF9F7', color: '#1C1917' }}>
        {/* Nav */}
        <nav style={{
          position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100, padding: '14px 0',
          background: 'rgba(250,249,247,0.8)', backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)',
          borderBottom: '1px solid #E8E5DF',
        }}>
          <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 28px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: '10px', textDecoration: 'none', color: '#1C1917' }}>
              <div style={{ width: '30px', height: '30px', borderRadius: '9px', background: 'linear-gradient(135deg, #0D9488, #06B6D4)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: '14px', fontWeight: 800 }}>J</div>
              <span className="font-display" style={{ fontSize: '16px', fontWeight: 800, letterSpacing: '-0.03em' }}>
                jamie<span style={{ color: '#A8A29E', fontWeight: 400 }}>@</span>work
              </span>
            </Link>
            <div style={{ display: 'flex', gap: '8px' }}>
              <Link href="/dashboard" className="font-body" style={{
                fontSize: '13px', padding: '8px 18px', borderRadius: '10px',
                border: '1.5px solid #E8E5DF', background: 'white', color: '#1C1917',
                textDecoration: 'none', fontWeight: 600,
              }}>Dashboard</Link>
              <Link href="/onboarding" className="font-body" style={{
                fontSize: '13px', padding: '8px 18px', borderRadius: '10px',
                background: 'linear-gradient(135deg, #0D9488, #06B6D4)', color: 'white',
                textDecoration: 'none', fontWeight: 600, border: 'none',
              }}>Hire Jamie →</Link>
            </div>
          </div>
        </nav>

        {/* Hero */}
        <section style={{ paddingTop: '160px', paddingBottom: '100px', position: 'relative', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', top: '5%', left: '15%', width: '500px', height: '500px', borderRadius: '50%', background: 'radial-gradient(circle, rgba(13,148,136,0.06) 0%, transparent 70%)', filter: 'blur(60px)', pointerEvents: 'none' }} />
          <div style={{ position: 'absolute', top: '30%', right: '10%', width: '400px', height: '400px', borderRadius: '50%', background: 'radial-gradient(circle, rgba(6,182,212,0.04) 0%, transparent 70%)', filter: 'blur(60px)', pointerEvents: 'none' }} />

          <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 28px', position: 'relative', textAlign: 'center' }}>
            <div className="anim-in font-body" style={{
              display: 'inline-flex', alignItems: 'center', gap: '8px', padding: '6px 18px',
              borderRadius: '100px', border: '1px solid #E8E5DF', background: 'white',
              fontSize: '13px', color: '#78716C', marginBottom: '32px', boxShadow: '0 1px 3px rgba(28,25,23,0.04)',
            }}>
              <span style={{ width: '7px', height: '7px', borderRadius: '50%', background: '#0D9488', animation: 'pulse 2s infinite' }} />
              Your AI Sales Development Rep
            </div>

            <h1 className="anim-in d1 font-display" style={{
              fontSize: 'clamp(42px, 6vw, 72px)', fontWeight: 900, lineHeight: 1.05,
              letterSpacing: '-0.04em', marginBottom: '24px',
            }}>
              Your first SDR.<br />
              <span style={{ background: 'linear-gradient(135deg, #0D9488, #06B6D4)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                Trained in 10 minutes.
              </span>
            </h1>

            <p className="anim-in d2 font-body" style={{
              fontSize: '18px', color: '#78716C', maxWidth: '540px', margin: '0 auto 40px', lineHeight: 1.65,
            }}>
              Jamie learns your product, your pitch, and your ICP — then qualifies leads, sends outreach, and books meetings on your calendar. 24/7.
            </p>

            <div className="anim-in d3" style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
              <Link href="/onboarding" className="font-body" style={{
                padding: '14px 32px', borderRadius: '14px',
                background: 'linear-gradient(135deg, #0D9488, #06B6D4)', color: 'white',
                fontSize: '16px', fontWeight: 600, textDecoration: 'none',
                boxShadow: '0 4px 14px rgba(13,148,136,0.25)',
              }}>
                Hire Jamie — It&apos;s Free to Start →
              </Link>
              <a href="#how-it-works" className="font-body" style={{
                padding: '14px 28px', borderRadius: '14px',
                background: 'white', border: '1.5px solid #E8E5DF', color: '#1C1917',
                fontSize: '16px', fontWeight: 600, textDecoration: 'none',
                boxShadow: '0 1px 3px rgba(28,25,23,0.04)',
              }}>
                See How It Works
              </a>
            </div>

            <p className="anim-in d4 font-body" style={{ fontSize: '13px', color: '#A8A29E', marginTop: '24px' }}>
              Built for startups doing $0–$1M ARR who can&apos;t afford a full-time SDR.
            </p>
          </div>
        </section>

        {/* Problem */}
        <section style={{ borderTop: '1px solid #E8E5DF', borderBottom: '1px solid #E8E5DF', padding: '64px 0', background: '#F5F3EE' }}>
          <div style={{ maxWidth: '700px', margin: '0 auto', padding: '0 28px', textAlign: 'center' }}>
            <h2 className="font-display" style={{ fontSize: '26px', fontWeight: 800, letterSpacing: '-0.03em', marginBottom: '16px' }}>
              You know the problem.
            </h2>
            <p className="font-body" style={{ fontSize: '16px', color: '#78716C', lineHeight: 1.7 }}>
              You&apos;re the founder, the AE, and the SDR. You need pipeline, but a junior SDR costs $70K+ and takes 3 months to ramp.
            </p>
            <div style={{ display: 'flex', justifyContent: 'center', gap: '40px', marginTop: '36px' }}>
              {[
                { val: '$70K+', label: 'Junior SDR salary', color: '#DC2626' },
                { val: '3 mo', label: 'Ramp time', color: '#DC2626' },
                { val: '14 mo', label: 'Avg tenure', color: '#DC2626' },
                { val: '10 min', label: 'Jamie\'s ramp', color: '#0D9488' },
              ].map(s => (
                <div key={s.label}>
                  <div className="font-mono" style={{ fontSize: '28px', fontWeight: 700, color: s.color }}>{s.val}</div>
                  <div className="font-body" style={{ fontSize: '12px', color: '#A8A29E', marginTop: '4px' }}>{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Capabilities */}
        <section style={{ padding: '80px 0' }}>
          <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 28px' }}>
            <div style={{ marginBottom: '48px', textAlign: 'center' }}>
              <h2 className="font-display" style={{ fontSize: '32px', fontWeight: 800, letterSpacing: '-0.03em', marginBottom: '10px' }}>What Jamie Does</h2>
              <p className="font-body" style={{ color: '#78716C', fontSize: '16px' }}>A full SDR skill set, trained on your specific product and market.</p>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px' }}>
              {SDR_CAPABILITIES.map(cap => (
                <div key={cap.title} className="cap-card" style={{
                  padding: '24px', borderRadius: '16px', background: 'white',
                  border: '1px solid #E8E5DF', boxShadow: '0 1px 4px rgba(28,25,23,0.03)',
                  cursor: 'default',
                }}>
                  <div style={{ fontSize: '28px', marginBottom: '12px' }}>{cap.icon}</div>
                  <h3 className="font-display" style={{ fontSize: '16px', fontWeight: 700, marginBottom: '6px', letterSpacing: '-0.01em' }}>{cap.title}</h3>
                  <p className="font-body" style={{ fontSize: '14px', color: '#78716C', lineHeight: 1.6 }}>{cap.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* How It Works */}
        <section id="how-it-works" style={{ padding: '80px 0', borderTop: '1px solid #E8E5DF', background: '#F5F3EE' }}>
          <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 28px' }}>
            <h2 className="font-display" style={{ fontSize: '32px', fontWeight: 800, letterSpacing: '-0.03em', marginBottom: '48px', textAlign: 'center' }}>
              Trained and ready in{' '}
              <span style={{ background: 'linear-gradient(135deg, #0D9488, #06B6D4)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>10 minutes</span>
            </h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '20px' }}>
              {HOW_IT_WORKS.map(item => (
                <div key={item.step} style={{
                  padding: '32px 24px', borderRadius: '18px', background: 'white',
                  border: '1px solid #E8E5DF', textAlign: 'center',
                  boxShadow: '0 1px 4px rgba(28,25,23,0.03)',
                }}>
                  <div className="font-mono" style={{ fontSize: '36px', fontWeight: 700, color: '#0D9488', marginBottom: '16px', opacity: 0.5 }}>{item.step}</div>
                  <h3 className="font-display" style={{ fontSize: '18px', fontWeight: 700, marginBottom: '8px', letterSpacing: '-0.01em' }}>{item.title}</h3>
                  <p className="font-body" style={{ fontSize: '14px', color: '#78716C', lineHeight: 1.6, marginBottom: '16px' }}>{item.desc}</p>
                  <span className="font-mono" style={{
                    fontSize: '12px', color: '#0D9488', padding: '4px 12px', borderRadius: '100px',
                    border: '1px solid #99F6E4', background: '#F0FDFA',
                  }}>~{item.time}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section style={{ padding: '80px 0', textAlign: 'center' }}>
          <div style={{ maxWidth: '560px', margin: '0 auto', padding: '0 28px' }}>
            <h2 className="font-display" style={{ fontSize: '32px', fontWeight: 800, letterSpacing: '-0.03em', marginBottom: '16px' }}>
              Stop doing SDR work yourself.
            </h2>
            <p className="font-body" style={{ fontSize: '16px', color: '#78716C', marginBottom: '32px', lineHeight: 1.6 }}>
              Hire Jamie, teach her your pitch in 10 minutes, and let her fill your calendar with qualified meetings.
            </p>
            <Link href="/onboarding" className="font-body" style={{
              display: 'inline-block', padding: '14px 32px', borderRadius: '14px',
              background: 'linear-gradient(135deg, #0D9488, #06B6D4)', color: 'white',
              fontSize: '16px', fontWeight: 600, textDecoration: 'none',
              boxShadow: '0 4px 14px rgba(13,148,136,0.25)',
            }}>
              Hire SDR Jamie →
            </Link>
          </div>
        </section>

        {/* Footer */}
        <footer style={{ padding: '40px 0', borderTop: '1px solid #E8E5DF' }}>
          <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 28px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div className="font-mono" style={{ fontSize: '13px', color: '#A8A29E' }}>© 2026 jamie@work</div>
            <div className="font-body" style={{ fontSize: '13px', color: '#A8A29E' }}>AI digital employees for startups</div>
          </div>
        </footer>
      </div>
    </>
  )
}
